# EOA DelegateCall System

An advanced Ethereum smart contract system that enables **Externally Owned Accounts (EOAs)** to delegate execution logic through a `delegatecall`-based proxy architecture — combining the security of user-controlled accounts with the programmability of smart contract modules.

---

## Architecture Overview

```
  EOA Owner (signs EIP-712 requests)
        │
        ▼
  ┌─────────────┐     registerVault()    ┌───────────────┐
  │  VaultFactory│ ──────────────────▶  │  Orchestrator  │
  │  (CREATE2)  │                        │  (admin layer) │
  └─────────────┘                        └───────┬────────┘
        │                                         │ execute(vault, req, sig)
        │ deploys & initializes                   │
        ▼                                         ▼
  ┌─────────────┐   executeFromOrchestrator()  ┌─────────────────┐
  │   EOAVault  │ ◀─────────────────────────── │ Orchestrator    │
  │  (proxy)    │                               │  _routeToVault  │
  └──────┬──────┘                               └─────────────────┘
         │ delegatecall
         ▼
  ┌─────────────────┐
  │ ExecutionModule │  (stateless logic, runs in vault's storage context)
  │  execute()      │
  │  executeBatch() │
  │  sendETH()      │
  └─────────────────┘
```

### Contract Inventory

| Contract | Role | Key Properties |
|---|---|---|
| `StorageLayout` | Shared storage slots | Abstract base; defines deterministic slot layout |
| `SignatureVerifier` | EIP-712 typed signing | Pure library; produces/verifies structured data hashes |
| `NonceManager` | Replay protection | Sequential nonce + operation-ID bitmap |
| `ExecutionModule` | Execution logic | Stateless; runs via `delegatecall` in vault context |
| `EOAVault` | Proxy + state | Holds ETH; delegates calls to modules |
| `Orchestrator` | Policy enforcement | Signature verification, nonce check, call policies, timelock |
| `VaultFactory` | Vault lifecycle | CREATE2 deployment; atomic initialization |
| `SessionKeyManager` | Session key permissions | Grant/revoke time-bounded, scoped session keys |
| `AdvancedExecutionModule` | Advanced vault operations | Contract deployment, EIP-1271, staking, DeFi, raw calls |
| `TokenClaimModule` | Token management | ERC-20/721/1155 transfer, approve, claim, airdrop sweep |

---

## How It Works

### 1. Deployment

The `VaultFactory` is the entry point for the entire system. Deploying it automatically creates an `Orchestrator` and an `ExecutionModule`:

```javascript
const factory = await VaultFactory.deploy(
  adminAddress,
  timelockDelay,       // e.g. 24 * 60 * 60 (24 hours)
  timelockThreshold    // e.g. ethers.parseEther("1") (1 ETH)
);
```

### 2. Vault Creation

Any EOA can deploy their own vault using a user-controlled `salt` for deterministic addressing:

```javascript
const salt = ethers.keccak256(ethers.toUtf8Bytes("my-vault-v1"));

// Predict the address before deploying
const predicted = await factory.predictVaultAddress(ownerAddress, salt);

// Deploy
await factory.connect(owner).deployVault(salt);
```

The factory atomically:
1. Deploys an `EOAVault` via `CREATE2`
2. Initializes it with the owner, orchestrator address, and pre-registered module selectors
3. Registers the vault with the `Orchestrator`

### 3. Signing a Request

All operations are authorized by EIP-712 typed signatures:

```javascript
const domain = {
  name: "EOAVault",
  version: "1",
  chainId: chainId,
  verifyingContract: vaultAddress
};

const types = {
  ExecutionRequest: [
    { name: "target",   type: "address" },
    { name: "value",    type: "uint256" },
    { name: "data",     type: "bytes"   },
    { name: "nonce",    type: "uint256" },
    { name: "deadline", type: "uint256" },
    { name: "chainId",  type: "uint256" },
  ]
};

const req = {
  target:   recipientAddress,
  value:    ethers.parseEther("0.1"),   // ETH from vault to send
  data:     "0x",                        // calldata
  nonce:    await vault.getNonce(),      // sequential nonce
  deadline: Math.floor(Date.now() / 1000) + 3600,
  chainId:  chainId
};

const signature = await owner.signTypedData(domain, types, req);
```

### 4. Executing via Orchestrator

The signed request is submitted to the `Orchestrator`, which validates and routes it:

```javascript
await orchestrator.execute(vaultAddress, req, signature);
```

The Orchestrator performs these steps in order:
1. **Temporal check** — deadline not expired, correct chainId
2. **Nonce check** — `req.nonce` must equal `vault.getNonce()` exactly
3. **Signature verification** — ECDSA recovery matches vault owner
4. **Replay check** — operation ID (hash of full request) not already consumed
5. **Call policy enforcement** — target/value/selector whitelisting
6. **Timelock check** — high-value operations may be queued
7. **Mark consumed** — operation ID burned to prevent replay
8. **Route to vault** — calls `vault.executeFromOrchestrator()`

### 5. DelegateCall Execution

Inside the vault, the selected module is called via `delegatecall`:

```
EOAVault.executeFromOrchestrator()
  │
  ├─ checks: module registered? delegate whitelisted?
  │
  └─ delegatecall → ExecutionModule.execute(target, value, data)
       │
       └─ runs in vault's storage/balance context
            └─ target.call{value: value}(data)
```

Because it's `delegatecall`, the module:
- Reads/writes **vault's** storage (nonces, balances, etc.)
- Sends ETH from **vault's** balance
- `msg.sender` in the module = the `Orchestrator`

---

## Security Properties

### EIP-712 Structured Data Signing

All requests use EIP-712, which prevents:
- **Cross-chain replay** — `chainId` is in the domain separator AND the struct
- **Cross-vault replay** — `verifyingContract: vaultAddress` in domain
- **Signature malleability** — enforced via `s ≤ N/2` check

### Three-Layer Replay Protection

| Layer | Mechanism | Purpose |
|---|---|---|
| Sequential nonce | `_nonce` in vault storage | Strictly ordered execution |
| Operation ID bitmap | `consumedOperations[hash]` in Orchestrator | Unique per-request replay block |
| Emergency advance | `emergencyAdvanceNonce(steps)` | Invalidate compromised signed requests |

### Nonce Validation Flow

The `Orchestrator.execute()` checks nonce **before** signature verification routing:

```solidity
uint256 expectedNonce = IEOAVault(vault).getNonce();
if (req.nonce != expectedNonce) {
    revert Orchestrator__NonceMismatch(expectedNonce, req.nonce);
}
```

This means:
- A request with `nonce=5` while vault is at `nonce=3` is rejected immediately
- No partial state changes occur before the check
- The revert includes both expected and provided values for debugging

### Storage Slot Layout

`StorageLayout` defines explicit slot assignments inherited by all contracts that touch vault storage. This prevents storage collisions between the vault and delegatecalled modules:

```solidity
abstract contract StorageLayout {
    address internal _owner;            // slot 0
    address internal _orchestrator;     // slot 1
    uint256 internal _nonce;            // slot 2
    bool    internal _locked;           // slot 3
    bool    internal _paused;           // slot 4
    bool    internal _initialized;      // slot 5
    mapping(address => bool) internal _delegates;       // slot 6
    mapping(bytes4 => address) internal _moduleRegistry; // slot 7
    // ...
}
```

### Module Security

Modules can only be called when:
1. The module address is in `_moduleRegistry` for the given selector
2. The module address has `_delegates[module] == true`

Revoking a delegate (`vault.revokeDelegate(module)`) immediately blocks all executions through that module, even if selectors are still registered.

### Atomic Module Bootstrap

To avoid a chicken-and-egg problem (factory needs to register modules but `registerModule` is owner-only), the vault's `initialize()` accepts selectors atomically:

```solidity
function initialize(
    address initialOwner,
    address initialOrchestrator,
    bytes4[] calldata selectors,
    address module
) external {
    // ...sets owner, orchestrator, nonce, paused state...
    if (module != address(0) && selectors.length > 0) {
        _delegates[module] = true;
        for (uint256 i = 0; i < selectors.length; i++) {
            _moduleRegistry[selectors[i]] = module;
        }
    }
}
```

The factory calls this once during `deployVault()`. After initialization, `_initialized = true` prevents re-initialization.

---

## Module System

### ExecutionModule Selectors

The following selectors are registered by default:

| Function | Selector | Purpose |
|---|---|---|
| `execute(address,uint256,bytes,bool)` | `0x...` | Single call with optional revert propagation |
| `executeBatch(address[],uint256[],bytes[],bool)` | `0x...` | Atomic or best-effort batch calls |
| `sendETH(address,uint256)` | `0x...` | Simple ETH transfer |
| `updateModuleRegistry(bytes4,address)` | `0x...` | Hot-swap module routing |
| `setDelegate(address,bool)` | `0x...` | Whitelist/revoke delegate |
| `syncBalance()` | `0x...` | Update cached ETH balance |

### Registering a Custom Module

```solidity
// Owner registers a new module
vault.registerModule(
    bytes4(keccak256("myCustomOp(address,uint256)")),
    myModuleAddress
);
```

The module must be designed for `delegatecall` and must inherit `StorageLayout` to read vault state at the correct slots.

---

## Timelock System

High-value or flagged operations are queued rather than executed immediately:

```javascript
// Setting a policy: delay + max value cap
await orchestrator.setCallPolicy(targetAddress, {
  allowed: true,
  requiresDelay: true,
  delaySeconds: 24 * 60 * 60,  // 24 hours
  maxValue: ethers.parseEther("0.5")
});
```

Operations exceeding `timelockValueThreshold` (set at deployment) or matching a policy with `requiresDelay: true` are queued as `QueuedOperation` and must be executed with `executeQueued()` after the delay expires.

---

## Call Policies

The Orchestrator supports per-target access control:

```javascript
// Enable whitelist mode (only whitelisted targets allowed)
await orchestrator.setWhitelistMode(true);

// Whitelist a specific target
await orchestrator.setCallPolicy(allowedTarget, {
  allowed: true,
  requiresDelay: false,
  delaySeconds: 0,
  maxValue: ethers.MaxUint256
});
```

Policies can enforce:
- **Target allowlist/blocklist**
- **Maximum value per call**
- **Selector-level restrictions**
- **Mandatory time delays**

---

## Running the Tests

```bash
cd eoa-delegatecall-system
npm install
npx hardhat test
```

Expected output:

```
  EOA DelegateCall System
    1. Deployment & Initialization
      ✔ Factory deploys Orchestrator and ExecutionModule
      ✔ Vault is initialized with correct owner and orchestrator
      ✔ CREATE2 vault address matches prediction
      ✔ Vault cannot be initialized twice
      ✔ ExecutionModule selectors are registered in vault
      ✔ Vault is registered with orchestrator
      ✔ Vault receives ETH via receive()
    2. EIP-712 Signature Verification
      ✔ getExecutionDigest returns correct EIP-712 digest
      ✔ Orchestrator rejects wrong signer
      ✔ Orchestrator rejects tampered request (wrong target)
      ✔ Orchestrator rejects tampered value
      ✔ Orchestrator rejects wrong chainId
      ✔ simulateExecution returns valid for correct signature
    3. Nonce Management & Replay Protection
      ✔ getNonce starts at 0
      ✔ Orchestrator rejects wrong nonce (too high)
      ✔ Rejects expired deadline
      ✔ emergencyAdvanceNonce invalidates pending requests
      ✔ simulateValidation detects nonce mismatch
      ✔ simulateValidation detects expired deadline
    4. Access Control
      ✔ Non-orchestrator cannot call executeFromOrchestrator
      ✔ Non-owner cannot pause vault
      ✔ Non-owner cannot register modules
      ✔ Non-owner cannot transfer ownership
      ✔ Non-admin cannot register vault with orchestrator
      ✔ Non-registered vault is rejected by orchestrator
      ✔ Orchestrator admin transfer is two-step
    5. Emergency Pause
      ✔ Owner can pause and unpause vault
      ✔ Paused vault rejects executeFromOrchestrator
      ✔ Admin can pause orchestrator
      ✔ Paused orchestrator rejects all execute calls
    6. Ownership Management
      ✔ Owner can transfer ownership
      ✔ New owner can exercise owner-only functions
      ✔ Old owner loses access after transfer
      ✔ Cannot transfer ownership to zero address
      ✔ Cannot transfer ownership to same owner
    7. Module Registry
      ✔ Owner can register a new module selector
      ✔ Module is whitelisted as delegate after registration
      ✔ Owner can deregister a module
      ✔ Owner can revoke delegate to block module entirely
      ✔ Execution fails when module delegate is revoked
    8. Domain Separator & EIP-712
      ✔ Domain separator is non-zero and consistent
      ✔ Different vaults have different domain separators
    9. Call Policies
      ✔ Admin can set a call policy for a target
      ✔ Whitelist mode blocks non-whitelisted targets
      ✔ Whitelist mode allows whitelisted targets
    10. Factory & Multi-Vault
      ✔ Multiple owners can deploy separate vaults
      ✔ getOwnerVaults returns correct vaults
      ✔ totalVaults increments after each deployment
      ✔ Cannot deploy same vault twice (same owner + salt)
    11. ETH Balance
      ✔ Vault correctly reports ETH balance
      ✔ Vault accumulates ETH from multiple sends
    12. NonceManager External Views
      ✔ isOperationConsumed returns false for fresh opId
      ✔ getModuleNonce returns 0 for unregistered module

  53 passing (811ms)
```

---

## Key Design Decisions

### Why `delegatecall` Instead of a Regular Module Call?

A regular call (`module.call(data)`) would execute module logic in the **module's** storage context. With `delegatecall`, the logic runs in the **vault's** storage context. This means:

- The module can read/write the vault's nonces, balance records, and access control state
- The vault owner's identity is preserved throughout execution
- Modules are purely stateless — they hold no state of their own
- Swapping module implementations doesn't require migrating state

### Why Sequential Nonces at the Orchestrator Level?

The Orchestrator checks `req.nonce == vault.getNonce()` before any other routing. This ensures:

- Operations execute in the exact order the EOA authorized
- A compromised or replayed higher-nonce request is rejected until the lower-nonce operations execute
- `emergencyAdvanceNonce` can skip ahead to invalidate a range of pending signed requests if a key is compromised

### Why Store `factory` as `immutable` in Orchestrator?

During deployment, `VaultFactory` constructs the `Orchestrator`. The Orchestrator needs to allow the factory to call `registerVault()` so newly deployed vaults are auto-registered. Storing `factory = msg.sender` as `immutable` in the Orchestrator constructor achieves this without adding a separate admin step — the factory is permanently authorized and the relationship is established atomically.

### ETH Flow: Vault Balance, Not Orchestrator Balance

ETH for execution comes from the **vault's own balance**, not forwarded from the Orchestrator. This is possible because:
- `ExecutionModule.execute()` runs via `delegatecall` → `address(this)` is the vault
- `address(this).balance` in the module refers to the vault's ETH
- The Orchestrator itself never holds user funds

This separation means the Orchestrator is a pure policy layer with no custody risk.

---

## Custom Errors Reference

### EOAVault Errors
| Error | Trigger |
|---|---|
| `EOAVault__AlreadyInitialized()` | `initialize()` called twice |
| `EOAVault__ZeroAddress()` | Zero address passed as owner/orchestrator |
| `EOAVault__Unauthorized(address)` | Non-owner or non-orchestrator call; revoked delegate |
| `EOAVault__NoModuleForSelector(bytes4)` | No module registered for the given selector |
| `EOAVault__DelegatecallFailed(address, bytes)` | Delegatecall reverted; inner error in `bytes` |
| `EOAVault__Paused()` | Vault is paused |
| `EOAVault__Reentrancy()` | Reentrant call detected |

### Orchestrator Errors
| Error | Trigger |
|---|---|
| `Orchestrator__NonceMismatch(uint256, uint256)` | req.nonce ≠ vault.getNonce() |
| `Orchestrator__InvalidSignature(address, address)` | Recovered signer ≠ vault owner |
| `Orchestrator__OperationAlreadyConsumed(bytes32)` | Operation ID already executed |
| `Orchestrator__DeadlineExpired(uint256, uint256)` | Block timestamp > req.deadline |
| `Orchestrator__ChainIdMismatch(uint256, uint256)` | req.chainId ≠ block.chainid |
| `Orchestrator__ExecutionFailed(address, bytes)` | Vault/module reverted; inner error in `bytes` |
| `Orchestrator__TimelockRequired(bytes32, uint256)` | Operation queued, not immediately executable |
| `Orchestrator__VaultNotRegistered(address)` | Vault not in registeredVaults mapping |

### NonceManager Errors
| Error | Trigger |
|---|---|
| `NonceManager__InvalidNonce(uint256, uint256)` | Sequential nonce mismatch in vault |
| `NonceManager__OperationAlreadyExecuted(bytes32)` | Operation bitmap already set |
| `NonceManager__DeadlineExpired(uint256, uint256)` | Deadline passed |

---

## Session Keys

Session keys allow third-party relayers (or automated bots) to execute pre-approved operations from a vault without the owner being online. Each key carries fine-grained permission constraints enforced on-chain.

### Granting a Session Key

```javascript
await vault.connect(owner).grantSessionKey(
  keyAddress,        // the key's address (EOA or contract)
  validAfter,        // Unix timestamp — key not valid before this
  validUntil,        // Unix timestamp — 0 = never expires
  maxValuePerCall,   // max ETH per single call (0 = no ETH allowed)
  maxValueTotal,     // max ETH in total across all calls (0 = unlimited)
  maxUsageCount,     // max number of executions (0 = unlimited)
  allowedSelectors,  // bytes4[] of whitelisted function selectors ([] = any)
  allowedTargets     // address[] of whitelisted targets ([] = any)
);
```

### Executing via Session Key

```javascript
const req = {
  keyAddress,   // session key address
  target,       // target contract (usually vault for module calls)
  value,        // ETH to send
  data,         // calldata
  nonce,        // from vault.getSessionKeyNonce(keyAddress)
  deadline,     // Unix timestamp after which the request expires
  chainId,      // must match current chain
};
const sig = await sessionKey.signTypedData(domain, SESSION_EXECUTION_TYPES, req);
await vault.connect(relayer).executeSessionKey(req, sig);
```

---

## AdvancedExecutionModule

Provides EOA-equivalent capabilities to the vault. All functions run via `delegatecall` — the vault is `msg.sender` to all external contracts.

| Function | Description |
|---|---|
| `deployContract(bytecode, value)` | CREATE deployment from vault |
| `deployContract2(bytecode, salt, value)` | CREATE2 deterministic deployment |
| `predictDeployAddress(bytecodeHash, salt)` | Predict CREATE2 address |
| `approveHash(hash)` | EIP-1271 hash pre-approval |
| `revokeHash(hash)` | EIP-1271 hash revocation |
| `permitERC20(token, spender, amount, deadline, v, r, s)` | EIP-2612 gasless permit |
| `stakeETH(stakingContract, amount, callData)` | ETH staking via arbitrary protocol |
| `unstakeETH(stakingContract, amount, callData)` | ETH unstake |
| `claimStakingRewards(stakingContract, callData)` | Claim staking rewards |
| `swapExact(router, tokenIn, tokenOut, amountIn, ethValue, callData)` | DEX exact-in swap |
| `addLiquidity(pool, amount0, amount1, ethValue, callData)` | Add liquidity to pool |
| `removeLiquidity(pool, liquidity, callData)` | Remove liquidity from pool |
| `bridgeTokens(bridge, token, amount, targetChain, ethValue, callData)` | Cross-chain bridge |
| `rawCall(target, callData)` | Arbitrary external call (no ETH) |
| `rawCallWithValue(target, value, callData)` | Arbitrary external call with ETH |

---

## TokenClaimModule

Handles all token-related operations from the vault context. Supports ERC-20, ERC-721, and ERC-1155 standards including airdrops and MerkleDistributor claims.

| Function | Description |
|---|---|
| `transferERC20(token, recipient, amount)` | Transfer ERC-20 from vault |
| `approveERC20(token, spender, amount)` | ERC-20 approve |
| `sweepERC20(token, recipient)` | Transfer entire vault ERC-20 balance |
| `transferFromERC20(token, from, amount)` | Pull tokens from approved address to vault |
| `claimERC20(claimContract, callData)` | Arbitrary claim call |
| `claimWithMerkle(distributor, index, amount, merkleProof)` | Standard MerkleDistributor claim |
| `claimAndSweep(claimContract, claimCallData, token, recipient)` | Atomic claim + sweep |
| `transferERC721(token, recipient, tokenId)` | ERC-721 safeTransferFrom vault |
| `transferERC1155(token, recipient, tokenId, amount, data)` | ERC-1155 safeTransferFrom vault |
| `setApprovalForAll(token, operator, approved)` | ERC-721/1155 setApprovalForAll |

---

## Module Routing Architecture

The vault supports two execution paths for dispatching module calls:

**Path 1 — Orchestrator (owner-signed EIP-712):**
`orchestrator.execute(vault, req, sig)` routes through `ExecutionModule.execute()` only. This path cannot invoke AdvancedExecutionModule or TokenClaimModule selectors directly.

**Path 2 — Session Key (delegated key signs SessionExecution):**
`vault.executeSessionKey(req, sig)` looks up `_moduleRegistry[selector]` and delegatecalls directly to whichever module is registered — including AEM and TCM. This is the correct path for all advanced module operations.

---

## File Structure

```
eoa-delegatecall-system/
├── contracts/
│   ├── StorageLayout.sol           # Shared storage slot definitions
│   ├── SignatureVerifier.sol       # EIP-712 typed data signing library
│   ├── NonceManager.sol            # Sequential + bitmap nonce management
│   ├── ExecutionModule.sol         # Core execution logic (delegatecall target)
│   ├── SessionKeyManager.sol       # Session key grant/revoke/execute logic
│   ├── AdvancedExecutionModule.sol # Contract deploy, DeFi, staking, permit
│   ├── TokenClaimModule.sol        # ERC-20/721/1155 + airdrop operations
│   ├── EOAVault.sol                # Main proxy vault (holds ETH + state)
│   ├── Orchestrator.sol            # Policy + routing layer
│   ├── VaultFactory.sol            # CREATE2 factory + system bootstrapper
│   └── mocks/
│       ├── MockCounter.sol
│       ├── MockERC20.sol
│       ├── MockERC20Permit.sol
│       ├── MockERC721.sol
│       ├── MockERC1155.sol
│       ├── MockMerkleDistributor.sol
│       └── MockReceiver.sol
├── test/
│   ├── EOAVaultSystem.test.js          # 53 core system tests
│   ├── SessionKeyManager.test.js       # 32 session key tests
│   ├── AdvancedExecutionModule.test.js # 29 AEM tests
│   └── TokenClaimModule.test.js        # 21 TCM tests (129 total)
├── hardhat.config.js                   # viaIR enabled for stack depth
├── package.json
└── README.md
```

---

## Security Considerations

1. **Module Upgrades** — Registering a new module is owner-only, but modules run with full access to vault storage. Always audit modules before registration.

2. **Delegate Revocation** — `revokeDelegate(module)` immediately prevents execution through that module. Use this as an emergency brake.

3. **Emergency Nonce Advance** — If a signing key is compromised, call `emergencyAdvanceNonce(N)` to skip `N` nonce positions, invalidating all previously signed requests with those nonces.

4. **Timelock Bypass** — Operations under the value threshold and without a policy set bypass the timelock. Set an appropriate `timelockValueThreshold` at deployment.

5. **Reentrancy** — `executeFromOrchestrator` and `executeDirectModule` have a `nonReentrant` guard. `ExecutionModule.execute()` uses `onlyDelegatecall` to ensure it never runs as a direct call.

6. **Signature Malleability** — `SignatureVerifier` rejects signatures with `s > N/2` (high-s form) to prevent malleable signatures from bypassing replay protection.