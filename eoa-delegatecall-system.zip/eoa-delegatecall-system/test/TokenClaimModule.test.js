// SPDX-License-Identifier: MIT
/**
 * @title TokenClaimModule Tests
 * @notice Tests for ERC-20/721/1155 token operations via delegatecall from EOAVault.
 *
 * Architecture note:
 *   TokenClaimModule functions are reached via vault.executeSessionKey() which routes
 *   directly via _moduleRegistry[selector] and delegatecalls to the module.
 */
const { expect } = require("chai");
const { ethers } = require("hardhat");
const { time }   = require("@nomicfoundation/hardhat-network-helpers");

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function deploySystem() {
  const [admin, owner, sessionKeyWallet, recipient, stranger] = await ethers.getSigners();

  const Factory = await ethers.getContractFactory("VaultFactory");
  const factory = await Factory.deploy(admin.address, 0, ethers.parseEther("100"));
  await factory.waitForDeployment();

  await factory.connect(owner).deployVault(ethers.ZeroHash);
  const vaultAddr       = (await factory.getOwnerVaults(owner.address))[0];
  const vault           = await ethers.getContractAt("EOAVault", vaultAddr);
  const orchestrator    = await ethers.getContractAt("Orchestrator", await factory.orchestrator());
  const tokenClaimModule = await ethers.getContractAt("TokenClaimModule", await factory.tokenClaimModule());

  return { factory, vault, orchestrator, tokenClaimModule, admin, owner, sessionKeyWallet, recipient, stranger };
}

/**
 * Execute a TokenClaimModule (or AdvancedExecutionModule) function via session key.
 * Grants an unrestricted session key on first use, then signs + submits.
 */
async function execViaSessionKey(ctx, data, { value = 0n, relayer } = {}) {
  const { vault, owner, sessionKeyWallet, stranger } = ctx;
  const vaultAddr = await vault.getAddress();
  const chainId   = (await ethers.provider.getNetwork()).chainId;
  const now       = BigInt(await time.latest());
  const nonce     = await vault.getSessionKeyNonce(sessionKeyWallet.address);

  // Grant key if not already active
  const isActive = (await vault.getSessionKey(sessionKeyWallet.address)).active;
  if (!isActive) {
    await vault.connect(owner).grantSessionKey(
      sessionKeyWallet.address,
      now - 10n,           // validAfter: already valid
      0n,                  // validUntil: never expires
      value > 0n ? value * 2n : 0n,  // maxValuePerCall
      0n,                  // maxValueTotal: unlimited
      0n,                  // maxUsageCount: unlimited
      [],                  // allowedSelectors: any
      []                   // allowedTargets: any
    );
  }

  const domain = {
    name:              "EOAVault",
    version:           "1",
    chainId,
    verifyingContract: vaultAddr,
  };

  const SESSION_EXECUTION_TYPES = {
    SessionExecution: [
      { name: "keyAddress", type: "address" },
      { name: "target",     type: "address" },
      { name: "value",      type: "uint256" },
      { name: "data",       type: "bytes"   },
      { name: "nonce",      type: "uint256" },
      { name: "deadline",   type: "uint256" },
      { name: "chainId",    type: "uint256" },
    ],
  };

  const req = {
    keyAddress: sessionKeyWallet.address,
    target:     vaultAddr,
    value,
    data,
    nonce,
    deadline:   now + 3600n,
    chainId,
  };

  const signature = await sessionKeyWallet.signTypedData(domain, SESSION_EXECUTION_TYPES, req);
  const sender    = relayer || stranger;
  return vault.connect(sender).executeSessionKey(req, signature);
}

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("TokenClaimModule", function () {
  let ctx;
  let vaultAddr;

  beforeEach(async function () {
    ctx       = await deploySystem();
    vaultAddr = await ctx.vault.getAddress();
  });

  // ── 1. ERC-20 Operations ────────────────────────────────────────────────────

  describe("1. ERC-20 Operations", function () {

    it("transferERC20: sends tokens from vault to recipient", async function () {
      const { recipient } = ctx;

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const sendAmount = ethers.parseEther("100");

      const TCM    = await ethers.getContractFactory("TokenClaimModule");
      const iface  = TCM.interface;
      const calldata = iface.encodeFunctionData("transferERC20", [
        tokenAddr, recipient.address, sendAmount
      ]);

      const before = await token.balanceOf(recipient.address);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(recipient.address);

      expect(after - before).to.equal(sendAmount);
    });

    it("approveERC20: vault approves spender", async function () {
      const { recipient } = ctx;

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const approveAmount = ethers.parseEther("500");

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("approveERC20", [
        tokenAddr, recipient.address, approveAmount
      ]);

      await execViaSessionKey(ctx, calldata);

      expect(await token.allowance(vaultAddr, recipient.address)).to.equal(approveAmount);
    });

    it("sweepERC20: transfers entire token balance to recipient", async function () {
      const { recipient } = ctx;

      const balance = ethers.parseEther("250");
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, balance);
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("sweepERC20", [tokenAddr, recipient.address]);

      const before = await token.balanceOf(recipient.address);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(recipient.address);

      expect(await token.balanceOf(vaultAddr)).to.equal(0n);
      expect(after - before).to.equal(balance);
    });

    it("sweepERC20: returns 0 when balance is zero", async function () {
      const { recipient } = ctx;

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, 0n);
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("sweepERC20", [tokenAddr, recipient.address]);

      // Should succeed (sweeps 0 tokens) without reverting
      await expect(execViaSessionKey(ctx, calldata)).to.not.be.reverted;
      expect(await token.balanceOf(recipient.address)).to.equal(0n);
    });

    it("transferFromERC20: pulls tokens from another address to vault", async function () {
      const { owner, recipient } = ctx;

      // Mint to recipient, recipient approves vault
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(recipient.address, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const pullAmount = ethers.parseEther("100");

      // recipient approves vault to pull tokens
      await token.connect(recipient).approve(vaultAddr, pullAmount);

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      // transferFromERC20(token, from, amount) — always transfers TO vault (address(this) in delegatecall)
      const calldata = iface.encodeFunctionData("transferFromERC20", [
        tokenAddr, recipient.address, pullAmount
      ]);

      const before = await token.balanceOf(vaultAddr);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(vaultAddr);

      expect(after - before).to.equal(pullAmount);
    });
  });

  // ── 2. ERC-20 Claim Operations ────────────────────────────────────────────

  describe("2. ERC-20 Claim Operations", function () {

    it("claimERC20: arbitrary call to claim contract", async function () {
      const { recipient } = ctx;

      // Deploy a MockERC20 that will serve as both token and claim contract
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(recipient.address, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      // Mint 100 tokens to vault as "claim" (token.mint(vault, 100))
      await token.connect(recipient).approve(vaultAddr, ethers.parseEther("100"));

      // Use claimERC20 to make an arbitrary call to token.mint(vault, 100)
      const mintCalldata = token.interface.encodeFunctionData("mint", [vaultAddr, ethers.parseEther("100")]);

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("claimERC20", [tokenAddr, mintCalldata]);

      const before = await token.balanceOf(vaultAddr);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(vaultAddr);

      expect(after - before).to.equal(ethers.parseEther("100"));
    });

    it("claimWithMerkle: standard MerkleDistributor ABI claim", async function () {
      // Deploy a MockERC20 to be the distributed token, mint tokens to the distributor
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const claimAmount = ethers.parseEther("50");
      // Mint tokens to a temp address, we'll transfer to distributor after deploy
      const token = await MockERC20.deploy(ctx.admin.address, claimAmount);
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      // Deploy MockMerkleDistributor with the token address
      const MockMerkleDistributor = await ethers.getContractFactory("MockMerkleDistributor");
      const distributor           = await MockMerkleDistributor.deploy(tokenAddr);
      await distributor.waitForDeployment();
      const distributorAddr = await distributor.getAddress();

      // Transfer tokens to the distributor so it can distribute them
      await token.connect(ctx.admin).transfer(distributorAddr, claimAmount);

      const index = 0n;
      const proof = [ethers.ZeroHash];

      // claimWithMerkle(distributor, index, amount, merkleProof) — account = vault
      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("claimWithMerkle", [
        distributorAddr, index, claimAmount, proof
      ]);

      const before = await token.balanceOf(vaultAddr);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(vaultAddr);

      expect(after - before).to.equal(claimAmount);
    });

    it("claimAndSweep: claims then sweeps to recipient atomically", async function () {
      const { recipient } = ctx;

      // Deploy a MockERC20 and MockMerkleDistributor that mints on claim
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, ethers.parseEther("0")); // vault starts with 0
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      // The distributor will mint tokens to vault on claim (simplified: just call mint directly)
      // Use claimAndSweep where claim call = mint to vault
      const claimAmount = ethers.parseEther("100");
      const mintCalldata = token.interface.encodeFunctionData("mint", [vaultAddr, claimAmount]);

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("claimAndSweep", [
        tokenAddr,        // claimContract
        mintCalldata,     // claimData
        tokenAddr,        // token to sweep
        recipient.address // sweep to recipient
      ]);

      const before = await token.balanceOf(recipient.address);
      await execViaSessionKey(ctx, calldata);
      const after = await token.balanceOf(recipient.address);

      expect(after - before).to.equal(claimAmount);
    });
  });

  // ── 3. ERC-721 Operations ─────────────────────────────────────────────────

  describe("3. ERC-721 Operations", function () {

    it("transferERC721: sends NFT from vault to recipient", async function () {
      const { recipient } = ctx;

      const MockERC721 = await ethers.getContractFactory("MockERC721");
      const nft        = await MockERC721.deploy();
      await nft.waitForDeployment();
      const nftAddr = await nft.getAddress();

      // Mint token #1 to vault
      await nft.mint(vaultAddr, 1n);
      expect(await nft.ownerOf(1n)).to.equal(vaultAddr);

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("transferERC721", [
        nftAddr, recipient.address, 1n
      ]);

      await execViaSessionKey(ctx, calldata);

      expect(await nft.ownerOf(1n)).to.equal(recipient.address);
    });

    it("setApprovalForAll: vault approves operator for ERC-721 via setApprovalForAll", async function () {
      const { recipient } = ctx;

      const MockERC721 = await ethers.getContractFactory("MockERC721");
      const nft        = await MockERC721.deploy();
      await nft.waitForDeployment();
      const nftAddr = await nft.getAddress();

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("setApprovalForAll", [
        nftAddr, recipient.address, true
      ]);

      await execViaSessionKey(ctx, calldata);

      expect(await nft.isApprovedForAll(vaultAddr, recipient.address)).to.be.true;
    });
  });

  // ── 4. ERC-1155 Operations ────────────────────────────────────────────────

  describe("4. ERC-1155 Operations", function () {

    it("transferERC1155: sends tokens from vault to recipient", async function () {
      const { recipient } = ctx;

      const MockERC1155 = await ethers.getContractFactory("MockERC1155");
      const token1155   = await MockERC1155.deploy();
      await token1155.waitForDeployment();
      const tokenAddr = await token1155.getAddress();

      // Mint token id=1 amount=10 to vault
      await token1155.mint(vaultAddr, 1n, 10n);
      expect(await token1155.balanceOf(vaultAddr, 1n)).to.equal(10n);

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("transferERC1155", [
        tokenAddr, recipient.address, 1n, 5n, "0x"
      ]);

      await execViaSessionKey(ctx, calldata);

      expect(await token1155.balanceOf(recipient.address, 1n)).to.equal(5n);
      expect(await token1155.balanceOf(vaultAddr, 1n)).to.equal(5n);
    });

    it("setApprovalForAll: vault approves operator for ERC-1155 via setApprovalForAll", async function () {
      const { recipient } = ctx;

      const MockERC1155 = await ethers.getContractFactory("MockERC1155");
      const token1155   = await MockERC1155.deploy();
      await token1155.waitForDeployment();
      const tokenAddr = await token1155.getAddress();

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("setApprovalForAll", [
        tokenAddr, recipient.address, true
      ]);

      await execViaSessionKey(ctx, calldata);

      expect(await token1155.isApprovedForAll(vaultAddr, recipient.address)).to.be.true;
    });
  });

  // ── 5. Error Cases ─────────────────────────────────────────────────────────

  describe("5. Error Cases", function () {

    it("claimERC20 reverts on zero address", async function () {
      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("claimERC20", [ethers.ZeroAddress, "0x"]);

      await expect(execViaSessionKey(ctx, calldata))
        .to.be.revertedWithCustomError(ctx.vault, "EOAVault__DelegatecallFailed");
    });

    it("transferERC20 reverts on zero address token", async function () {
      const { recipient } = ctx;
      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("transferERC20", [
        ethers.ZeroAddress, recipient.address, 100n
      ]);

      await expect(execViaSessionKey(ctx, calldata))
        .to.be.revertedWithCustomError(ctx.vault, "EOAVault__DelegatecallFailed");
    });

    it("transferERC20 reverts when token transfer fails (insufficient balance)", async function () {
      const { recipient } = ctx;

      // Deploy token with 0 balance to vault
      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(recipient.address, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const TCM      = await ethers.getContractFactory("TokenClaimModule");
      const iface    = TCM.interface;
      const calldata = iface.encodeFunctionData("transferERC20", [
        tokenAddr, recipient.address, ethers.parseEther("1")  // vault has 0 tokens
      ]);

      await expect(execViaSessionKey(ctx, calldata))
        .to.be.revertedWithCustomError(ctx.vault, "EOAVault__DelegatecallFailed");
    });

    it("TokenClaimModule cannot be called directly (onlyDelegatecall guard)", async function () {
      const { tokenClaimModule, stranger, recipient } = ctx;

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      await token.waitForDeployment();

      await expect(
        tokenClaimModule.connect(stranger).transferERC20(
          await token.getAddress(),
          recipient.address,
          100n
        )
      ).to.be.revertedWith("TokenClaimModule: must be called via delegatecall");
    });
  });

  // ── 6. Module Registration ─────────────────────────────────────────────────

  describe("6. Module Registration", function () {

    it("TokenClaimModule selectors are registered in vault after deployment", async function () {
      const { vault, tokenClaimModule } = ctx;
      const iface = tokenClaimModule.interface;

      const selectors = [
        iface.getFunction("transferERC20").selector,
        iface.getFunction("approveERC20").selector,
        iface.getFunction("sweepERC20").selector,
        iface.getFunction("transferERC721").selector,
        iface.getFunction("transferERC1155").selector,
      ];

      for (const sel of selectors) {
        const module = await vault.getModule(sel);
        expect(module).to.equal(await tokenClaimModule.getAddress());
      }
    });

    it("TokenClaimModule is in delegates whitelist", async function () {
      const { vault, tokenClaimModule } = ctx;
      expect(await vault.isDelegate(await tokenClaimModule.getAddress())).to.be.true;
    });
  });
});