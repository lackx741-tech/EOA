// SPDX-License-Identifier: MIT
/**
 * @title AdvancedExecutionModule Tests
 * @notice Tests for contract deployment, EIP-1271 hash approval, raw calls,
 *         and other advanced vault capabilities.
 *
 * Architecture note:
 *   AdvancedExecutionModule functions MUST be called via delegatecall from the vault.
 *   The vault dispatches delegatecalls via two paths:
 *     1. orchestrator → vault.executeFromOrchestrator(selector, callData) — uses _moduleRegistry
 *        BUT the orchestrator's _routeToVault wraps everything through ExecutionModule.execute(),
 *        so it cannot directly invoke AEM selectors.
 *     2. vault.executeSessionKey(req, sig) — directly looks up _moduleRegistry[selector]
 *        and delegatecalls to the registered module. This is the correct path for AEM tests.
 *
 *   All tests below use executeSessionKey to route to AdvancedExecutionModule functions.
 */
const { expect } = require("chai");
const { ethers } = require("hardhat");
const { time }   = require("@nomicfoundation/hardhat-network-helpers");

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function deploySystem() {
  const [admin, owner, sessionKeyWallet, stranger, recipient] = await ethers.getSigners();

  const Factory = await ethers.getContractFactory("VaultFactory");
  const factory = await Factory.deploy(admin.address, 0, ethers.parseEther("100"));
  await factory.waitForDeployment();

  await factory.connect(owner).deployVault(ethers.ZeroHash);
  const vaultAddr = (await factory.getOwnerVaults(owner.address))[0];
  const vault     = await ethers.getContractAt("EOAVault", vaultAddr);

  const orchestrator = await ethers.getContractAt("Orchestrator", await factory.orchestrator());
  const advModule    = await ethers.getContractAt("AdvancedExecutionModule", await factory.advancedExecutionModule());

  return { factory, vault, orchestrator, advModule, admin, owner, sessionKeyWallet, stranger, recipient };
}

/**
 * Grant an unrestricted session key and sign a SessionExecution request
 * targeting an AdvancedExecutionModule function.
 *
 * @param vault          EOAVault contract instance
 * @param owner          Vault owner signer (grants the key)
 * @param keyWallet      Signer that owns the session key
 * @param data           ABI-encoded AEM function call (e.g. rawCall(...))
 * @param target         Target address for the execution (default: vault address for AEM)
 * @param value          ETH value (default: 0)
 * @param permissions    Optional overrides for grantSessionKey parameters
 */
async function execViaSessionKey(vault, owner, keyWallet, data, target, value = 0n, permissions = {}) {
  const vaultAddr = await vault.getAddress();
  if (!target) target = vaultAddr;  // AEM functions target the vault itself (delegatecall context)

  const now      = BigInt(await time.latest());
  const chainId  = (await ethers.provider.getNetwork()).chainId;
  const nonce    = await vault.getSessionKeyNonce(keyWallet.address);
  const deadline = now + 3600n;

  // Grant session key with no restrictions (unless permissions override)
  const isActive = (await vault.getSessionKey(keyWallet.address)).active;
  if (!isActive) {
    await vault.connect(owner).grantSessionKey(
      keyWallet.address,
      permissions.validAfter  !== undefined ? permissions.validAfter  : now - 10n,
      permissions.validUntil  !== undefined ? permissions.validUntil  : 0n,  // 0 = no expiry
      permissions.maxValuePerCall !== undefined ? permissions.maxValuePerCall : (value > 0n ? value * 2n : 0n),
      permissions.maxValueTotal   !== undefined ? permissions.maxValueTotal   : 0n,
      permissions.maxUsageCount   !== undefined ? permissions.maxUsageCount   : 0n,  // 0 = unlimited
      permissions.allowedSelectors !== undefined ? permissions.allowedSelectors : [],
      permissions.allowedTargets   !== undefined ? permissions.allowedTargets   : []
    );
  }

  const domain = {
    name:              "EOAVault",
    version:           "1",
    chainId:           chainId,
    verifyingContract: vaultAddr,
  };

  const SESSION_EXECUTION_TYPES = {
    SessionExecution: [
      { name: "keyAddress", type: "address" },
      { name: "target",     type: "address" },
      { name: "value",      type: "uint256" },
      { name: "data",       type: "bytes"   },
      { name: "nonce",      type: "uint256" },
      { name: "deadline",   type: "uint256" },
      { name: "chainId",    type: "uint256" },
    ],
  };

  const req = {
    keyAddress: keyWallet.address,
    target,
    value,
    data,
    nonce,
    deadline,
    chainId,
  };

  const signature = await keyWallet.signTypedData(domain, SESSION_EXECUTION_TYPES, req);
  return vault.connect(stranger_).executeSessionKey(req, signature);
}

// We need a "relayer" — anyone can call executeSessionKey
let stranger_;

// ─── Tests ───────────────────────────────────────────────────────────────────

describe("AdvancedExecutionModule", function () {
  let ctx;
  let vaultAddr;

  beforeEach(async function () {
    ctx = await deploySystem();
    vaultAddr = await ctx.vault.getAddress();
    stranger_ = ctx.stranger;
  });

  // ── 1. Module Registration ─────────────────────────────────────────────────

  describe("1. Module Registration", function () {

    it("AdvancedExecutionModule selectors are registered in vault", async function () {
      const { vault, advModule } = ctx;
      const iface = advModule.interface;

      const selectors = [
        iface.getFunction("rawCall").selector,
        iface.getFunction("rawCallWithValue").selector,
        iface.getFunction("deployContract").selector,
        iface.getFunction("deployContract2").selector,
        iface.getFunction("approveHash").selector,
        iface.getFunction("revokeHash").selector,
      ];

      for (const sel of selectors) {
        const module = await vault.getModule(sel);
        expect(module).to.equal(await advModule.getAddress());
      }
    });

    it("AdvancedExecutionModule is in delegates whitelist", async function () {
      const { vault, advModule } = ctx;
      expect(await vault.isDelegate(await advModule.getAddress())).to.be.true;
    });

    it("Cannot call AdvancedExecutionModule directly (onlyDelegatecall guard)", async function () {
      const { advModule, stranger } = ctx;
      await expect(
        advModule.connect(stranger).rawCall(stranger.address, "0x")
      ).to.be.revertedWith("AdvancedExecutionModule: must be called via delegatecall");
    });
  });

  // ── 2. Raw Calls ───────────────────────────────────────────────────────────

  describe("2. Raw Calls", function () {

    it("rawCall: executes arbitrary call to a target contract", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const receiver     = await MockReceiver.deploy();
      await receiver.waitForDeployment();
      const receiverAddr = await receiver.getAddress();

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("rawCall", [receiverAddr, "0xdeadbeef"]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      expect(await receiver.callCount()).to.equal(1n);
      expect(await receiver.lastCallData()).to.equal("0xdeadbeef");
    });

    it("rawCallWithValue: forwards ETH with call", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      // Fund vault
      await owner.sendTransaction({ to: vaultAddr, value: ethers.parseEther("1") });

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const receiver     = await MockReceiver.deploy();
      await receiver.waitForDeployment();
      const receiverAddr = await receiver.getAddress();

      const AEM        = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface      = AEM.interface;
      const sendAmount = ethers.parseEther("0.5");
      const calldata   = iface.encodeFunctionData("rawCallWithValue", [receiverAddr, sendAmount, "0x"]);

      const before = await ethers.provider.getBalance(receiverAddr);
      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);
      const after = await ethers.provider.getBalance(receiverAddr);

      expect(after - before).to.equal(sendAmount);
    });

    it("rawCall reverts on zero target address", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("rawCall", [ethers.ZeroAddress, "0x"]);

      // The delegatecall failure bubbles up as EOAVault__DelegatecallFailed
      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, calldata)
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });
  });

  // ── 3. Contract Deployment ─────────────────────────────────────────────────

  describe("3. Contract Deployment", function () {

    it("deployContract: deploys a contract from vault using CREATE", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      // Minimal bytecode: PUSH1 0x00 PUSH1 0x00 RETURN → returns empty constructor
      const initBytecode = "0x6000600052";

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("deployContract", [initBytecode, 0n]);

      const nonce_  = await vault.getSessionKeyNonce(sessionKeyWallet.address);
      const chainId = (await ethers.provider.getNetwork()).chainId;
      const now_    = BigInt(await time.latest());

      // Grant key if not active
      const isActive = (await vault.getSessionKey(sessionKeyWallet.address)).active;
      if (!isActive) {
        await vault.connect(owner).grantSessionKey(sessionKeyWallet.address, now_ - 10n, 0n, 0n, 0n, 0n, [], []);
      }

      const domain = { name: "EOAVault", version: "1", chainId, verifyingContract: vaultAddr };
      const types = {
        SessionExecution: [
          { name: "keyAddress", type: "address" },
          { name: "target",     type: "address" },
          { name: "value",      type: "uint256" },
          { name: "data",       type: "bytes"   },
          { name: "nonce",      type: "uint256" },
          { name: "deadline",   type: "uint256" },
          { name: "chainId",    type: "uint256" },
        ],
      };
      const req = {
        keyAddress: sessionKeyWallet.address,
        target:     vaultAddr,
        value:      0n,
        data:       calldata,
        nonce:      nonce_,
        deadline:   now_ + 3600n,
        chainId,
      };
      const sig = await sessionKeyWallet.signTypedData(domain, types, req);

      const tx = await vault.connect(ctx.stranger).executeSessionKey(req, sig);
      const rc = await tx.wait();

      // Deployed address comes from return data; just confirm tx succeeded
      expect(rc.status).to.equal(1);
    });

    it("deployContract2: deploys a contract using CREATE2 (deterministic)", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const initBytecode = "0x6000600052";
      const salt         = ethers.keccak256(ethers.toUtf8Bytes("test-salt-1"));

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("deployContract2", [initBytecode, salt, 0n]);

      const nonce_  = await vault.getSessionKeyNonce(sessionKeyWallet.address);
      const chainId = (await ethers.provider.getNetwork()).chainId;
      const now_    = BigInt(await time.latest());

      const isActive = (await vault.getSessionKey(sessionKeyWallet.address)).active;
      if (!isActive) {
        await vault.connect(owner).grantSessionKey(sessionKeyWallet.address, now_ - 10n, 0n, 0n, 0n, 0n, [], []);
      }

      const domain = { name: "EOAVault", version: "1", chainId, verifyingContract: vaultAddr };
      const types  = {
        SessionExecution: [
          { name: "keyAddress", type: "address" },
          { name: "target",     type: "address" },
          { name: "value",      type: "uint256" },
          { name: "data",       type: "bytes"   },
          { name: "nonce",      type: "uint256" },
          { name: "deadline",   type: "uint256" },
          { name: "chainId",    type: "uint256" },
        ],
      };
      const req = {
        keyAddress: sessionKeyWallet.address,
        target:     vaultAddr,
        value:      0n,
        data:       calldata,
        nonce:      nonce_,
        deadline:   now_ + 3600n,
        chainId,
      };
      const sig = await sessionKeyWallet.signTypedData(domain, types, req);

      const tx = await vault.connect(ctx.stranger).executeSessionKey(req, sig);
      const rc = await tx.wait();
      expect(rc.status).to.equal(1);
    });

    it("deployContract reverts with empty bytecode", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("deployContract", ["0x", 0n]);

      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, calldata)
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });
  });

  // ── 4. EIP-1271 Hash Approval ──────────────────────────────────────────────

  describe("4. EIP-1271 Hash Approval", function () {

    it("approveHash: pre-approves a hash for isValidSignature", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const testHash = ethers.id("test-hash-for-approval");

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("approveHash", [testHash]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      // approveHash sets _approvedHashes[hash] = true → isValidSignature returns magic
      expect(await vault.isValidSignature(testHash, "0x")).to.equal("0x1626ba7e");
    });

    it("revokeHash: revokes a previously approved hash", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const testHash = ethers.id("hash-to-revoke");

      const AEM   = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface = AEM.interface;

      // First approve
      await execViaSessionKey(vault, owner, sessionKeyWallet, iface.encodeFunctionData("approveHash", [testHash]));
      expect(await vault.isValidSignature(testHash, "0x")).to.equal("0x1626ba7e");

      // Then revoke
      await execViaSessionKey(vault, owner, sessionKeyWallet, iface.encodeFunctionData("revokeHash", [testHash]));
      expect(await vault.isValidSignature(testHash, "0x")).to.equal("0xffffffff");
    });

    it("approveHash reverts if hash already approved", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const testHash = ethers.id("double-approve");
      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;

      // First approve (ok)
      await execViaSessionKey(vault, owner, sessionKeyWallet, iface.encodeFunctionData("approveHash", [testHash]));

      // Second approve reverts via delegatecall fail
      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, iface.encodeFunctionData("approveHash", [testHash]))
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });

    it("revokeHash reverts if hash not approved", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const testHash = ethers.id("not-approved");
      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;

      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, iface.encodeFunctionData("revokeHash", [testHash]))
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });

    it("isValidSignature returns magic for owner ECDSA signature", async function () {
      const { vault, owner } = ctx;

      // Hardhat account[1] (owner in test) private key (deterministic):
      const OWNER_KEY   = "0x59c6995e998f97a5a0044966f0945389dc9e86dae88c7a8412f4603b6b78690d";
      const ownerWallet = new ethers.Wallet(OWNER_KEY);
      const hash        = ethers.id("owner signed message");

      if ((await owner.getAddress()).toLowerCase() === ownerWallet.address.toLowerCase()) {
        const rawSig   = ownerWallet.signingKey.sign(hash);
        const sigBytes = ethers.Signature.from(rawSig).serialized;
        expect(await vault.isValidSignature(hash, sigBytes)).to.equal("0x1626ba7e");
      } else {
        // Key doesn't match — just verify the call works
        expect(await vault.isValidSignature(hash, "0x")).to.equal("0xffffffff");
        this.skip();
      }
    });

    it("isValidSignature returns 0xffffffff for non-owner ECDSA signature", async function () {
      const { vault } = ctx;
      const strangerWallet = new ethers.Wallet("0x5de4111afa1a4b94908f83103eb1f1706367c2e68ca870fc3fb9a804cdab365a");
      const hash           = ethers.id("stranger signed message");
      const rawSig         = strangerWallet.signingKey.sign(hash);
      const sigBytes       = ethers.Signature.from(rawSig).serialized;
      expect(await vault.isValidSignature(hash, sigBytes)).to.equal("0xffffffff");
    });
  });

  // ── 5. Staking Operations ──────────────────────────────────────────────────

  describe("5. Staking Operations", function () {

    it("stakeETH: calls staking contract with ETH value", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      // Fund vault
      await owner.sendTransaction({ to: vaultAddr, value: ethers.parseEther("1") });

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const staking      = await MockReceiver.deploy();
      await staking.waitForDeployment();
      const stakingAddr  = await staking.getAddress();

      const stakeAmount = ethers.parseEther("0.5");
      const stakeData   = "0x"; // simplified

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("stakeETH", [stakingAddr, stakeAmount, stakeData]);

      const before = await ethers.provider.getBalance(stakingAddr);
      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata, vaultAddr, 0n,
        { maxValuePerCall: stakeAmount });
      const after = await ethers.provider.getBalance(stakingAddr);

      expect(after - before).to.equal(stakeAmount);
    });

    it("unstakeETH: calls staking contract for unstake", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const staking      = await MockReceiver.deploy();
      await staking.waitForDeployment();
      const stakingAddr  = await staking.getAddress();

      const unstakeData = "0xaabbccdd";

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("unstakeETH", [stakingAddr, 0n, unstakeData]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      expect(await staking.callCount()).to.equal(1n);
    });

    it("claimStakingRewards: calls rewards contract", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const rewards      = await MockReceiver.deploy();
      await rewards.waitForDeployment();
      const rewardsAddr  = await rewards.getAddress();

      const claimData = "0xaabb";

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("claimStakingRewards", [rewardsAddr, claimData]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      expect(await rewards.callCount()).to.equal(1n);
    });
  });

  // ── 6. DeFi Operations ─────────────────────────────────────────────────────

  describe("6. DeFi Operations", function () {

    it("swapExact: calls router with swap calldata", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const router       = await MockReceiver.deploy();
      await router.waitForDeployment();
      const routerAddr   = await router.getAddress();

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const tokenIn   = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      const tokenOut  = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      await tokenIn.waitForDeployment();
      await tokenOut.waitForDeployment();

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const swapCalldata = "0x12345678";  // mock calldata
      const calldata = iface.encodeFunctionData("swapExact", [
        routerAddr,
        await tokenIn.getAddress(),
        await tokenOut.getAddress(),
        ethers.parseEther("100"),
        0n,                           // ethValue: no ETH for token swap
        swapCalldata
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);
      expect(await router.callCount()).to.equal(1n);
    });

    it("addLiquidity: calls pool with add liquidity calldata", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const pool         = await MockReceiver.deploy();
      await pool.waitForDeployment();
      const poolAddr     = await pool.getAddress();

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const addCalldata = "0xabcdef";
      const calldata = iface.encodeFunctionData("addLiquidity", [
        poolAddr,
        ethers.parseEther("100"),   // amount0
        ethers.parseEther("100"),   // amount1
        0n,                          // ethValue
        addCalldata
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);
      expect(await pool.callCount()).to.equal(1n);
    });

    it("removeLiquidity: calls pool to remove liquidity", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const pool         = await MockReceiver.deploy();
      await pool.waitForDeployment();
      const poolAddr     = await pool.getAddress();

      const AEM          = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface        = AEM.interface;
      const removeCalldata = "0x99887766";
      const calldata     = iface.encodeFunctionData("removeLiquidity", [
        poolAddr,
        ethers.parseEther("50"),   // liquidity amount
        removeCalldata
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);
      expect(await pool.callCount()).to.equal(1n);
    });

    it("bridgeTokens: calls bridge contract with token bridge calldata", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const bridge       = await MockReceiver.deploy();
      await bridge.waitForDeployment();
      const bridgeAddr   = await bridge.getAddress();

      const MockERC20 = await ethers.getContractFactory("MockERC20");
      const token     = await MockERC20.deploy(vaultAddr, ethers.parseEther("1000"));
      await token.waitForDeployment();

      const AEM          = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface        = AEM.interface;
      const bridgeCalldata = "0xffeeddcc";
      const calldata     = iface.encodeFunctionData("bridgeTokens", [
        bridgeAddr,
        await token.getAddress(),
        ethers.parseEther("50"),
        137n,                        // targetChain (e.g. Polygon)
        0n,                          // ethValue
        bridgeCalldata
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);
      expect(await bridge.callCount()).to.equal(1n);
    });
  });

  // ── 7. ERC-20 Permit ───────────────────────────────────────────────────────

  describe("7. ERC-20 Permit", function () {

    it("permitERC20: calls permit on an EIP-2612 token", async function () {
      const { vault, owner, sessionKeyWallet, recipient } = ctx;

      const MockERC20Permit = await ethers.getContractFactory("MockERC20Permit");
      const token           = await MockERC20Permit.deploy(vaultAddr, ethers.parseEther("1000"));
      await token.waitForDeployment();
      const tokenAddr = await token.getAddress();

      const spender  = recipient.address;
      const amount   = ethers.parseEther("100");
      const deadline = BigInt(Math.floor(Date.now() / 1000)) + 3600n;
      const v        = 27;
      const r        = ethers.ZeroHash;
      const s        = ethers.ZeroHash;

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("permitERC20", [
        tokenAddr, spender, amount, deadline, v, r, s
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      // MockERC20Permit.permit just sets allowance — verify
      expect(await token.allowance(vaultAddr, spender)).to.equal(amount);
    });
  });

  // ── 8. Defensive Checks ────────────────────────────────────────────────────

  describe("8. Defensive Checks", function () {

    it("rawCallWithValue reverts when vault has insufficient ETH", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      // Don't fund vault — it has 0 ETH
      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const receiver     = await MockReceiver.deploy();
      await receiver.waitForDeployment();

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("rawCallWithValue", [
        await receiver.getAddress(),
        ethers.parseEther("1"),
        "0x"
      ]);

      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, calldata)
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });

    it("stakeETH reverts on zero address staking contract", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("stakeETH", [ethers.ZeroAddress, 0n, "0x"]);

      await expect(
        execViaSessionKey(vault, owner, sessionKeyWallet, calldata)
      ).to.be.revertedWithCustomError(vault, "EOAVault__DelegatecallFailed");
    });

    it("unstakeETH is called exactly once (no double-call bug)", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const MockReceiver = await ethers.getContractFactory("MockReceiver");
      const staking      = await MockReceiver.deploy();
      await staking.waitForDeployment();

      const AEM      = await ethers.getContractFactory("AdvancedExecutionModule");
      const iface    = AEM.interface;
      const calldata = iface.encodeFunctionData("unstakeETH", [
        await staking.getAddress(),
        0n,
        "0xaabbccdd"
      ]);

      await execViaSessionKey(vault, owner, sessionKeyWallet, calldata);

      // Critical: must be exactly 1, not 2 (verifies the double-call bug is fixed)
      expect(await staking.callCount()).to.equal(1n);
    });

    it("predictDeployAddress returns deterministic address for CREATE2", async function () {
      const { vault, owner, sessionKeyWallet } = ctx;

      const initBytecode = "0x6000600052";
      const salt         = ethers.keccak256(ethers.toUtf8Bytes("predict-test"));
      const bytecodeHash = ethers.keccak256(initBytecode);

      // predictDeployAddress has onlyDelegatecall guard, so call via session key
      // and capture result via rawCall returning the ABI-encoded predicted address.
      // Alternatively, verify the CREATE2 formula directly in JS.
      // The contract uses: keccak256(0xff ++ deployer ++ salt ++ bytecodeHash)
      const predicted = ethers.getCreate2Address(vaultAddr, salt, bytecodeHash);
      expect(ethers.isAddress(predicted)).to.be.true;
      expect(predicted).to.not.equal(ethers.ZeroAddress);
    });
  });
});