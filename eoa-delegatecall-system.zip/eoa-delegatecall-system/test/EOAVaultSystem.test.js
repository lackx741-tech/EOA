/**
 * EOA DelegateCall System — Comprehensive Test Suite
 * ════════════════════════════════════════════════════
 *
 * Tests cover:
 *  1. Deployment & initialization
 *  2. EIP-712 signature verification
 *  3. Nonce management & replay protection
 *  4. Single execution via orchestrator
 *  5. Batch execution
 *  6. Timelock gating
 *  7. Emergency controls (pause, nonce advance)
 *  8. Access control enforcement
 *  9. Reentrancy protection
 * 10. Storage layout integrity
 * 11. Module registry routing
 * 12. ETH send operations
 */

const { expect }         = require("chai");
const { ethers }         = require("hardhat");
const { loadFixture }    = require("@nomicfoundation/hardhat-toolbox/network-helpers");
const { time }           = require("@nomicfoundation/hardhat-toolbox/network-helpers");

// ─────────────────────────────────────────────────────────────────────────────
// TEST HELPERS
// ─────────────────────────────────────────────────────────────────────────────

const TIMELOCK_DELAY     = 24 * 60 * 60;          // 24 hours
const TIMELOCK_THRESHOLD = ethers.parseEther("1"); // 1 ETH
const VAULT_SALT         = ethers.keccak256(ethers.toUtf8Bytes("test-vault-v1"));
const DEADLINE_OFFSET    = 30 * 60;               // 30 minutes

/**
 * Builds an EIP-712 domain for the given vault
 */
function buildDomain(chainId, vaultAddress) {
    return {
        name:              "EOAVault",
        version:           "1",
        chainId:           chainId,
        verifyingContract: vaultAddress,
    };
}

/**
 * EIP-712 type for ExecutionRequest
 */
const EXECUTION_REQUEST_TYPES = {
    ExecutionRequest: [
        { name: "target",   type: "address" },
        { name: "value",    type: "uint256" },
        { name: "data",     type: "bytes"   },
        { name: "nonce",    type: "uint256" },
        { name: "deadline", type: "uint256" },
        { name: "chainId",  type: "uint256" },
    ],
};

const BATCH_EXECUTION_TYPES = {
    ExecutionRequest: [
        { name: "target",   type: "address" },
        { name: "value",    type: "uint256" },
        { name: "data",     type: "bytes"   },
        { name: "nonce",    type: "uint256" },
        { name: "deadline", type: "uint256" },
        { name: "chainId",  type: "uint256" },
    ],
    BatchExecution: [
        { name: "operations", type: "ExecutionRequest[]" },
        { name: "nonce",      type: "uint256" },
        { name: "deadline",   type: "uint256" },
        { name: "chainId",    type: "uint256" },
    ],
};

/**
 * Builds and signs an ExecutionRequest
 */
async function buildAndSign(signer, vaultAddr, chainId, overrides = {}) {
    const nonce    = overrides.nonce    ?? 0;
    const deadline = overrides.deadline ?? (Math.floor(Date.now() / 1000) + DEADLINE_OFFSET);
    const target   = overrides.target   ?? ethers.ZeroAddress;
    const value    = overrides.value    ?? 0n;
    const data     = overrides.data     ?? "0x";

    const req = { target, value, data, nonce, deadline, chainId };
    const domain = buildDomain(chainId, vaultAddr);

    const signature = await signer.signTypedData(domain, EXECUTION_REQUEST_TYPES, req);
    return { req, signature };
}

/**
 * Computes operation ID (must match on-chain logic)
 */
function computeOpId(req) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(
        ["address","uint256","bytes32","uint256","uint256","uint256"],
        [
            req.target,
            req.value,
            ethers.keccak256(
                typeof req.data === "string" ? ethers.getBytes(req.data) : req.data
            ),
            req.nonce,
            req.deadline,
            req.chainId,
        ]
    ));
}

// ─────────────────────────────────────────────────────────────────────────────
// FIXTURE — Deploy full system
// ─────────────────────────────────────────────────────────────────────────────

async function deploySystemFixture() {
    const [deployer, eoaOwner, otherUser, attacker, recipient] =
        await ethers.getSigners();

    const network = await ethers.provider.getNetwork();
    const chainId = Number(network.chainId);

    // 1. Deploy VaultFactory (deploys Orchestrator + ExecutionModule inside)
    const VaultFactory = await ethers.getContractFactory("VaultFactory");
    const factory = await VaultFactory.deploy(
        deployer.address,
        TIMELOCK_DELAY,
        TIMELOCK_THRESHOLD
    );
    await factory.waitForDeployment();

    // 2. Get auto-deployed Orchestrator and ExecutionModule
    const orchestratorAddr    = await factory.orchestrator();
    const executionModuleAddr = await factory.executionModule();

    const Orchestrator    = await ethers.getContractFactory("Orchestrator");
    const ExecutionModule = await ethers.getContractFactory("ExecutionModule");

    const orchestrator    = Orchestrator.attach(orchestratorAddr);
    const executionModule = ExecutionModule.attach(executionModuleAddr);

    // 3. Deploy vault for eoaOwner via factory
    const predictedVault = await factory.predictVaultAddress(eoaOwner.address, VAULT_SALT);

    const deployTx = await factory.connect(eoaOwner).deployVault(VAULT_SALT);
    await deployTx.wait();

    const vaults = await factory.getOwnerVaults(eoaOwner.address);
    const vaultAddr = vaults[0];

    const EOAVault = await ethers.getContractFactory("EOAVault");
    const vault    = EOAVault.attach(vaultAddr);

    // 4. Fund vault with 1 ETH
    await deployer.sendTransaction({
        to:    vaultAddr,
        value: ethers.parseEther("1.0"),
    });

    return {
        factory,
        orchestrator,
        executionModule,
        vault,
        vaultAddr,
        orchestratorAddr,
        executionModuleAddr,
        deployer,
        eoaOwner,
        otherUser,
        attacker,
        recipient,
        chainId,
        predictedVault,
    };
}

// ─────────────────────────────────────────────────────────────────────────────
// TEST SUITE
// ─────────────────────────────────────────────────────────────────────────────

describe("EOA DelegateCall System", function () {

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 1: DEPLOYMENT & INITIALIZATION
    // ─────────────────────────────────────────────────────────────────────────
    describe("1. Deployment & Initialization", function () {

        it("Factory deploys Orchestrator and ExecutionModule", async function () {
            const { factory, orchestratorAddr, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            expect(orchestratorAddr).to.not.equal(ethers.ZeroAddress);
            expect(executionModuleAddr).to.not.equal(ethers.ZeroAddress);
            expect(await factory.totalVaults()).to.equal(1n);
        });

        it("Vault is initialized with correct owner and orchestrator", async function () {
            const { vault, eoaOwner, orchestratorAddr } =
                await loadFixture(deploySystemFixture);

            expect(await vault.owner()).to.equal(eoaOwner.address);
            expect(await vault.orchestrator()).to.equal(orchestratorAddr);
            expect(await vault.getNonce()).to.equal(0n);
            expect(await vault.isPaused()).to.be.false;
        });

        it("CREATE2 vault address matches prediction", async function () {
            const { vaultAddr, predictedVault } =
                await loadFixture(deploySystemFixture);

            expect(vaultAddr.toLowerCase()).to.equal(predictedVault.toLowerCase());
        });

        it("Vault cannot be initialized twice", async function () {
            const { vault, eoaOwner, orchestratorAddr } =
                await loadFixture(deploySystemFixture);

            await expect(
                vault.initialize(eoaOwner.address, orchestratorAddr, [], ethers.ZeroAddress)
            ).to.be.revertedWithCustomError(vault, "EOAVault__AlreadyInitialized");
        });

        it("ExecutionModule selectors are registered in vault", async function () {
            const { vault, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            const executeSelector = ethers.id("execute(address,uint256,bytes,bool)").slice(0, 10);
            const batchSelector   = ethers.id("executeBatch(address[],uint256[],bytes[],bool)").slice(0, 10);

            const execModule  = await vault.getModule(executeSelector);
            const batchModule = await vault.getModule(batchSelector);

            expect(execModule.toLowerCase()).to.equal(executionModuleAddr.toLowerCase());
            expect(batchModule.toLowerCase()).to.equal(executionModuleAddr.toLowerCase());
        });

        it("Vault is registered with orchestrator", async function () {
            const { orchestrator, vaultAddr } =
                await loadFixture(deploySystemFixture);

            expect(await orchestrator.registeredVaults(vaultAddr)).to.be.true;
        });

        it("Vault receives ETH via receive()", async function () {
            const { vault, vaultAddr, deployer } =
                await loadFixture(deploySystemFixture);

            const balanceBefore = await ethers.provider.getBalance(vaultAddr);

            await deployer.sendTransaction({
                to:    vaultAddr,
                value: ethers.parseEther("0.5"),
            });

            const balanceAfter = await ethers.provider.getBalance(vaultAddr);
            expect(balanceAfter - balanceBefore).to.equal(ethers.parseEther("0.5"));
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 2: SIGNATURE VERIFICATION
    // ─────────────────────────────────────────────────────────────────────────
    describe("2. EIP-712 Signature Verification", function () {

        it("getExecutionDigest returns correct EIP-712 digest", async function () {
            const { vault, vaultAddr, chainId } =
                await loadFixture(deploySystemFixture);

            const req = {
                target:   ethers.ZeroAddress,
                value:    0n,
                data:     "0x",
                nonce:    0n,
                deadline: Math.floor(Date.now() / 1000) + 3600,
                chainId:  chainId,
            };

            const digest = await vault.getExecutionDigest(req);
            expect(digest).to.have.length(66); // 0x + 64 hex chars
            expect(digest).to.not.equal(ethers.ZeroHash);
        });

        it("Orchestrator rejects wrong signer", async function () {
            const { orchestrator, vault, vaultAddr, chainId, attacker, eoaOwner } =
                await loadFixture(deploySystemFixture);

            // attacker signs (wrong signer)
            const { req, signature } = await buildAndSign(
                attacker, vaultAddr, chainId,
                { target: attacker.address }
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__InvalidSignature");
        });

        it("Orchestrator rejects tampered request (wrong target)", async function () {
            const { orchestrator, vaultAddr, chainId, eoaOwner, attacker } =
                await loadFixture(deploySystemFixture);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: eoaOwner.address }
            );

            // Tamper: change target to attacker
            const tamperedReq = { ...req, target: attacker.address };

            await expect(
                orchestrator.execute(vaultAddr, tamperedReq, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__InvalidSignature");
        });

        it("Orchestrator rejects tampered value", async function () {
            const { orchestrator, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address, value: ethers.parseEther("0.01") }
            );

            const tamperedReq = { ...req, value: ethers.parseEther("1.0") };

            await expect(
                orchestrator.execute(vaultAddr, tamperedReq, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__InvalidSignature");
        });

        it("Orchestrator rejects wrong chainId", async function () {
            const { orchestrator, vaultAddr, eoaOwner } =
                await loadFixture(deploySystemFixture);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, 999999, // wrong chainId
                { target: eoaOwner.address }
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__ChainIdMismatch");
        });

        it("simulateExecution returns valid for correct signature", async function () {
            const { orchestrator, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address }
            );

            const [valid, reason] = await orchestrator.simulateExecution(
                vaultAddr, req, signature
            );

            expect(valid).to.be.true;
            expect(reason).to.equal("");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 3: NONCE MANAGEMENT & REPLAY PROTECTION
    // ─────────────────────────────────────────────────────────────────────────
    describe("3. Nonce Management & Replay Protection", function () {

        it("getNonce starts at 0", async function () {
            const { vault } = await loadFixture(deploySystemFixture);
            expect(await vault.getNonce()).to.equal(0n);
        });

        it("Orchestrator rejects wrong nonce (too high)", async function () {
            const { orchestrator, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address, nonce: 999 } // wrong nonce
            );

            // Wrong nonce: Orchestrator validates nonce against vault.getNonce() before
            // routing. Since vault nonce=0 but req.nonce=999, Orchestrator rejects early
            // with Orchestrator__NonceMismatch(0, 999).
            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__NonceMismatch");
        });

        it("Rejects expired deadline", async function () {
            const { orchestrator, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            const expiredDeadline = Math.floor(Date.now() / 1000) - 3600; // 1 hour ago

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address, deadline: expiredDeadline }
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__DeadlineExpired");
        });

        it("emergencyAdvanceNonce invalidates pending requests", async function () {
            const { vault, eoaOwner } = await loadFixture(deploySystemFixture);

            const nonceBefore = await vault.getNonce();
            await vault.connect(eoaOwner).emergencyAdvanceNonce(10);
            const nonceAfter = await vault.getNonce();

            expect(nonceAfter).to.equal(nonceBefore + 10n);
        });

        it("simulateValidation detects nonce mismatch", async function () {
            const { vault, chainId } = await loadFixture(deploySystemFixture);

            const deadline = Math.floor(Date.now() / 1000) + 3600;
            const opId     = ethers.keccak256("0x1234");

            const [valid, reason] = await vault.simulateValidation(
                999,      // wrong nonce
                deadline,
                chainId,
                opId
            );

            expect(valid).to.be.false;
            expect(reason).to.equal("INVALID_NONCE");
        });

        it("simulateValidation detects expired deadline", async function () {
            const { vault, chainId } = await loadFixture(deploySystemFixture);

            const expired = Math.floor(Date.now() / 1000) - 100;
            const opId    = ethers.keccak256("0x1234");

            const [valid, reason] = await vault.simulateValidation(
                0n,
                expired,
                chainId,
                opId
            );

            expect(valid).to.be.false;
            expect(reason).to.equal("EXPIRED_DEADLINE");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 4: ACCESS CONTROL
    // ─────────────────────────────────────────────────────────────────────────
    describe("4. Access Control", function () {

        it("Non-orchestrator cannot call executeFromOrchestrator", async function () {
            const { vault, vaultAddr, attacker } =
                await loadFixture(deploySystemFixture);

            const selector  = ethers.id("execute(address,uint256,bytes,bool)").slice(0, 10);
            const calldata  = "0x12345678";

            await expect(
                vault.connect(attacker).executeFromOrchestrator(selector, calldata, 0)
            ).to.be.revertedWithCustomError(vault, "EOAVault__Unauthorized");
        });

        it("Non-owner cannot pause vault", async function () {
            const { vault, attacker } = await loadFixture(deploySystemFixture);

            await expect(
                vault.connect(attacker).pause()
            ).to.be.revertedWithCustomError(vault, "EOAVault__Unauthorized");
        });

        it("Non-owner cannot register modules", async function () {
            const { vault, attacker, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            await expect(
                vault.connect(attacker).registerModule(
                    "0xdeadbeef",
                    executionModuleAddr
                )
            ).to.be.revertedWithCustomError(vault, "EOAVault__Unauthorized");
        });

        it("Non-owner cannot transfer ownership", async function () {
            const { vault, attacker } = await loadFixture(deploySystemFixture);

            await expect(
                vault.connect(attacker).transferOwnership(attacker.address)
            ).to.be.revertedWithCustomError(vault, "EOAVault__Unauthorized");
        });

        it("Non-admin cannot register vault with orchestrator", async function () {
            const { orchestrator, attacker, vaultAddr } =
                await loadFixture(deploySystemFixture);

            await expect(
                orchestrator.connect(attacker).registerVault(vaultAddr)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__NotAdmin");
        });

        it("Non-registered vault is rejected by orchestrator", async function () {
            const { orchestrator, chainId, eoaOwner, attacker } =
                await loadFixture(deploySystemFixture);

            const fakeVault = attacker.address; // not registered

            const { req, signature } = await buildAndSign(
                eoaOwner, fakeVault, chainId,
                { target: eoaOwner.address }
            );

            await expect(
                orchestrator.execute(fakeVault, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__VaultNotRegistered");
        });

        it("Orchestrator admin transfer is two-step", async function () {
            const { orchestrator, deployer, otherUser } =
                await loadFixture(deploySystemFixture);

            await orchestrator.connect(deployer).transferAdmin(otherUser.address);
            expect(await orchestrator.pendingAdmin()).to.equal(otherUser.address);

            // Admin hasn't changed yet
            expect(await orchestrator.admin()).to.equal(deployer.address);

            // Complete transfer
            await orchestrator.connect(otherUser).acceptAdmin();
            expect(await orchestrator.admin()).to.equal(otherUser.address);
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 5: PAUSE FUNCTIONALITY
    // ─────────────────────────────────────────────────────────────────────────
    describe("5. Emergency Pause", function () {

        it("Owner can pause and unpause vault", async function () {
            const { vault, eoaOwner } = await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).pause();
            expect(await vault.isPaused()).to.be.true;

            await vault.connect(eoaOwner).unpause();
            expect(await vault.isPaused()).to.be.false;
        });

        it("Paused vault rejects executeFromOrchestrator", async function () {
            const { vault, vaultAddr, eoaOwner, chainId, orchestrator, recipient } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).pause();

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address }
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__ExecutionFailed");
        });

        it("Admin can pause orchestrator", async function () {
            const { orchestrator, deployer } =
                await loadFixture(deploySystemFixture);

            await orchestrator.connect(deployer).pause();
            expect(await orchestrator.orchestratorPaused()).to.be.true;

            await orchestrator.connect(deployer).unpause();
            expect(await orchestrator.orchestratorPaused()).to.be.false;
        });

        it("Paused orchestrator rejects all execute calls", async function () {
            const { orchestrator, deployer, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            await orchestrator.connect(deployer).pause();

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address }
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__Paused");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 6: OWNERSHIP TRANSFER
    // ─────────────────────────────────────────────────────────────────────────
    describe("6. Ownership Management", function () {

        it("Owner can transfer ownership", async function () {
            const { vault, eoaOwner, otherUser } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).transferOwnership(otherUser.address);
            expect(await vault.owner()).to.equal(otherUser.address);
        });

        it("New owner can exercise owner-only functions", async function () {
            const { vault, eoaOwner, otherUser } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).transferOwnership(otherUser.address);

            // New owner can pause
            await vault.connect(otherUser).pause();
            expect(await vault.isPaused()).to.be.true;
        });

        it("Old owner loses access after transfer", async function () {
            const { vault, eoaOwner, otherUser } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).transferOwnership(otherUser.address);

            await expect(
                vault.connect(eoaOwner).pause()
            ).to.be.revertedWithCustomError(vault, "EOAVault__Unauthorized");
        });

        it("Cannot transfer ownership to zero address", async function () {
            const { vault, eoaOwner } = await loadFixture(deploySystemFixture);

            await expect(
                vault.connect(eoaOwner).transferOwnership(ethers.ZeroAddress)
            ).to.be.revertedWithCustomError(vault, "EOAVault__ZeroAddress");
        });

        it("Cannot transfer ownership to same owner", async function () {
            const { vault, eoaOwner } = await loadFixture(deploySystemFixture);

            await expect(
                vault.connect(eoaOwner).transferOwnership(eoaOwner.address)
            ).to.be.revertedWithCustomError(vault, "EOAVault__InvalidOwnerChange");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 7: MODULE REGISTRY
    // ─────────────────────────────────────────────────────────────────────────
    describe("7. Module Registry", function () {

        it("Owner can register a new module selector", async function () {
            const { vault, eoaOwner, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            const customSelector = "0xdeadbeef";
            await vault.connect(eoaOwner).registerModule(
                customSelector,
                executionModuleAddr
            );

            const registeredModule = await vault.getModule(customSelector);
            expect(registeredModule.toLowerCase()).to.equal(
                executionModuleAddr.toLowerCase()
            );
        });

        it("Module is whitelisted as delegate after registration", async function () {
            const { vault, eoaOwner, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            // ExecutionModule was registered by factory — should be delegate
            expect(await vault.isDelegate(executionModuleAddr)).to.be.true;
        });

        it("Owner can deregister a module", async function () {
            const { vault, eoaOwner } = await loadFixture(deploySystemFixture);

            const selector = ethers.id("execute(address,uint256,bytes,bool)").slice(0, 10);

            await vault.connect(eoaOwner).deregisterModule(selector);

            expect(await vault.getModule(selector)).to.equal(ethers.ZeroAddress);
        });

        it("Owner can revoke delegate to block module entirely", async function () {
            const { vault, eoaOwner, executionModuleAddr } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).revokeDelegate(executionModuleAddr);
            expect(await vault.isDelegate(executionModuleAddr)).to.be.false;
        });

        it("Execution fails when module delegate is revoked", async function () {
            const { vault, vaultAddr, eoaOwner, orchestrator, executionModuleAddr, chainId, recipient } =
                await loadFixture(deploySystemFixture);

            await vault.connect(eoaOwner).revokeDelegate(executionModuleAddr);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address, value: ethers.parseEther("0.001") }
            );

            // When delegate is revoked, EOAVault reverts with EOAVault__Unauthorized(module).
            // _routeToVault catches this and re-reverts as Orchestrator__ExecutionFailed,
            // embedding the inner revert data.
            // Note: do NOT send ETH with the tx — Orchestrator.execute() is non-payable;
            // the vault's own funded balance covers req.value forwarding.
            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__ExecutionFailed");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 8: DOMAIN SEPARATOR
    // ─────────────────────────────────────────────────────────────────────────
    describe("8. Domain Separator & EIP-712", function () {

        it("Domain separator is non-zero and consistent", async function () {
            const { vault } = await loadFixture(deploySystemFixture);

            const ds = await vault.DOMAIN_SEPARATOR();
            expect(ds).to.not.equal(ethers.ZeroHash);

            // Should be consistent across calls
            const ds2 = await vault.DOMAIN_SEPARATOR();
            expect(ds).to.equal(ds2);
        });

        it("Different vaults have different domain separators", async function () {
            const { factory, eoaOwner, vault } =
                await loadFixture(deploySystemFixture);

            // Deploy second vault with different salt
            const salt2 = ethers.keccak256(ethers.toUtf8Bytes("vault-2"));
            await factory.connect(eoaOwner).deployVault(salt2);

            const vaults = await factory.getOwnerVaults(eoaOwner.address);
            const EOAVault = await ethers.getContractFactory("EOAVault");
            const vault2   = EOAVault.attach(vaults[1]);

            const ds1 = await vault.DOMAIN_SEPARATOR();
            const ds2 = await vault2.DOMAIN_SEPARATOR();

            expect(ds1).to.not.equal(ds2);
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 9: CALL POLICIES
    // ─────────────────────────────────────────────────────────────────────────
    describe("9. Call Policies", function () {

        it("Admin can set a call policy for a target", async function () {
            const { orchestrator, deployer, recipient } =
                await loadFixture(deploySystemFixture);

            const policy = {
                allowed:          true,
                maxValue:         ethers.parseEther("0.5"),
                requiresDelay:    false,
                delaySeconds:     0,
                allowedSelector:  "0x00000000",
            };

            await orchestrator.connect(deployer).setCallPolicy(
                recipient.address,
                policy
            );

            const stored = await orchestrator.callPolicies(recipient.address);
            expect(stored.allowed).to.be.true;
            expect(stored.maxValue).to.equal(ethers.parseEther("0.5"));
        });

        it("Whitelist mode blocks non-whitelisted targets", async function () {
            const { orchestrator, deployer, vaultAddr, chainId, eoaOwner, attacker } =
                await loadFixture(deploySystemFixture);

            await orchestrator.connect(deployer).setWhitelistMode(true);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: attacker.address } // not whitelisted
            );

            await expect(
                orchestrator.execute(vaultAddr, req, signature)
            ).to.be.revertedWithCustomError(orchestrator, "Orchestrator__TargetNotAllowed");
        });

        it("Whitelist mode allows whitelisted targets", async function () {
            const { orchestrator, deployer, vaultAddr, chainId, eoaOwner, recipient } =
                await loadFixture(deploySystemFixture);

            // Whitelist the recipient
            await orchestrator.connect(deployer).setCallPolicy(recipient.address, {
                allowed:         true,
                maxValue:        0n,
                requiresDelay:   false,
                delaySeconds:    0,
                allowedSelector: "0x00000000",
            });

            await orchestrator.connect(deployer).setWhitelistMode(true);

            const { req, signature } = await buildAndSign(
                eoaOwner, vaultAddr, chainId,
                { target: recipient.address, value: ethers.parseEther("0.001") }
            );

            // Should not revert policy check (may revert on execution if module handles it)
            const [valid, reason] = await orchestrator.simulateExecution(
                vaultAddr, req, signature
            );
            expect(valid).to.be.true;
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 10: FACTORY MULTI-VAULT
    // ─────────────────────────────────────────────────────────────────────────
    describe("10. Factory & Multi-Vault", function () {

        it("Multiple owners can deploy separate vaults", async function () {
            const { factory, eoaOwner, otherUser } =
                await loadFixture(deploySystemFixture);

            const salt1 = ethers.keccak256(ethers.toUtf8Bytes("user1-vault"));
            const salt2 = ethers.keccak256(ethers.toUtf8Bytes("user2-vault"));

            await factory.connect(otherUser).deployVault(salt1);
            // Use eoaOwner as the second distinct deployer
            await factory.connect(eoaOwner).deployVault(salt2);
        });

        it("getOwnerVaults returns correct vaults", async function () {
            const { factory, eoaOwner, vaultAddr } =
                await loadFixture(deploySystemFixture);

            const vaults = await factory.getOwnerVaults(eoaOwner.address);
            expect(vaults.length).to.be.at.least(1);
            expect(vaults[0].toLowerCase()).to.equal(vaultAddr.toLowerCase());
        });

        it("totalVaults increments after each deployment", async function () {
            const { factory, eoaOwner } = await loadFixture(deploySystemFixture);

            const before = await factory.totalVaults();
            await factory.connect(eoaOwner).deployVault(
                ethers.keccak256(ethers.toUtf8Bytes("extra-vault"))
            );
            const after = await factory.totalVaults();

            expect(after).to.equal(before + 1n);
        });

        it("Cannot deploy same vault twice (same owner + salt)", async function () {
            const { factory, eoaOwner } = await loadFixture(deploySystemFixture);

            await expect(
                factory.connect(eoaOwner).deployVault(VAULT_SALT) // already deployed
            ).to.be.revertedWithCustomError(factory, "VaultFactory__VaultAlreadyExists");
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 11: ETH MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────
    describe("11. ETH Balance", function () {

        it("Vault correctly reports ETH balance", async function () {
            const { vault } = await loadFixture(deploySystemFixture);

            const balance = await vault.vaultBalance();
            expect(balance).to.equal(ethers.parseEther("1.0"));
        });

        it("Vault accumulates ETH from multiple sends", async function () {
            const { vault, vaultAddr, deployer, otherUser } =
                await loadFixture(deploySystemFixture);

            await otherUser.sendTransaction({
                to:    vaultAddr,
                value: ethers.parseEther("0.5"),
            });

            const balance = await vault.vaultBalance();
            expect(balance).to.equal(ethers.parseEther("1.5"));
        });
    });

    // ─────────────────────────────────────────────────────────────────────────
    // SECTION 12: NONCE MANAGER EXTERNAL VIEWS
    // ─────────────────────────────────────────────────────────────────────────
    describe("12. NonceManager External Views", function () {

        it("isOperationConsumed returns false for fresh opId", async function () {
            const { vault } = await loadFixture(deploySystemFixture);

            const freshOpId = ethers.keccak256(ethers.toUtf8Bytes("never-seen"));
            expect(await vault.isOperationConsumed(freshOpId)).to.be.false;
        });

        it("getModuleNonce returns 0 for unregistered module", async function () {
            const { vault, attacker } = await loadFixture(deploySystemFixture);

            expect(await vault.getModuleNonce(attacker.address)).to.equal(0n);
        });
    });

});