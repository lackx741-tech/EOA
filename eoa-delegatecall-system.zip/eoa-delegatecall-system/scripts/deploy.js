/**
 * EOA DelegateCall System — Full Deployment Script
 * ══════════════════════════════════════════════════
 * 
 * This script deploys the entire EOA DelegateCall system from scratch.
 * Designed for beginners ("script kiddies") — just fill in your RPC URL
 * and private key, run it, and everything is set up automatically.
 *
 * WHAT THIS SCRIPT DOES:
 *  1. Deploys VaultFactory (which auto-deploys Orchestrator + ExecutionModule)
 *  2. Deploys a personal EOAVault for your EOA address
 *  3. Configures call policies on the Orchestrator
 *  4. Verifies the entire deployment
 *  5. Saves all addresses to deployment.json for later use
 *
 * USAGE:
 *   npm install ethers
 *   node scripts/deploy.js
 *
 * REQUIREMENTS:
 *   - Node.js >= 16
 *   - ethers.js v6
 *   - A funded EOA private key
 *   - An RPC endpoint (Infura, Alchemy, local Hardhat/Anvil, etc.)
 */

const { ethers } = require("ethers");
const fs         = require("fs");
const path       = require("path");

// ─────────────────────────────────────────────────────────────────────────────
// ██████╗  ██████╗ ███╗   ██╗███████╗██╗ ██████╗
// ██╔════╝██╔═══██╗████╗  ██║██╔════╝██║██╔════╝
// ██║     ██║   ██║██╔██╗ ██║█████╗  ██║██║  ███╗
// ██║     ██║   ██║██║╚██╗██║██╔══╝  ██║██║   ██║
// ╚██████╗╚██████╔╝██║ ╚████║██║     ██║╚██████╔╝
//  ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝     ╚═╝ ╚═════╝
// ─────────────────────────────────────────────────────────────────────────────
// ▼▼▼ EDIT THESE VALUES BEFORE RUNNING ▼▼▼

const CONFIG = {
    // Your RPC endpoint — use one of these:
    //   Local:   "http://127.0.0.1:8545"   (Hardhat/Anvil)
    //   Sepolia: "https://sepolia.infura.io/v3/YOUR_KEY"
    //   Mainnet: "https://mainnet.infura.io/v3/YOUR_KEY"
    RPC_URL: process.env.RPC_URL || "http://127.0.0.1:8545",

    // Your EOA private key (NEVER commit this to git!)
    // Set via environment variable: export PRIVATE_KEY=0x...
    PRIVATE_KEY: process.env.PRIVATE_KEY || "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",
    //                                        ^^^^ This is Hardhat/Anvil default test key

    // A random salt for CREATE2 vault deployment
    // Change this to deploy a different vault address for the same owner
    VAULT_SALT: process.env.VAULT_SALT || ethers.keccak256(ethers.toUtf8Bytes("my-first-vault-v1")),

    // Timelock settings
    TIMELOCK_DELAY_SECONDS:    60 * 60 * 24,  // 24 hours
    TIMELOCK_VALUE_THRESHOLD:  ethers.parseEther("1.0"),  // 1 ETH triggers timelock

    // Whether to fund the vault with some ETH after deployment
    FUND_VAULT_ETH: "0.01",  // Set to "0" to skip funding

    // Output file for deployed addresses
    OUTPUT_FILE: path.join(__dirname, "../deployment.json"),
};

// ▲▲▲ EDIT ABOVE THIS LINE ▲▲▲
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// CONTRACT ABIs (minimal ABIs for deployment interaction)
// In production, generate these from compiled artifacts
// ─────────────────────────────────────────────────────────────────────────────

const VAULT_FACTORY_ABI = [
    "constructor(address admin, uint256 timelockDelay, uint256 timelockValueThreshold)",
    "function deployVault(bytes32 userSalt) external returns (address vault)",
    "function predictVaultAddress(address owner, bytes32 userSalt) public view returns (address)",
    "function orchestrator() external view returns (address)",
    "function executionModule() external view returns (address)",
    "function getOwnerVaults(address owner) external view returns (address[])",
    "function totalVaults() external view returns (uint256)",
    "event VaultDeployed(address indexed owner, address indexed vault, bytes32 indexed salt, address orchestrator_, address executionModule_)",
];

const EOA_VAULT_ABI = [
    "function initialize(address owner, address orchestrator) external",
    "function owner() external view returns (address)",
    "function orchestrator() external view returns (address)",
    "function getNonce() external view returns (uint256)",
    "function isPaused() external view returns (bool)",
    "function isDelegate(address module) external view returns (bool)",
    "function getModule(bytes4 selector) external view returns (address)",
    "function vaultBalance() external view returns (uint256)",
    "function DOMAIN_SEPARATOR() external view returns (bytes32)",
    "function registerModule(bytes4 selector, address module) external",
    "function setOrchestrator(address newOrchestrator) external",
    "function pause() external",
    "function unpause() external",
    "function emergencyAdvanceNonce(uint256 steps) external",
    "function getExecutionDigest(tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req) external view returns (bytes32)",
    "function simulateValidation(uint256 nonce, uint256 deadline, uint256 chainId, bytes32 operationId) external view returns (bool, string)",
    "receive() external payable",
];

const ORCHESTRATOR_ABI = [
    "constructor(address admin, uint256 timelockDelay, uint256 timelockValueThreshold)",
    "function admin() external view returns (address)",
    "function registeredVaults(address) external view returns (bool)",
    "function whitelistMode() external view returns (bool)",
    "function timelockValueThreshold() external view returns (uint256)",
    "function defaultTimelockDelay() external view returns (uint256)",
    "function registerVault(address vault) external",
    "function setCallPolicy(address target, tuple(bool allowed, uint256 maxValue, bool requiresDelay, uint256 delaySeconds, bytes4 allowedSelector) policy) external",
    "function setWhitelistMode(bool enabled) external",
    "function isOperationConsumed(bytes32 operationId) external view returns (bool)",
    "function execute(address vault, tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req, bytes signature) external",
    "function simulateExecution(address vault, tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req, bytes signature) external view returns (bool, string)",
    "event OperationExecuted(bytes32 indexed operationId, address indexed vault, address indexed target, uint256 value, uint256 nonce, bool success)",
];

const EXECUTION_MODULE_ABI = [
    "function MAX_BATCH_SIZE() external view returns (uint256)",
    "function GAS_RESERVE() external view returns (uint256)",
];

// ─────────────────────────────────────────────────────────────────────────────
// BYTECODES — Replace with actual compiled bytecode from your build toolchain
// When using Hardhat: require the artifact JSON and use artifact.bytecode
// ─────────────────────────────────────────────────────────────────────────────

// NOTE: In a real deployment, you would compile the contracts first:
//   npx hardhat compile
// Then import:
//   const VaultFactoryArtifact = require("../artifacts/contracts/VaultFactory.sol/VaultFactory.json");
//   const bytecode = VaultFactoryArtifact.bytecode;
//
// For this demo script we use placeholder markers — the compile step fills these in

// ─────────────────────────────────────────────────────────────────────────────
// UTILITIES
// ─────────────────────────────────────────────────────────────────────────────

const log = {
    header: (msg) => console.log(`\n${"═".repeat(60)}\n  ${msg}\n${"═".repeat(60)}`),
    step:   (n, msg) => console.log(`\n  [${n}] ${msg}`),
    info:   (key, val) => console.log(`      ${key.padEnd(30)} ${val}`),
    ok:     (msg) => console.log(`      ✅ ${msg}`),
    warn:   (msg) => console.log(`      ⚠️  ${msg}`),
    err:    (msg) => console.log(`      ❌ ${msg}`),
    divider: () => console.log(`      ${"─".repeat(54)}`),
};

/**
 * Deploys a contract from bytecode + ABI
 */
async function deployContract(signer, abi, bytecode, args = [], label = "Contract") {
    log.info("Deploying", label);
    const factory  = new ethers.ContractFactory(abi, bytecode, signer);
    const contract = await factory.deploy(...args);
    await contract.waitForDeployment();
    const address = await contract.getAddress();
    log.ok(`${label} → ${address}`);
    return contract;
}

/**
 * Sleeps for ms milliseconds
 */
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

/**
 * Formats ETH value nicely
 */
const formatEth = (wei) => `${ethers.formatEther(wei)} ETH`;

// ─────────────────────────────────────────────────────────────────────────────
// MAIN DEPLOYMENT FUNCTION
// ─────────────────────────────────────────────────────────────────────────────

async function main() {
    log.header("EOA DelegateCall System — Deployment");

    // ── Provider + Signer setup ───────────────────────────────────────────────
    log.step(1, "Connecting to network...");
    const provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL);

    let network;
    try {
        network = await provider.getNetwork();
    } catch (e) {
        log.err("Failed to connect to RPC: " + CONFIG.RPC_URL);
        log.warn("Make sure your local node is running: npx hardhat node");
        process.exit(1);
    }

    const signer = new ethers.Wallet(CONFIG.PRIVATE_KEY, provider);
    const balance = await provider.getBalance(signer.address);

    log.info("Network:",       `${network.name} (chainId: ${network.chainId})`);
    log.info("EOA Address:",   signer.address);
    log.info("EOA Balance:",   formatEth(balance));
    log.info("Vault Salt:",    CONFIG.VAULT_SALT);

    if (balance === 0n) {
        log.warn("EOA has zero balance. Deployment will fail!");
        log.warn("Fund your account first.");
    }

    // ── Load compiled artifacts ───────────────────────────────────────────────
    log.step(2, "Loading contract artifacts...");

    // Try to load from Hardhat artifacts (run `npx hardhat compile` first)
    let VaultFactoryBytecode, ExecutionModuleBytecode;

    try {
        const artifactsPath = path.join(__dirname, "../artifacts/contracts");

        const vfArtifact  = JSON.parse(fs.readFileSync(
            path.join(artifactsPath, "VaultFactory.sol/VaultFactory.json"), "utf8"
        ));
        const emArtifact  = JSON.parse(fs.readFileSync(
            path.join(artifactsPath, "ExecutionModule.sol/ExecutionModule.json"), "utf8"
        ));

        VaultFactoryBytecode    = vfArtifact.bytecode;
        ExecutionModuleBytecode = emArtifact.bytecode;

        log.ok("Artifacts loaded from Hardhat compilation");
    } catch (e) {
        log.warn("Hardhat artifacts not found. Run: npx hardhat compile");
        log.warn("Using mock bytecode for address computation demo only.");
        // In a real script you would exit here; we continue for demonstration
        VaultFactoryBytecode    = "0x"; // placeholder
        ExecutionModuleBytecode = "0x"; // placeholder
    }

    // ── Pre-compute addresses ─────────────────────────────────────────────────
    log.step(3, "Pre-computing deployment addresses...");

    const deployerNonce = await provider.getTransactionCount(signer.address);

    // VaultFactory address = deterministic from deployer nonce
    const factoryAddress = ethers.getCreateAddress({
        from:  signer.address,
        nonce: deployerNonce
    });

    log.info("Predicted Factory Addr:", factoryAddress);
    log.info("Deployer Nonce:",         deployerNonce.toString());

    // ── Deploy VaultFactory ───────────────────────────────────────────────────
    log.step(4, "Deploying VaultFactory (+ Orchestrator + ExecutionModule)...");

    let factory;
    if (VaultFactoryBytecode !== "0x") {
        factory = await deployContract(
            signer,
            VAULT_FACTORY_ABI,
            VaultFactoryBytecode,
            [
                signer.address,                       // admin
                CONFIG.TIMELOCK_DELAY_SECONDS,        // timelock delay
                CONFIG.TIMELOCK_VALUE_THRESHOLD       // ETH threshold
            ],
            "VaultFactory"
        );
    } else {
        log.warn("Skipping actual deployment (no bytecode available)");
        log.warn("This is a dry-run. Compile contracts first.");

        // Show what would be deployed
        log.info("Would deploy VaultFactory at:", factoryAddress);
        log.info("With admin:",                  signer.address);
        log.info("Timelock delay:",              CONFIG.TIMELOCK_DELAY_SECONDS + "s");
        log.info("Timelock threshold:",          formatEth(CONFIG.TIMELOCK_VALUE_THRESHOLD));

        // Save mock deployment for reference
        const mockDeployment = {
            network: {
                name:    network.name,
                chainId: Number(network.chainId),
            },
            deployer:       signer.address,
            deployedAt:     new Date().toISOString(),
            dryRun:         true,
            contracts: {
                VaultFactory:    { address: factoryAddress,  note: "predicted" },
                Orchestrator:    { address: "computed-from-factory-nonce-+1" },
                ExecutionModule: { address: "computed-from-factory-nonce-+2" },
                EOAVault:        { address: "use predictVaultAddress() after deploy" },
            },
            config: {
                vaultSalt:             CONFIG.VAULT_SALT,
                timelockDelaySeconds:  CONFIG.TIMELOCK_DELAY_SECONDS,
                timelockValueThreshold: CONFIG.TIMELOCK_VALUE_THRESHOLD.toString(),
            },
        };

        fs.writeFileSync(CONFIG.OUTPUT_FILE, JSON.stringify(mockDeployment, null, 2));
        log.ok("Mock deployment data saved to: " + CONFIG.OUTPUT_FILE);
        printNextSteps(null, null, null, null, true);
        return;
    }

    const factoryAddr = await factory.getAddress();

    // ── Read auto-deployed addresses ──────────────────────────────────────────
    log.step(5, "Reading auto-deployed contract addresses...");

    const orchestratorAddr    = await factory.orchestrator();
    const executionModuleAddr = await factory.executionModule();

    log.info("VaultFactory:",    factoryAddr);
    log.info("Orchestrator:",    orchestratorAddr);
    log.info("ExecutionModule:", executionModuleAddr);

    // ── Pre-compute vault address ─────────────────────────────────────────────
    log.step(6, "Pre-computing vault address (counterfactual)...");

    const predictedVault = await factory.predictVaultAddress(
        signer.address,
        CONFIG.VAULT_SALT
    );

    log.info("Predicted Vault Addr:", predictedVault);
    log.ok("You can send ETH to this address NOW (before deployment)!");

    // ── Optionally fund vault before deploy ───────────────────────────────────
    if (CONFIG.FUND_VAULT_ETH !== "0") {
        log.step(7, `Pre-funding vault with ${CONFIG.FUND_VAULT_ETH} ETH...`);

        const fundTx = await signer.sendTransaction({
            to:    predictedVault,
            value: ethers.parseEther(CONFIG.FUND_VAULT_ETH),
        });
        await fundTx.wait();

        const vaultBalance = await provider.getBalance(predictedVault);
        log.ok(`Vault pre-funded with ${formatEth(vaultBalance)}`);
        log.info("Fund tx:", fundTx.hash);
    }

    // ── Deploy EOAVault ───────────────────────────────────────────────────────
    log.step(8, "Deploying EOAVault via factory (CREATE2)...");

    const deployTx  = await factory.deployVault(CONFIG.VAULT_SALT);
    const deployRec = await deployTx.wait();

    // Extract vault address from VaultDeployed event
    const vaultDeployedEvent = deployRec.logs.find(log =>
        log.topics[0] === ethers.id("VaultDeployed(address,address,bytes32,address,address)")
    );

    let vaultAddr;
    if (vaultDeployedEvent) {
        // Decode the event — vault is the second indexed topic (topics[2])
        vaultAddr = "0x" + vaultDeployedEvent.topics[2].slice(26);
        vaultAddr = ethers.getAddress(vaultAddr); // checksum
    } else {
        const vaults = await factory.getOwnerVaults(signer.address);
        vaultAddr = vaults[vaults.length - 1];
    }

    log.ok(`EOAVault deployed at: ${vaultAddr}`);
    log.info("Deploy tx:", deployTx.hash);

    // Verify predicted == actual
    if (vaultAddr.toLowerCase() === predictedVault.toLowerCase()) {
        log.ok("✓ Vault address matches prediction (CREATE2 working correctly)");
    } else {
        log.warn("Vault address mismatch! Check salt configuration.");
    }

    // ── Verify vault state ────────────────────────────────────────────────────
    log.step(9, "Verifying vault deployment...");

    const vault          = new ethers.Contract(vaultAddr, EOA_VAULT_ABI, signer);
    const vaultOwner     = await vault.owner();
    const vaultOrch      = await vault.orchestrator();
    const vaultNonce     = await vault.getNonce();
    const vaultPaused    = await vault.isPaused();
    const vaultBal       = await vault.vaultBalance();
    const domainSep      = await vault.DOMAIN_SEPARATOR();
    const executeModule  = await vault.getModule(
        ethers.id("execute(address,uint256,bytes,bool)").slice(0, 10)
    );

    log.divider();
    log.info("Vault Owner:",        vaultOwner);
    log.info("Orchestrator:",       vaultOrch);
    log.info("Current Nonce:",      vaultNonce.toString());
    log.info("Paused:",             vaultPaused.toString());
    log.info("Vault Balance:",      formatEth(vaultBal));
    log.info("Domain Separator:",   domainSep.slice(0, 18) + "...");
    log.info("Execute Module:",     executeModule);
    log.divider();

    const allGood = (
        vaultOwner.toLowerCase() === signer.address.toLowerCase() &&
        vaultOrch.toLowerCase()  === orchestratorAddr.toLowerCase() &&
        !vaultPaused
    );

    if (allGood) {
        log.ok("All vault checks passed!");
    } else {
        log.err("Vault verification failed. Check deployment.");
    }

    // ── Configure call policies ───────────────────────────────────────────────
    log.step(10, "Configuring Orchestrator call policies...");

    const orch = new ethers.Contract(orchestratorAddr, ORCHESTRATOR_ABI, signer);

    // Example policy: allow calls to a test ERC20 with max 0 ETH
    // In production, add policies for each contract you want to interact with

    log.warn("Skipping example policy setup (no target contracts defined).");
    log.warn("Use setCallPolicy() to whitelist target contracts.");
    log.warn("See interact.js for examples.");

    // ── Save deployment data ──────────────────────────────────────────────────
    log.step(11, "Saving deployment data...");

    const deploymentData = {
        network: {
            name:    network.name,
            chainId: Number(network.chainId),
            rpcUrl:  CONFIG.RPC_URL,
        },
        deployer:    signer.address,
        deployedAt:  new Date().toISOString(),
        dryRun:      false,
        contracts: {
            VaultFactory: {
                address: factoryAddr,
                abi:     "VAULT_FACTORY_ABI",
            },
            Orchestrator: {
                address: orchestratorAddr,
                abi:     "ORCHESTRATOR_ABI",
            },
            ExecutionModule: {
                address: executionModuleAddr,
                abi:     "EXECUTION_MODULE_ABI",
            },
            EOAVault: {
                address:         vaultAddr,
                owner:           vaultOwner,
                domainSeparator: domainSep,
                abi:             "EOA_VAULT_ABI",
            },
        },
        config: {
            vaultSalt:              CONFIG.VAULT_SALT,
            timelockDelaySeconds:   CONFIG.TIMELOCK_DELAY_SECONDS,
            timelockValueThreshold: CONFIG.TIMELOCK_VALUE_THRESHOLD.toString(),
        },
    };

    fs.writeFileSync(CONFIG.OUTPUT_FILE, JSON.stringify(deploymentData, null, 2));
    log.ok("Deployment data saved to: " + CONFIG.OUTPUT_FILE);

    printNextSteps(factoryAddr, orchestratorAddr, vaultAddr, executionModuleAddr, false);
}

// ─────────────────────────────────────────────────────────────────────────────
// NEXT STEPS HELPER
// ─────────────────────────────────────────────────────────────────────────────

function printNextSteps(factory, orch, vault, module, isDryRun) {
    log.header("🎉 Deployment Complete — What's Next?");

    if (!isDryRun) {
        console.log(`
  DEPLOYED CONTRACTS:
  ───────────────────────────────────────────────────────
  VaultFactory:    ${factory}
  Orchestrator:    ${orch}
  ExecutionModule: ${module}
  EOAVault:        ${vault}
  ───────────────────────────────────────────────────────
`);
    }

    console.log(`
  NEXT STEPS:
  ──────────────────────────────────────────────────────

  1. SEND ETH TO VAULT (if not already funded):
     ┌─────────────────────────────────────────────────┐
     │  cast send ${vault || "<vault>"} --value 0.1ether \\  │
     │       --private-key $PRIVATE_KEY                │
     └─────────────────────────────────────────────────┘

  2. EXECUTE A TRANSACTION (via interact.js):
     ┌─────────────────────────────────────────────────┐
     │  node scripts/interact.js                       │
     └─────────────────────────────────────────────────┘

  3. MONITOR EVENTS (via cast):
     ┌─────────────────────────────────────────────────┐
     │  cast logs --address ${orch || "<orch>"}  \\     │
     │       "OperationExecuted(bytes32,address,...)"  │
     └─────────────────────────────────────────────────┘

  4. CHECK VAULT NONCE:
     ┌─────────────────────────────────────────────────┐
     │  cast call ${vault || "<vault>"} "getNonce()"   │
     └─────────────────────────────────────────────────┘

  5. EMERGENCY PAUSE (if something goes wrong):
     ┌─────────────────────────────────────────────────┐
     │  cast send ${vault || "<vault>"} "pause()"  \\   │
     │       --private-key $PRIVATE_KEY                │
     └─────────────────────────────────────────────────┘

  📄 Full deployment data saved to: deployment.json
  📖 See docs/ARCHITECTURE.md for detailed documentation
  🔐 Never expose your PRIVATE_KEY in code — use env vars!
  `);
}

// ─────────────────────────────────────────────────────────────────────────────
// ENTRY POINT
// ─────────────────────────────────────────────────────────────────────────────

main().catch((error) => {
    console.error("\n❌ Deployment failed:");
    console.error(error);
    process.exit(1);
});