/**
 * EOA DelegateCall System — Interaction Script
 * ══════════════════════════════════════════════
 *
 * Demonstrates how to interact with the deployed system:
 *  1. Building signed ExecutionRequests (EIP-712)
 *  2. Submitting them through the Orchestrator
 *  3. Monitoring execution events
 *  4. Performing batch operations
 *  5. Emergency operations (pause, nonce advance)
 *
 * USAGE:
 *   node scripts/interact.js [command]
 *
 * COMMANDS:
 *   send-eth   <recipient> <amount>   Send ETH from vault
 *   call       <target> <calldata>    Call a contract function
 *   batch      (runs example batch)   Execute multiple calls
 *   check-nonce                       Print current vault nonce
 *   simulate   <target> <calldata>    Simulate without executing
 *   pause                             Pause the vault
 *   emergency                         Advance nonce by 10 (invalidate pending)
 */

const { ethers } = require("ethers");
const fs         = require("fs");
const path       = require("path");

// ─────────────────────────────────────────────────────────────────────────────
// LOAD DEPLOYMENT DATA
// ─────────────────────────────────────────────────────────────────────────────

const DEPLOYMENT_FILE = path.join(__dirname, "../deployment.json");

let deployment;
try {
    deployment = JSON.parse(fs.readFileSync(DEPLOYMENT_FILE, "utf8"));
} catch (e) {
    console.error("❌ deployment.json not found. Run deploy.js first.");
    process.exit(1);
}

// ─────────────────────────────────────────────────────────────────────────────
// CONFIG — override via environment variables
// ─────────────────────────────────────────────────────────────────────────────

const CONFIG = {
    RPC_URL:     process.env.RPC_URL     || deployment.network.rpcUrl || "http://127.0.0.1:8545",
    PRIVATE_KEY: process.env.PRIVATE_KEY || "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80",

    // Contract addresses from deployment
    VAULT_ADDR:       deployment.contracts.EOAVault?.address,
    ORCHESTRATOR_ADDR: deployment.contracts.Orchestrator?.address,
    FACTORY_ADDR:     deployment.contracts.VaultFactory?.address,

    // Default deadline = 30 minutes from now
    DEFAULT_DEADLINE_OFFSET: 30 * 60,
};

// ─────────────────────────────────────────────────────────────────────────────
// CONTRACT ABIs
// ─────────────────────────────────────────────────────────────────────────────

const EOA_VAULT_ABI = [
    "function owner() external view returns (address)",
    "function getNonce() external view returns (uint256)",
    "function isPaused() external view returns (bool)",
    "function vaultBalance() external view returns (uint256)",
    "function DOMAIN_SEPARATOR() external view returns (bytes32)",
    "function pause() external",
    "function unpause() external",
    "function emergencyAdvanceNonce(uint256 steps) external",
    "function simulateValidation(uint256 nonce, uint256 deadline, uint256 chainId, bytes32 operationId) external view returns (bool, string)",
    "function getExecutionDigest(tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req) external view returns (bytes32)",
    "event ETHReceived(address indexed sender, uint256 amount)",
    "event ExecutionRouted(bytes4 indexed selector, address indexed module, address indexed caller, uint256 nonce)",
];

const ORCHESTRATOR_ABI = [
    "function execute(address vault, tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req, bytes signature) external payable",
    "function simulateExecution(address vault, tuple(address target, uint256 value, bytes data, uint256 nonce, uint256 deadline, uint256 chainId) req, bytes signature) external view returns (bool, string)",
    "function isOperationConsumed(bytes32 operationId) external view returns (bool)",
    "function registeredVaults(address) external view returns (bool)",
    "function setCallPolicy(address target, tuple(bool allowed, uint256 maxValue, bool requiresDelay, uint256 delaySeconds, bytes4 allowedSelector) policy) external",
    "event OperationExecuted(bytes32 indexed operationId, address indexed vault, address indexed target, uint256 value, uint256 nonce, bool success)",
    "event OperationQueued(bytes32 indexed operationId, address indexed vault, address indexed target, uint256 scheduledAt, uint256 executeAfter)",
];

// ─────────────────────────────────────────────────────────────────────────────
// EIP-712 TYPED DATA DEFINITION
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Returns the EIP-712 domain for a given vault
 * The EOA wallet signs with these exact domain parameters
 */
function buildEIP712Domain(chainId, vaultAddress) {
    return {
        name:              "EOAVault",
        version:           "1",
        chainId:           chainId,
        verifyingContract: vaultAddress,
    };
}

/**
 * EIP-712 type definitions for ExecutionRequest
 */
const EIP712_TYPES = {
    ExecutionRequest: [
        { name: "target",   type: "address" },
        { name: "value",    type: "uint256" },
        { name: "data",     type: "bytes"   },
        { name: "nonce",    type: "uint256" },
        { name: "deadline", type: "uint256" },
        { name: "chainId",  type: "uint256" },
    ],
};

/**
 * EIP-712 type definitions for BatchExecution
 */
const EIP712_BATCH_TYPES = {
    ExecutionRequest: [
        { name: "target",   type: "address" },
        { name: "value",    type: "uint256" },
        { name: "data",     type: "bytes"   },
        { name: "nonce",    type: "uint256" },
        { name: "deadline", type: "uint256" },
        { name: "chainId",  type: "uint256" },
    ],
    BatchExecution: [
        { name: "operations", type: "ExecutionRequest[]" },
        { name: "nonce",      type: "uint256" },
        { name: "deadline",   type: "uint256" },
        { name: "chainId",    type: "uint256" },
    ],
};

// ─────────────────────────────────────────────────────────────────────────────
// CORE FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Build an ExecutionRequest object
 *
 * @param target    - Contract or EOA to call
 * @param value     - ETH value in wei
 * @param data      - ABI-encoded calldata (use "0x" for plain ETH transfer)
 * @param nonce     - Current vault nonce
 * @param chainId   - Network chainId
 * @param deadlineOffset - Seconds from now until expiry (default 30 min)
 */
function buildExecutionRequest({
    target,
    value,
    data,
    nonce,
    chainId,
    deadlineOffset = CONFIG.DEFAULT_DEADLINE_OFFSET,
}) {
    const deadline = Math.floor(Date.now() / 1000) + deadlineOffset;

    return {
        target:   target,
        value:    value,
        data:     data || "0x",
        nonce:    nonce,
        deadline: deadline,
        chainId:  chainId,
    };
}

/**
 * Sign an ExecutionRequest using EIP-712 typed data signing
 *
 * @param signer  - ethers.Wallet instance (the EOA)
 * @param vault   - EOAVault address (domain binding)
 * @param req     - The ExecutionRequest to sign
 * @param chainId - Network chainId
 * @returns signature - 65-byte hex signature string
 */
async function signExecutionRequest(signer, vault, req, chainId) {
    const domain = buildEIP712Domain(chainId, vault);

    console.log("\n  📝 Signing ExecutionRequest...");
    console.log(`     Target:   ${req.target}`);
    console.log(`     Value:    ${ethers.formatEther(req.value)} ETH`);
    console.log(`     Nonce:    ${req.nonce}`);
    console.log(`     Deadline: ${new Date(req.deadline * 1000).toISOString()}`);
    console.log(`     ChainId:  ${req.chainId}`);
    console.log(`     Data:     ${req.data.length > 10 ? req.data.slice(0,10)+"..." : req.data}`);

    // The EOA signs the typed data — this is the core signing step
    // ethers.js handles the EIP-712 encoding automatically
    const signature = await signer.signTypedData(domain, EIP712_TYPES, req);

    console.log(`     Signature: ${signature.slice(0, 20)}...${signature.slice(-10)}`);
    console.log("  ✅ Request signed!");

    return signature;
}

/**
 * Sign a BatchExecution request
 */
async function signBatchExecution(signer, vault, batch, chainId) {
    const domain = buildEIP712Domain(chainId, vault);

    console.log("\n  📝 Signing BatchExecution...");
    console.log(`     Operations: ${batch.operations.length}`);
    console.log(`     Nonce:      ${batch.nonce}`);
    console.log(`     ChainId:    ${batch.chainId}`);

    const signature = await signer.signTypedData(domain, EIP712_BATCH_TYPES, batch);

    console.log("  ✅ Batch signed!");
    return signature;
}

/**
 * Submit a signed ExecutionRequest to the Orchestrator
 *
 * @param orchestrator - ethers.Contract instance
 * @param vault        - EOAVault address
 * @param req          - The ExecutionRequest
 * @param signature    - The EIP-712 signature
 * @param valueToSend  - Optional ETH to send with tx (for forwarding value)
 */
async function submitToOrchestrator(orchestrator, vault, req, signature, valueToSend = 0n) {
    console.log("\n  🚀 Submitting to Orchestrator...");

    const tx = await orchestrator.execute(vault, req, signature, {
        value: valueToSend,
    });

    console.log(`     Tx sent: ${tx.hash}`);
    console.log("     Waiting for confirmation...");

    const receipt = await tx.wait();

    console.log(`     ✅ Confirmed in block ${receipt.blockNumber}`);
    console.log(`     Gas used: ${receipt.gasUsed.toString()}`);

    // Parse OperationExecuted event
    const iface = new ethers.Interface(ORCHESTRATOR_ABI);
    for (const log of receipt.logs) {
        try {
            const parsed = iface.parseLog(log);
            if (parsed && parsed.name === "OperationExecuted") {
                console.log("\n  📣 OperationExecuted Event:");
                console.log(`     OperationId: ${parsed.args.operationId}`);
                console.log(`     Vault:       ${parsed.args.vault}`);
                console.log(`     Target:      ${parsed.args.target}`);
                console.log(`     Value:       ${ethers.formatEther(parsed.args.value)} ETH`);
                console.log(`     Nonce:       ${parsed.args.nonce}`);
                console.log(`     Success:     ${parsed.args.success}`);
            }
            if (parsed && parsed.name === "OperationQueued") {
                console.log("\n  ⏳ Operation Queued (timelock required):");
                console.log(`     OperationId:  ${parsed.args.operationId}`);
                console.log(`     ExecuteAfter: ${new Date(Number(parsed.args.executeAfter) * 1000).toISOString()}`);
            }
        } catch {}
    }

    return receipt;
}

// ─────────────────────────────────────────────────────────────────────────────
// COMMAND IMPLEMENTATIONS
// ─────────────────────────────────────────────────────────────────────────────

/**
 * CMD: send-eth — Send ETH from vault to a recipient
 */
async function cmdSendETH(provider, signer, vault, orchestrator, chainId, recipient, amountEth) {
    console.log("\n═══════════════════════════════════════");
    console.log("  COMMAND: Send ETH from Vault");
    console.log("═══════════════════════════════════════");

    if (!ethers.isAddress(recipient)) {
        console.error("❌ Invalid recipient address");
        return;
    }

    const value    = ethers.parseEther(amountEth);
    const nonce    = await vault.getNonce();
    const vaultBal = await vault.vaultBalance();

    console.log(`\n  Vault Balance: ${ethers.formatEther(vaultBal)} ETH`);
    console.log(`  Sending:       ${amountEth} ETH`);
    console.log(`  To:            ${recipient}`);

    if (vaultBal < value) {
        console.error("❌ Insufficient vault balance!");
        return;
    }

    // Build request: target = recipient, value = ETH amount, data = "0x"
    const req = buildExecutionRequest({
        target:  recipient,
        value:   value,
        data:    "0x",
        nonce:   nonce,
        chainId: chainId,
    });

    const signature = await signExecutionRequest(
        signer,
        await vault.getAddress(),
        req,
        chainId
    );

    await submitToOrchestrator(
        orchestrator,
        await vault.getAddress(),
        req,
        signature,
        value // forward the ETH value with the orchestrator call
    );

    console.log("\n  ✅ ETH sent successfully!");
}

/**
 * CMD: call — Call a contract function from the vault
 */
async function cmdContractCall(
    provider, signer, vault, orchestrator, chainId,
    targetAddr, funcSig, funcArgs, valueEth = "0"
) {
    console.log("\n═══════════════════════════════════════");
    console.log("  COMMAND: Contract Call from Vault");
    console.log("═══════════════════════════════════════");

    // Encode the function call
    const iface    = new ethers.Interface([`function ${funcSig}`]);
    const calldata = iface.encodeFunctionData(
        funcSig.split("(")[0],
        funcArgs
    );
    const value    = ethers.parseEther(valueEth);
    const nonce    = await vault.getNonce();

    console.log(`\n  Target:   ${targetAddr}`);
    console.log(`  Function: ${funcSig}`);
    console.log(`  Args:     ${JSON.stringify(funcArgs)}`);
    console.log(`  Value:    ${valueEth} ETH`);
    console.log(`  Calldata: ${calldata.slice(0, 18)}...`);

    const req = buildExecutionRequest({
        target:  targetAddr,
        value:   value,
        data:    calldata,
        nonce:   nonce,
        chainId: chainId,
    });

    const signature = await signExecutionRequest(
        signer,
        await vault.getAddress(),
        req,
        chainId
    );

    // Simulate first
    const [simOk, simReason] = await orchestrator.simulateExecution(
        await vault.getAddress(),
        req,
        signature
    );

    console.log(`\n  Simulation: ${simOk ? "✅ PASS" : "❌ FAIL — " + simReason}`);

    if (!simOk) {
        console.error("Aborting due to simulation failure.");
        return;
    }

    await submitToOrchestrator(
        orchestrator,
        await vault.getAddress(),
        req,
        signature,
        value
    );

    console.log("\n  ✅ Contract call executed!");
}

/**
 * CMD: batch — Execute multiple calls atomically
 */
async function cmdBatch(provider, signer, vault, orchestrator, chainId) {
    console.log("\n═══════════════════════════════════════");
    console.log("  COMMAND: Batch Execution");
    console.log("═══════════════════════════════════════");

    const nonce    = await vault.getNonce();
    const deadline = Math.floor(Date.now() / 1000) + CONFIG.DEFAULT_DEADLINE_OFFSET;

    // Example batch: 3 different ETH transfers
    // In production these would be real contract calls
    const operations = [
        {
            target:   "0x0000000000000000000000000000000000000001",
            value:    ethers.parseEther("0.001"),
            data:     "0x",
            nonce:    nonce,
            deadline: deadline,
            chainId:  chainId,
        },
        {
            target:   "0x0000000000000000000000000000000000000002",
            value:    ethers.parseEther("0.001"),
            data:     "0x",
            nonce:    nonce,
            deadline: deadline,
            chainId:  chainId,
        },
        {
            target:   "0x0000000000000000000000000000000000000003",
            value:    ethers.parseEther("0.001"),
            data:     "0x",
            nonce:    nonce,
            deadline: deadline,
            chainId:  chainId,
        },
    ];

    const batch = {
        operations,
        nonce:    nonce,
        deadline: deadline,
        chainId:  chainId,
    };

    console.log(`\n  Batching ${operations.length} operations...`);
    for (let i = 0; i < operations.length; i++) {
        console.log(`    [${i}] → ${operations[i].target} (${ethers.formatEther(operations[i].value)} ETH)`);
    }

    const domain = buildEIP712Domain(chainId, await vault.getAddress());
    const signature = await signer.signTypedData(domain, EIP712_BATCH_TYPES, batch);

    console.log("\n  ⚠️  Batch signing demo only — actual executeBatch() call");
    console.log("  would route through Orchestrator.executeBatch().");
    console.log(`  Signature: ${signature.slice(0,20)}...`);
    console.log("  ✅ Batch signed successfully!");
}

/**
 * CMD: check-nonce — Print vault nonce and state
 */
async function cmdCheckNonce(vault, orchestrator) {
    console.log("\n═══════════════════════════════════════");
    console.log("  VAULT STATE");
    console.log("═══════════════════════════════════════");

    const vaultAddr = await vault.getAddress();
    const nonce     = await vault.getNonce();
    const paused    = await vault.isPaused();
    const balance   = await vault.vaultBalance();
    const owner     = await vault.owner();
    const domSep    = await vault.DOMAIN_SEPARATOR();
    const registered = await orchestrator.registeredVaults(vaultAddr);

    console.log(`\n  Vault Address:     ${vaultAddr}`);
    console.log(`  Owner:             ${owner}`);
    console.log(`  Current Nonce:     ${nonce.toString()}`);
    console.log(`  Paused:            ${paused}`);
    console.log(`  Balance:           ${ethers.formatEther(balance)} ETH`);
    console.log(`  Domain Separator:  ${domSep.slice(0,18)}...`);
    console.log(`  Registered:        ${registered}`);
    console.log("\n  ✅ State check complete");
}

/**
 * CMD: simulate — Dry-run an execution without sending a transaction
 */
async function cmdSimulate(
    signer, vault, orchestrator, chainId,
    targetAddr, data
) {
    console.log("\n═══════════════════════════════════════");
    console.log("  COMMAND: Simulate Execution");
    console.log("═══════════════════════════════════════");

    const nonce = await vault.getNonce();

    const req = buildExecutionRequest({
        target:  targetAddr,
        value:   0n,
        data:    data || "0x",
        nonce:   nonce,
        chainId: chainId,
    });

    const signature = await signExecutionRequest(
        signer,
        await vault.getAddress(),
        req,
        chainId
    );

    const [valid, reason] = await orchestrator.simulateExecution(
        await vault.getAddress(),
        req,
        signature
    );

    console.log(`\n  Simulation Result: ${valid ? "✅ WOULD SUCCEED" : "❌ WOULD FAIL"}`);
    if (!valid) {
        console.log(`  Failure Reason:    ${reason}`);
    }

    // Also check vault-level validation
    const opId = ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(
        ["address","uint256","bytes32","uint256","uint256","uint256"],
        [req.target, req.value, ethers.keccak256(req.data), req.nonce, req.deadline, req.chainId]
    ));

    const [vaultValid, vaultReason] = await vault.simulateValidation(
        nonce, req.deadline, chainId, opId
    );

    console.log(`  Vault Validation:  ${vaultValid ? "✅ PASS" : "❌ FAIL — " + vaultReason}`);
}

/**
 * CMD: emergency — Advance nonce to invalidate pending signed requests
 */
async function cmdEmergency(signer, vault) {
    console.log("\n═══════════════════════════════════════");
    console.log("  COMMAND: Emergency Nonce Advance");
    console.log("═══════════════════════════════════════");
    console.log("\n  ⚠️  This will invalidate ALL pending signed requests!");
    console.log("  Advancing nonce by 10...");

    const tx = await vault.connect(signer).emergencyAdvanceNonce(10);
    await tx.wait();

    const newNonce = await vault.getNonce();
    console.log(`\n  ✅ Nonce advanced. New nonce: ${newNonce}`);
    console.log("  All previously signed requests with nonce < " + newNonce + " are now invalid.");
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITIES — Off-chain signing helpers
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Utility: Compute operation ID for a request (matches on-chain logic)
 */
function computeOperationId(req) {
    return ethers.keccak256(ethers.AbiCoder.defaultAbiCoder().encode(
        ["address", "uint256", "bytes32", "uint256", "uint256", "uint256"],
        [
            req.target,
            req.value,
            ethers.keccak256(
                typeof req.data === "string" ? ethers.getBytes(req.data) : req.data
            ),
            req.nonce,
            req.deadline,
            req.chainId,
        ]
    ));
}

/**
 * Utility: Get the EIP-712 digest for manual signing (e.g., hardware wallet)
 */
async function getSigningDigest(vault, req) {
    return await vault.getExecutionDigest(req);
}

/**
 * Utility: Build calldata for common ERC-20 operations
 */
const ERC20 = {
    transfer: (to, amount) => {
        const iface = new ethers.Interface(["function transfer(address to, uint256 amount)"]);
        return iface.encodeFunctionData("transfer", [to, amount]);
    },
    approve: (spender, amount) => {
        const iface = new ethers.Interface(["function approve(address spender, uint256 amount)"]);
        return iface.encodeFunctionData("approve", [spender, amount]);
    },
    transferFrom: (from, to, amount) => {
        const iface = new ethers.Interface(["function transferFrom(address from, address to, uint256 amount)"]);
        return iface.encodeFunctionData("transferFrom", [from, to, amount]);
    },
};

/**
 * Utility: Build calldata for common NFT operations
 */
const ERC721 = {
    transferFrom: (from, to, tokenId) => {
        const iface = new ethers.Interface(["function transferFrom(address from, address to, uint256 tokenId)"]);
        return iface.encodeFunctionData("transferFrom", [from, to, tokenId]);
    },
    safeTransferFrom: (from, to, tokenId) => {
        const iface = new ethers.Interface(["function safeTransferFrom(address from, address to, uint256 tokenId)"]);
        return iface.encodeFunctionData("safeTransferFrom", [from, to, tokenId]);
    },
};

// ─────────────────────────────────────────────────────────────────────────────
// MAIN — Parse args and run command
// ─────────────────────────────────────────────────────────────────────────────

async function main() {
    const args    = process.argv.slice(2);
    const command = args[0] || "check-nonce";

    // ── Setup ──────────────────────────────────────────────────────────────────
    const provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL);
    const network  = await provider.getNetwork();
    const signer   = new ethers.Wallet(CONFIG.PRIVATE_KEY, provider);
    const chainId  = Number(network.chainId);

    if (!CONFIG.VAULT_ADDR || !CONFIG.ORCHESTRATOR_ADDR) {
        console.error("❌ Missing vault/orchestrator addresses in deployment.json");
        process.exit(1);
    }

    const vault        = new ethers.Contract(CONFIG.VAULT_ADDR, EOA_VAULT_ABI, signer);
    const orchestrator = new ethers.Contract(CONFIG.ORCHESTRATOR_ADDR, ORCHESTRATOR_ABI, signer);

    console.log("\n╔═══════════════════════════════════════════╗");
    console.log("║   EOA DelegateCall System — Interact      ║");
    console.log("╚═══════════════════════════════════════════╝");
    console.log(`   Network:  ${network.name} (${chainId})`);
    console.log(`   EOA:      ${signer.address}`);
    console.log(`   Vault:    ${CONFIG.VAULT_ADDR}`);
    console.log(`   Orch:     ${CONFIG.ORCHESTRATOR_ADDR}`);
    console.log(`   Command:  ${command}`);

    // ── Route command ─────────────────────────────────────────────────────────
    switch (command) {

        case "send-eth": {
            const recipient = args[1];
            const amount    = args[2] || "0.01";
            await cmdSendETH(provider, signer, vault, orchestrator, chainId, recipient, amount);
            break;
        }

        case "call": {
            const target   = args[1];
            const funcSig  = args[2] || "transfer(address,uint256)";
            const funcArgs = args[3] ? JSON.parse(args[3]) : [];
            const value    = args[4] || "0";
            await cmdContractCall(provider, signer, vault, orchestrator, chainId, target, funcSig, funcArgs, value);
            break;
        }

        case "batch": {
            await cmdBatch(provider, signer, vault, orchestrator, chainId);
            break;
        }

        case "check-nonce": {
            await cmdCheckNonce(vault, orchestrator);
            break;
        }

        case "simulate": {
            const target = args[1] || "0x0000000000000000000000000000000000000001";
            const data   = args[2] || "0x";
            await cmdSimulate(signer, vault, orchestrator, chainId, target, data);
            break;
        }

        case "pause": {
            const tx = await vault.pause();
            await tx.wait();
            console.log("\n  ✅ Vault paused");
            break;
        }

        case "unpause": {
            const tx = await vault.unpause();
            await tx.wait();
            console.log("\n  ✅ Vault unpaused");
            break;
        }

        case "emergency": {
            await cmdEmergency(signer, vault);
            break;
        }

        case "digest": {
            // Compute signing digest for hardware wallet users
            const nonce   = await vault.getNonce();
            const target  = args[1] || "0x0000000000000000000000000000000000000001";
            const req     = buildExecutionRequest({ target, value: 0n, data: "0x", nonce, chainId });
            const digest  = await getSigningDigest(vault, req);
            const opId    = computeOperationId(req);
            console.log(`\n  Request:    ${JSON.stringify(req, (k,v) => typeof v === "bigint" ? v.toString() : v, 2)}`);
            console.log(`\n  EIP-712 Digest (sign this with hardware wallet):`);
            console.log(`  ${digest}`);
            console.log(`\n  Operation ID (for replay tracking):`);
            console.log(`  ${opId}`);
            break;
        }

        default:
            console.log("\n  ❌ Unknown command: " + command);
            console.log("  Usage: node interact.js [send-eth|call|batch|check-nonce|simulate|pause|emergency|digest]");
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// EXPORTS — For use as a module in tests or other scripts
// ─────────────────────────────────────────────────────────────────────────────

module.exports = {
    buildExecutionRequest,
    signExecutionRequest,
    signBatchExecution,
    submitToOrchestrator,
    computeOperationId,
    getSigningDigest,
    buildEIP712Domain,
    EIP712_TYPES,
    EIP712_BATCH_TYPES,
    ERC20,
    ERC721,
};

main().catch((e) => {
    console.error("\n❌ Error:", e.message || e);
    process.exit(1);
});