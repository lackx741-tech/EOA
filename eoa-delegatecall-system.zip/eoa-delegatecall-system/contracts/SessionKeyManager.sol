// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";

/**
 * @title SessionKeyManager
 * @notice Abstract contract that manages session keys for the EOA Vault system.
 *         Session keys are delegated signers with constrained permissions —
 *         they can execute calls on behalf of the vault owner, but only within
 *         the bounds set when the key was granted.
 *
 * @dev Inherits StorageLayout to read/write session key state into shared slots.
 *      Designed to be inherited by EOAVault.
 *
 * Permission Model:
 * ┌────────────────────────────────────────────────────────────────────────┐
 * │  validAfter / validUntil  │ Temporal window for key validity           │
 * │  maxValuePerCall          │ Max ETH per single execution               │
 * │  maxValueTotal            │ Lifetime ETH spending cap                  │
 * │  maxUsageCount            │ Max number of executions (0 = unlimited)   │
 * │  allowedSelectors         │ Whitelist of function selectors (empty=any)│
 * │  allowedTargets           │ Whitelist of target addresses (empty=any)  │
 * └────────────────────────────────────────────────────────────────────────┘
 */
abstract contract SessionKeyManager is StorageLayout {

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    event SessionKeyGranted(
        address indexed key,
        address indexed grantedBy,
        uint48  validAfter,
        uint48  validUntil,
        uint256 maxUsageCount,
        uint256 maxValuePerCall,
        uint256 maxValueTotal
    );

    event SessionKeyRevoked(address indexed key, address indexed revokedBy);

    event SessionKeyConsumed(
        address indexed key,
        address indexed target,
        uint256 value,
        uint256 usageCount
    );

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error SessionKey__NotFound(address key);
    error SessionKey__AlreadyActive(address key);
    error SessionKey__Revoked(address key);
    error SessionKey__Expired(address key, uint48 validUntil, uint48 now_);
    error SessionKey__NotYetValid(address key, uint48 validAfter, uint48 now_);
    error SessionKey__UsageLimitReached(address key, uint256 maxUsage, uint256 current);
    error SessionKey__ValueExceeded(address key, uint256 maxValue, uint256 attempted);
    error SessionKey__TotalValueExceeded(address key, uint256 budget, uint256 wouldSpend);
    error SessionKey__TargetNotAllowed(address key, address target);
    error SessionKey__SelectorNotAllowed(address key, bytes4 selector);
    error SessionKey__InvalidNonce(address key, uint256 expected, uint256 provided);

    // ─────────────────────────────────────────────────────────────────────────
    // OWNER-ONLY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Grants a session key with full permission configuration.
     * @dev    Only callable by the vault owner. The key must not already be active.
     *
     * @param key               The EOA address that will act as session key
     * @param validAfter        Unix timestamp: key is inactive before this
     * @param validUntil        Unix timestamp: key expires after this (0 = no expiry)
     * @param maxValuePerCall   Max ETH per single call (0 = no ETH allowed)
     * @param maxValueTotal     Lifetime ETH budget (0 = unlimited)
     * @param maxUsageCount     Max number of uses (0 = unlimited)
     * @param allowedSelectors  Whitelisted selectors (empty = any)
     * @param allowedTargets    Whitelisted targets (empty = any)
     */
    function grantSessionKey(
        address   key,
        uint48    validAfter,
        uint48    validUntil,
        uint256   maxValuePerCall,
        uint256   maxValueTotal,
        uint256   maxUsageCount,
        bytes4[]  calldata allowedSelectors,
        address[] calldata allowedTargets
    ) external {
        require(msg.sender == _owner, "SessionKeyManager: not owner");
        require(key != address(0),   "SessionKeyManager: zero key address");
        require(!_sessionKeys[key].active, "SessionKeyManager: key already active");

        if (validUntil != 0) {
            require(validUntil > block.timestamp, "SessionKeyManager: already expired");
            require(validAfter < validUntil,      "SessionKeyManager: invalid time range");
        }

        SessionKey storage sk = _sessionKeys[key];
        sk.active          = true;
        sk.validAfter      = validAfter;
        sk.validUntil      = validUntil;
        sk.maxValuePerCall = maxValuePerCall;
        sk.maxValueTotal   = maxValueTotal;
        sk.spentValue      = 0;
        sk.usageCount      = 0;
        sk.maxUsageCount   = maxUsageCount;

        // Copy arrays
        delete sk.allowedSelectors;
        for (uint256 i = 0; i < allowedSelectors.length; i++) {
            sk.allowedSelectors.push(allowedSelectors[i]);
        }

        delete sk.allowedTargets;
        for (uint256 i = 0; i < allowedTargets.length; i++) {
            sk.allowedTargets.push(allowedTargets[i]);
        }

        emit SessionKeyGranted(
            key,
            msg.sender,
            validAfter,
            validUntil,
            maxUsageCount,
            maxValuePerCall,
            maxValueTotal
        );
    }

    /**
     * @notice Revokes a session key, immediately preventing any further use.
     * @param key  The session key address to revoke
     */
    function revokeSessionKey(address key) external {
        require(
            msg.sender == _owner || msg.sender == key,
            "SessionKeyManager: not authorized"
        );
        require(_sessionKeys[key].active, "SessionKeyManager: key not active");

        _sessionKeys[key].active = false;
        emit SessionKeyRevoked(key, msg.sender);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VIEW FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Returns the full SessionKey struct for a given key address.
     */
    function getSessionKey(address key) external view returns (SessionKey memory) {
        return _sessionKeys[key];
    }

    /**
     * @notice Returns whether a session key is currently valid (active + within time window).
     */
    function isSessionKeyValid(address key) external view returns (bool) {
        return _isSessionKeyValid(key);
    }

    /**
     * @notice Returns the current replay-protection nonce for a session key.
     */
    function getSessionKeyNonce(address key) external view returns (uint256) {
        return _sessionKeyNonces[key];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Internal view: checks active + time window only (not usage/value).
     */
    function _isSessionKeyValid(address key) internal view returns (bool) {
        SessionKey storage sk = _sessionKeys[key];
        if (!sk.active) return false;
        if (sk.validAfter != 0 && block.timestamp < sk.validAfter) return false;
        if (sk.validUntil != 0 && block.timestamp > sk.validUntil) return false;
        return true;
    }

    /**
     * @notice Validates all session key permissions and records usage.
     * @dev    Called from EOAVault.executeSessionKey() before routing.
     *         Reverts with descriptive errors if any constraint is violated.
     *
     * @param key       The session key address
     * @param target    Target contract of the execution
     * @param value     ETH value of the execution
     * @param selector  4-byte selector of the call data (bytes4(0) if no data)
     */
    function _consumeSessionKey(
        address key,
        address target,
        uint256 value,
        bytes4  selector
    ) internal {
        SessionKey storage sk = _sessionKeys[key];

        // ── Existence check ────────────────────────────────────────────────
        if (!sk.active) {
            // Distinguish "never existed" from "revoked"
            revert SessionKey__Revoked(key);
        }

        // ── Temporal checks ───────────────────────────────────────────────
        if (sk.validAfter != 0 && block.timestamp < sk.validAfter) {
            revert SessionKey__NotYetValid(key, sk.validAfter, uint48(block.timestamp));
        }
        if (sk.validUntil != 0 && block.timestamp > sk.validUntil) {
            revert SessionKey__Expired(key, sk.validUntil, uint48(block.timestamp));
        }

        // ── Usage count check ─────────────────────────────────────────────
        if (sk.maxUsageCount != 0 && sk.usageCount >= sk.maxUsageCount) {
            revert SessionKey__UsageLimitReached(key, sk.maxUsageCount, sk.usageCount);
        }

        // ── Per-call value check ──────────────────────────────────────────
        if (value > 0) {
            if (sk.maxValuePerCall == 0) {
                // No ETH allowed at all
                revert SessionKey__ValueExceeded(key, 0, value);
            }
            if (value > sk.maxValuePerCall) {
                revert SessionKey__ValueExceeded(key, sk.maxValuePerCall, value);
            }
        }

        // ── Lifetime value budget check ───────────────────────────────────
        if (sk.maxValueTotal != 0 && value > 0) {
            uint256 wouldSpend = sk.spentValue + value;
            if (wouldSpend > sk.maxValueTotal) {
                revert SessionKey__TotalValueExceeded(key, sk.maxValueTotal, wouldSpend);
            }
        }

        // ── Target whitelist check ────────────────────────────────────────
        if (sk.allowedTargets.length > 0) {
            bool targetAllowed = false;
            for (uint256 i = 0; i < sk.allowedTargets.length; i++) {
                if (sk.allowedTargets[i] == target) {
                    targetAllowed = true;
                    break;
                }
            }
            if (!targetAllowed) {
                revert SessionKey__TargetNotAllowed(key, target);
            }
        }

        // ── Selector whitelist check ──────────────────────────────────────
        if (sk.allowedSelectors.length > 0 && selector != bytes4(0)) {
            bool selectorAllowed = false;
            for (uint256 i = 0; i < sk.allowedSelectors.length; i++) {
                if (sk.allowedSelectors[i] == selector) {
                    selectorAllowed = true;
                    break;
                }
            }
            if (!selectorAllowed) {
                revert SessionKey__SelectorNotAllowed(key, selector);
            }
        }

        // ── Record usage ──────────────────────────────────────────────────
        sk.usageCount++;
        if (value > 0) {
            sk.spentValue += value;
        }

        emit SessionKeyConsumed(key, target, value, sk.usageCount);
    }
}