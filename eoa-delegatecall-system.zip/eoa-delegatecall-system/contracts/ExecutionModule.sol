// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";
import "./SignatureVerifier.sol";

/**
 * @title ExecutionModule
 * @notice Stateless logic contract that is invoked via delegatecall from EOAVault.
 *         When delegatecalled, all code here executes in the STORAGE CONTEXT of
 *         the EOAVault — meaning msg.sender, msg.value, and all storage reads/writes
 *         affect the EOAVault's state, NOT this contract's state.
 *
 * @dev ╔══════════════════════════════════════════════════════════════════════╗
 *      ║  CRITICAL DELEGATECALL INVARIANT                                    ║
 *      ║  ─────────────────────────────────────────────────────────────────  ║
 *      ║  This contract MUST NEVER hold ETH or tokens.                       ║
 *      ║  This contract MUST NEVER use constructor-set state variables.      ║
 *      ║  All storage access maps to EOAVault's storage layout.              ║
 *      ║  StorageLayout inheritance ensures correct slot alignment.           ║
 *      ╚══════════════════════════════════════════════════════════════════════╝
 *
 * Module Capabilities:
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │ 1. execute()       │ Single authorized call (call or staticcall)        │
 * │ 2. executeBatch()  │ Atomic multi-call execution                        │
 * │ 3. executeRaw()    │ Low-level arbitrary call (unrestricted data)       │
 * │ 4. sendETH()       │ Native ETH transfer helper                         │
 * │ 5. selfUpgrade()   │ Updates module registry entry (governance)         │
 * └──────────────────────────────────────────────────────────────────────────┘
 */
contract ExecutionModule is StorageLayout {

    using SignatureVerifier for *;

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    event ModuleExecuted(
        address indexed target,
        uint256 value,
        bytes   data,
        bool    success,
        bytes   returnData
    );

    event BatchExecuted(
        uint256 indexed operationCount,
        uint256 indexed nonce,
        bool    allSucceeded
    );

    event ETHTransferred(
        address indexed recipient,
        uint256 amount
    );

    event ModuleUpgraded(
        bytes4  indexed selector,
        address indexed oldImpl,
        address indexed newImpl
    );

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error ExecutionModule__CallFailed(address target, bytes returnData);
    error ExecutionModule__ETHTransferFailed(address recipient, uint256 amount);
    error ExecutionModule__InvalidTarget(address target);
    error ExecutionModule__InsufficientBalance(uint256 available, uint256 required);
    error ExecutionModule__UnauthorizedCaller(address caller);
    error ExecutionModule__BatchTooLarge(uint256 size, uint256 maxSize);
    error ExecutionModule__ZeroAddressTarget();

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTANTS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Maximum number of operations in a single batch call
    uint256 public constant MAX_BATCH_SIZE = 32;

    /// @notice Minimum gas to reserve for post-execution cleanup
    uint256 public constant GAS_RESERVE = 10_000;

    // ─────────────────────────────────────────────────────────────────────────
    // MODIFIERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Ensures the function is called via delegatecall from the vault.
     *         When delegatecalled, address(this) = EOAVault address.
     *         When called directly, address(this) = ExecutionModule address.
     * @dev    We store the module's own deployed address at construction and
     *         compare it to address(this) at runtime. If they differ, we are
     *         inside a delegatecall context (expected behavior).
     */
    address private immutable _self;

    modifier onlyDelegatecall() {
        require(
            address(this) != _self,
            "ExecutionModule: must be called via delegatecall"
        );
        _;
    }

    /**
     * @notice Restricts execution to the registered orchestrator address
     * @dev    `_orchestrator` is read from EOAVault's storage (slot 1)
     *         because we are in delegatecall context
     */
    modifier onlyOrchestrator() {
        if (msg.sender != _orchestrator) {
            revert ExecutionModule__UnauthorizedCaller(msg.sender);
        }
        _;
    }

    /**
     * @notice Blocks calls when the vault is paused
     */
    modifier whenNotPaused() {
        require(!_paused, "ExecutionModule: vault is paused");
        _;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────────

    constructor() {
        // Capture this module's own address for delegatecall detection
        _self = address(this);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CORE EXECUTION — SINGLE CALL
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Executes a single authorized call to a target address
     * @dev    Called via delegatecall from EOAVault. Executes in EOAVault's context:
     *         - msg.sender = Orchestrator (the actual caller of delegatecall)
     *         - address(this) = EOAVault address
     *         - Storage reads/writes = EOAVault's storage
     *
     * @param target      Address to call
     * @param value       ETH to send with the call
     * @param data        ABI-encoded calldata
     * @param allowRevert If false, execution continues even if target reverts
     * @return success    Whether the call succeeded
     * @return returnData Data returned by the target
     */
    function execute(
        address target,
        uint256 value,
        bytes calldata data,
        bool allowRevert
    )
        external
        payable
        onlyDelegatecall
        onlyOrchestrator
        whenNotPaused
        returns (bool success, bytes memory returnData)
    {
        // ── Input validation ─────────────────────────────────────────────────
        if (target == address(0)) {
            revert ExecutionModule__ZeroAddressTarget();
        }

        // ── Balance check for ETH transfers ──────────────────────────────────
        if (value > 0 && address(this).balance < value) {
            revert ExecutionModule__InsufficientBalance(
                address(this).balance,
                value
            );
        }

        // ── Execute the call ─────────────────────────────────────────────────
        // Gas reservation ensures cleanup code can run even if target consumes
        // most available gas
        (success, returnData) = target.call{
            value: value,
            gas: gasleft() - GAS_RESERVE
        }(data);

        // ── Revert propagation ───────────────────────────────────────────────
        if (!success && allowRevert) {
            // Bubble up the revert reason from the target
            assembly {
                let returnDataSize := mload(returnData)
                revert(add(32, returnData), returnDataSize)
            }
        }

        emit ModuleExecuted(target, value, data, success, returnData);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CORE EXECUTION — BATCH CALLS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Executes multiple calls atomically in a single transaction
     * @dev    All calls are executed sequentially. If `atomic` is true, any
     *         failure reverts the entire batch. If false, failures are logged
     *         but execution continues.
     *
     * @param targets      Array of target addresses
     * @param values       Array of ETH values per call
     * @param dataArray    Array of calldata per call
     * @param atomic       If true, any failure reverts the entire batch
     * @return successes   Boolean array indicating per-call success
     * @return returnDatas Array of return data per call
     */
    function executeBatch(
        address[] calldata targets,
        uint256[] calldata values,
        bytes[]   calldata dataArray,
        bool      atomic
    )
        external
        payable
        onlyDelegatecall
        onlyOrchestrator
        whenNotPaused
        returns (bool[] memory successes, bytes[] memory returnDatas)
    {
        uint256 length = targets.length;

        // ── Batch size guard ─────────────────────────────────────────────────
        if (length > MAX_BATCH_SIZE) {
            revert ExecutionModule__BatchTooLarge(length, MAX_BATCH_SIZE);
        }

        require(
            length == values.length && length == dataArray.length,
            "ExecutionModule: array length mismatch"
        );

        successes   = new bool[](length);
        returnDatas = new bytes[](length);

        bool allSucceeded = true;

        for (uint256 i = 0; i < length; ) {
            if (targets[i] == address(0)) {
                revert ExecutionModule__ZeroAddressTarget();
            }

            // ── Execute individual call ──────────────────────────────────────
            (bool ok, bytes memory ret) = targets[i].call{
                value: values[i],
                gas: gasleft() - GAS_RESERVE
            }(dataArray[i]);

            successes[i]   = ok;
            returnDatas[i] = ret;

            if (!ok) {
                allSucceeded = false;

                if (atomic) {
                    // Bubble up the specific failure
                    assembly {
                        let retSize := mload(ret)
                        revert(add(32, ret), retSize)
                    }
                }
            }

            emit ModuleExecuted(targets[i], values[i], dataArray[i], ok, ret);

            unchecked { ++i; }
        }

        emit BatchExecuted(length, _nonce, allSucceeded);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ETH MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Transfers native ETH to a recipient
     * @dev    Uses low-level call instead of transfer() to avoid gas limit issues.
     *         This is the EOA-equivalent of a plain ETH send.
     *
     * @param recipient  Address to receive ETH
     * @param amount     Wei amount to send
     * @return success   True if transfer succeeded
     */
    function sendETH(
        address payable recipient,
        uint256 amount
    )
        external
        onlyDelegatecall
        onlyOrchestrator
        whenNotPaused
        returns (bool success)
    {
        if (recipient == address(0)) {
            revert ExecutionModule__ZeroAddressTarget();
        }

        if (address(this).balance < amount) {
            revert ExecutionModule__InsufficientBalance(
                address(this).balance,
                amount
            );
        }

        // Low-level call with minimal gas for plain ETH transfers
        // 2300 gas is sufficient for a plain receive(), consistent with EOA behavior
        (success, ) = recipient.call{value: amount, gas: 2300}("");

        if (!success) {
            // Fallback: try with more gas (recipient might be a contract with receive())
            (success, ) = recipient.call{value: amount}("");
        }

        if (!success) {
            revert ExecutionModule__ETHTransferFailed(recipient, amount);
        }

        // Update tracked balance
        _trackedBalance = address(this).balance;

        emit ETHTransferred(recipient, amount);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MODULE REGISTRY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Updates a function selector's registered implementation module
     * @dev    This is a governance operation — allows the vault owner to upgrade
     *         specific function routes without replacing the entire vault.
     *         Only callable by the vault owner through proper orchestration.
     *
     * @param selector   The 4-byte function selector to register
     * @param newModule  The new implementation address for this selector
     */
    function updateModuleRegistry(
        bytes4  selector,
        address newModule
    )
        external
        onlyDelegatecall
        onlyOrchestrator
    {
        require(newModule != address(0), "ExecutionModule: zero module address");

        address oldModule = _moduleRegistry[selector];
        _moduleRegistry[selector] = newModule;

        emit ModuleUpgraded(selector, oldModule, newModule);
    }

    /**
     * @notice Registers or updates a delegate (whitelisted module address)
     * @param delegate  Address to whitelist
     * @param approved  True to approve, false to revoke
     */
    function setDelegate(
        address delegate,
        bool approved
    )
        external
        onlyDelegatecall
        onlyOrchestrator
    {
        require(delegate != address(0), "ExecutionModule: zero delegate");
        _delegates[delegate] = approved;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STATIC CALL SUPPORT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Performs a staticcall (read-only) to a target contract
     * @dev    Used when the vault needs to query state without state changes
     *
     * @param target   Address to staticcall
     * @param data     Calldata to send
     * @return success Whether the staticcall succeeded
     * @return result  Returned data from the target
     */
    function staticQuery(
        address target,
        bytes calldata data
    )
        external
        view
        onlyDelegatecall
        returns (bool success, bytes memory result)
    {
        if (target == address(0)) {
            revert ExecutionModule__ZeroAddressTarget();
        }

        (success, result) = target.staticcall(data);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BALANCE TRACKING
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Syncs the tracked ETH balance with actual contract balance
     * @dev    Called after deposits or unexpected ETH receipts to keep accounting accurate
     */
    function syncBalance() external onlyDelegatecall onlyOrchestrator {
        _trackedBalance = address(this).balance;
    }

    /**
     * @notice Returns the tracked ETH balance (from storage slot 9)
     * @dev    In delegatecall context, reads from EOAVault's storage
     */
    function getTrackedBalance() external view onlyDelegatecall returns (uint256) {
        return _trackedBalance;
    }
}