// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";

/**
 * @title TokenClaimModule
 * @notice Delegatecall module enabling the EOA Vault to claim tokens, transfer
 *         ERC-20/721/1155 assets, and interact with airdrop distributors.
 *
 * @dev All functions run in the EOAVault's storage/balance context via delegatecall.
 *      The vault acts as the msg.sender to all target contracts.
 *      This module MUST NOT hold assets or state of its own.
 *
 * Capabilities:
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │  claimERC20()       │ Arbitrary call to a claim contract               │
 * │  claimWithMerkle()  │ Standard MerkleDistributor ABI claim             │
 * │  approveERC20()     │ ERC-20 approve                                   │
 * │  transferERC20()    │ ERC-20 transfer                                  │
 * │  transferFromERC20()│ ERC-20 transferFrom                              │
 * │  sweepERC20()       │ Transfer full ERC-20 balance to recipient        │
 * │  claimAndSweep()    │ Atomic claim + sweep                             │
 * │  transferERC721()   │ ERC-721 safeTransferFrom                         │
 * │  transferERC1155()  │ ERC-1155 safeTransferFrom                        │
 * │  setApprovalForAll()│ ERC-721/1155 setApprovalForAll                   │
 * └──────────────────────────────────────────────────────────────────────────┘
 */
contract TokenClaimModule is StorageLayout {

    // ─────────────────────────────────────────────────────────────────────────
    // DELEGATECALL GUARD
    // ─────────────────────────────────────────────────────────────────────────

    address private immutable _self;

    constructor() {
        _self = address(this);
    }

    modifier onlyDelegatecall() {
        require(
            address(this) != _self,
            "TokenClaimModule: must be called via delegatecall"
        );
        _;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error TokenClaimModule__CallFailed(address target, bytes returnData);
    error TokenClaimModule__ZeroAddress();
    error TokenClaimModule__InsufficientBalance(uint256 available, uint256 required);

    // ─────────────────────────────────────────────────────────────────────────
    // ERC-20 CLAIM OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Perform an arbitrary claim call to a distributor contract.
     * @dev    Encodes and forwards `callData` to `claimContract`. The vault is
     *         the caller, so any airdrop addressed to the vault is claimed here.
     *
     * @param claimContract  The airdrop/distributor contract address
     * @param callData       ABI-encoded call to forward (e.g. claim(index, amount, proof))
     * @return returnData    Data returned by the claim contract
     */
    function claimERC20(
        address claimContract,
        bytes calldata callData
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (claimContract == address(0)) revert TokenClaimModule__ZeroAddress();

        bool success;
        (success, returnData) = claimContract.call(callData);
        if (!success) revert TokenClaimModule__CallFailed(claimContract, returnData);
    }

    /**
     * @notice Claim tokens from a standard MerkleDistributor (Uniswap / common ABI).
     * @dev    Calls `claim(uint256 index, address account, uint256 amount, bytes32[] proof)`
     *         with the vault address as the account.
     *
     * @param distributor  The MerkleDistributor contract
     * @param index        Leaf index in the Merkle tree
     * @param amount       Token amount to claim (in token decimals)
     * @param merkleProof  Proof path from leaf to root
     */
    function claimWithMerkle(
        address   distributor,
        uint256   index,
        uint256   amount,
        bytes32[] calldata merkleProof
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (distributor == address(0)) revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "claim(uint256,address,uint256,bytes32[])",
            index,
            address(this),   // account = vault (delegatecall context)
            amount,
            merkleProof
        );

        bool success;
        (success, returnData) = distributor.call(data);
        if (!success) revert TokenClaimModule__CallFailed(distributor, returnData);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ERC-20 TRANSFER OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Approve a spender for an ERC-20 token.
     * @param token    ERC-20 token address
     * @param spender  Address to approve
     * @param amount   Allowance amount
     */
    function approveERC20(
        address token,
        address spender,
        uint256 amount
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || spender == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "approve(address,uint256)",
            spender,
            amount
        );
        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    /**
     * @notice Transfer ERC-20 tokens from the vault to a recipient.
     * @param token      ERC-20 token address
     * @param recipient  Recipient address
     * @param amount     Amount to transfer
     */
    function transferERC20(
        address token,
        address recipient,
        uint256 amount
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || recipient == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "transfer(address,uint256)",
            recipient,
            amount
        );
        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    /**
     * @notice Transfer ERC-20 tokens on behalf of another address (vault must be approved).
     * @param token      ERC-20 token address
     * @param from       Address to transfer from
     * @param amount     Amount to transfer (to vault)
     */
    function transferFromERC20(
        address token,
        address from,
        uint256 amount
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || from == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "transferFrom(address,address,uint256)",
            from,
            address(this),
            amount
        );
        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    /**
     * @notice Transfer the vault's entire ERC-20 balance to a recipient.
     * @dev    Queries balanceOf(vault), then calls transfer().
     * @param token      ERC-20 token address
     * @param recipient  Recipient for the swept tokens
     * @return swept     Amount swept
     */
    function sweepERC20(
        address token,
        address recipient
    )
        external
        onlyDelegatecall
        returns (uint256 swept)
    {
        if (token == address(0) || recipient == address(0))
            revert TokenClaimModule__ZeroAddress();

        // Query balance
        (bool ok, bytes memory balData) = token.staticcall(
            abi.encodeWithSignature("balanceOf(address)", address(this))
        );
        require(ok, "TokenClaimModule: balanceOf failed");
        swept = abi.decode(balData, (uint256));

        if (swept == 0) return 0;

        // Transfer full balance
        bytes memory transferData = abi.encodeWithSignature(
            "transfer(address,uint256)",
            recipient,
            swept
        );
        (bool success, bytes memory ret) = token.call(transferData);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    /**
     * @notice Atomically claim tokens and sweep them to a recipient in one transaction.
     * @param claimContract  The claim/airdrop contract
     * @param claimCallData  Calldata for the claim call
     * @param token          ERC-20 token to sweep after claiming
     * @param recipient      Where to send the claimed tokens
     * @return swept         Amount swept to recipient
     */
    function claimAndSweep(
        address claimContract,
        bytes calldata claimCallData,
        address token,
        address recipient
    )
        external
        onlyDelegatecall
        returns (uint256 swept)
    {
        if (claimContract == address(0) || token == address(0) || recipient == address(0))
            revert TokenClaimModule__ZeroAddress();

        // Step 1: Claim
        (bool claimOk, bytes memory claimRet) = claimContract.call(claimCallData);
        if (!claimOk) revert TokenClaimModule__CallFailed(claimContract, claimRet);

        // Step 2: Query balance
        (bool balOk, bytes memory balData) = token.staticcall(
            abi.encodeWithSignature("balanceOf(address)", address(this))
        );
        require(balOk, "TokenClaimModule: balanceOf failed");
        swept = abi.decode(balData, (uint256));

        if (swept == 0) return 0;

        // Step 3: Sweep
        bytes memory transferData = abi.encodeWithSignature(
            "transfer(address,uint256)",
            recipient,
            swept
        );
        (bool transferOk, bytes memory transferRet) = token.call(transferData);
        if (!transferOk) revert TokenClaimModule__CallFailed(token, transferRet);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ERC-721 OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Transfer an ERC-721 token from the vault to a recipient.
     * @param token      ERC-721 contract address
     * @param recipient  Destination address
     * @param tokenId    Token ID to transfer
     */
    function transferERC721(
        address token,
        address recipient,
        uint256 tokenId
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || recipient == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "safeTransferFrom(address,address,uint256)",
            address(this),
            recipient,
            tokenId
        );
        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ERC-1155 OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Transfer ERC-1155 tokens from the vault to a recipient.
     * @param token      ERC-1155 contract address
     * @param recipient  Destination address
     * @param tokenId    Token ID
     * @param amount     Amount to transfer
     * @param data       Extra data for safeTransferFrom
     */
    function transferERC1155(
        address token,
        address recipient,
        uint256 tokenId,
        uint256 amount,
        bytes calldata data
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || recipient == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory callData = abi.encodeWithSignature(
            "safeTransferFrom(address,address,uint256,uint256,bytes)",
            address(this),
            recipient,
            tokenId,
            amount,
            data
        );
        (bool success, bytes memory ret) = token.call(callData);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }

    /**
     * @notice Set or remove approval for an operator on ERC-721 or ERC-1155.
     * @param token     Token contract address
     * @param operator  Address to grant/revoke operator status
     * @param approved  True to approve, false to revoke
     */
    function setApprovalForAll(
        address token,
        address operator,
        bool    approved
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || operator == address(0))
            revert TokenClaimModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "setApprovalForAll(address,bool)",
            operator,
            approved
        );
        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert TokenClaimModule__CallFailed(token, ret);
    }
}