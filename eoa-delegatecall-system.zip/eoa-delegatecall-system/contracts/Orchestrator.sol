// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";
import "./SignatureVerifier.sol";
import "./NonceManager.sol";

/**
 * @title Orchestrator
 * @notice The central coordination and policy enforcement layer between the
 *         off-chain EOA signer and the on-chain EOAVault. It is the ONLY
 *         authorized caller of the vault's execution functions.
 *
 * @dev ╔══════════════════════════════════════════════════════════════════════╗
 *      ║  ORCHESTRATOR RESPONSIBILITIES                                      ║
 *      ║  ─────────────────────────────────────────────────────────────────  ║
 *      ║  1. Receives signed ExecutionRequests from off-chain EOA            ║
 *      ║  2. Validates ECDSA signatures against the vault's owner            ║
 *      ║  3. Enforces nonce ordering and deadline constraints                ║
 *      ║  4. Enforces call policies (target whitelist, value limits)         ║
 *      ║  5. Routes validated calls to the EOAVault via delegatecall         ║
 *      ║  6. Manages timelocked operations for high-value transactions       ║
 *      ║  7. Emits a comprehensive audit trail of all operations             ║
 *      ╚══════════════════════════════════════════════════════════════════════╝
 *
 * Trust Model:
 *  ┌─────────────────────────────────────────────────────────────────────┐
 *  │  EOA (signer) ──signs──► Orchestrator ──validates──► EOAVault       │
 *  │                          │                           │              │
 *  │                          │ enforces policies         │ delegatecall │
 *  │                          │ validates signatures      │              │
 *  │                          │ manages timelocks         ▼              │
 *  │                                                 ExecutionModule     │
 *  │                                                      │              │
 *  │                                                      │ call         │
 *  │                                                      ▼              │
 *  │                                               Target Contract       │
 *  └─────────────────────────────────────────────────────────────────────┘
 */
contract Orchestrator {

    using SignatureVerifier for *;

    // ─────────────────────────────────────────────────────────────────────────
    // STRUCTS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Call policy configuration for a specific target address
     * @param allowed        Whether calls to this target are permitted
     * @param maxValue       Maximum ETH value allowed per single call (0 = no ETH)
     * @param requiresDelay  Whether calls to this target need timelock delay
     * @param delaySeconds   Timelock delay in seconds (if requiresDelay = true)
     * @param selector       If non-zero, only this selector is permitted on this target
     */
    struct CallPolicy {
        bool    allowed;
        uint256 maxValue;
        bool    requiresDelay;
        uint256 delaySeconds;
        bytes4  allowedSelector; // zero = any selector allowed
    }

    /**
     * @notice A queued (timelocked) operation awaiting execution
     * @param vault          The vault to execute through
     * @param req            The execution request
     * @param signature      EOA's signature
     * @param scheduledAt    Block timestamp when queued
     * @param executed       Whether this operation has been executed
     * @param cancelled      Whether this operation was cancelled
     */
    struct QueuedOperation {
        address                          vault;
        SignatureVerifier.ExecutionRequest req;
        bytes                            signature;
        uint256                          scheduledAt;
        bool                             executed;
        bool                             cancelled;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STATE VARIABLES
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Admin address (can update policies, not execute operations)
    address public admin;

    /// @notice Pending admin for two-step admin transfer
    address public pendingAdmin;

    /// @notice The VaultFactory address authorized to register vaults during deployment
    address public immutable factory;

    /// @notice Default timelock delay for high-value operations (seconds)
    uint256 public defaultTimelockDelay;

    /// @notice Maximum ETH value per call that bypasses timelock (in wei)
    uint256 public timelockValueThreshold;

    /// @notice Whether the orchestrator itself is paused
    bool public orchestratorPaused;

    /// @notice Registered vault addresses (only these can be orchestrated)
    mapping(address => bool) public registeredVaults;

    /// @notice Call policies per target address
    mapping(address => CallPolicy) public callPolicies;

    /// @notice Global target whitelist mode: if true, only whitelisted targets allowed
    bool public whitelistMode;

    /// @notice Queued operations awaiting timelock execution
    mapping(bytes32 => QueuedOperation) public queuedOperations;

    /// @notice Operation IDs that have been consumed (replay protection at orchestrator level)
    mapping(bytes32 => bool) public consumedOperations;

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    event OperationExecuted(
        bytes32 indexed operationId,
        address indexed vault,
        address indexed target,
        uint256 value,
        uint256 nonce,
        bool    success
    );

    event BatchOperationExecuted(
        bytes32 indexed batchId,
        address indexed vault,
        uint256 operationCount,
        uint256 nonce,
        bool    success
    );

    event OperationQueued(
        bytes32 indexed operationId,
        address indexed vault,
        address indexed target,
        uint256 scheduledAt,
        uint256 executeAfter
    );

    event OperationExecutedFromQueue(
        bytes32 indexed operationId,
        address indexed executor
    );

    event OperationCancelled(
        bytes32 indexed operationId,
        address indexed cancelledBy
    );

    event VaultRegistered(address indexed vault, address indexed by);
    event VaultDeregistered(address indexed vault);
    event PolicyUpdated(address indexed target, CallPolicy policy);
    event AdminTransferInitiated(address indexed currentAdmin, address indexed pendingAdmin);
    event AdminTransferCompleted(address indexed previousAdmin, address indexed newAdmin);
    event OrchestratorPaused(address indexed by);
    event OrchestratorUnpaused(address indexed by);
    event TimelockThresholdUpdated(uint256 oldThreshold, uint256 newThreshold);

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error Orchestrator__NotAdmin(address caller);
    error Orchestrator__Paused();
    error Orchestrator__VaultNotRegistered(address vault);
    error Orchestrator__InvalidSignature(address recovered, address expected);
    error Orchestrator__TargetNotAllowed(address target);
    error Orchestrator__ValueExceedsPolicy(uint256 value, uint256 max);
    error Orchestrator__SelectorNotAllowed(bytes4 selector, address target);
    error Orchestrator__DeadlineExpired(uint256 deadline, uint256 now_);
    error Orchestrator__ChainIdMismatch(uint256 expected, uint256 provided);
    error Orchestrator__OperationAlreadyConsumed(bytes32 operationId);
    error Orchestrator__TimelockRequired(bytes32 operationId, uint256 executeAfter);
    error Orchestrator__TimelockNotExpired(uint256 executeAfter, uint256 now_);
    error Orchestrator__OperationNotQueued(bytes32 operationId);
    error Orchestrator__OperationAlreadyExecuted(bytes32 operationId);
    error Orchestrator__OperationCancelled(bytes32 operationId);
    error Orchestrator__ExecutionFailed(address vault, bytes returnData);
    error Orchestrator__NonceMismatch(uint256 expected, uint256 provided);
    error Orchestrator__ZeroAddress();

    // ─────────────────────────────────────────────────────────────────────────
    // MODIFIERS
    // ─────────────────────────────────────────────────────────────────────────

    modifier onlyAdmin() {
        if (msg.sender != admin) revert Orchestrator__NotAdmin(msg.sender);
        _;
    }

    modifier whenNotPaused() {
        if (orchestratorPaused) revert Orchestrator__Paused();
        _;
    }

    modifier onlyRegisteredVault(address vault) {
        if (!registeredVaults[vault]) {
            revert Orchestrator__VaultNotRegistered(vault);
        }
        _;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Deploys the Orchestrator with an admin and default settings
     * @param _admin                   The administrator address
     * @param _defaultTimelockDelay    Default delay for timelocked operations (seconds)
     * @param _timelockValueThreshold  ETH value above which timelock is required (wei)
     */
    constructor(
        address _admin,
        uint256 _defaultTimelockDelay,
        uint256 _timelockValueThreshold
    ) {
        require(_admin != address(0), "Orchestrator: zero admin address");

        admin                   = _admin;
        factory                 = msg.sender; // VaultFactory is the authorized registrar
        defaultTimelockDelay    = _defaultTimelockDelay;
        timelockValueThreshold  = _timelockValueThreshold;
        whitelistMode           = false; // open mode by default
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PRIMARY EXECUTION — SINGLE OPERATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Execute a single signed operation through a registered vault
     * @dev    FULL EXECUTION FLOW:
     *           Step 1: Validate vault is registered
     *           Step 2: Validate request temporal context (deadline, chainId)
     *           Step 3: Verify ECDSA signature against vault owner
     *           Step 4: Check orchestrator-level replay protection
     *           Step 5: Enforce call policies (target whitelist, value limits)
     *           Step 6: Check if timelock is required (high-value operations)
     *           Step 7: Mark operation as consumed
     *           Step 8: Route call to vault → delegatecall → ExecutionModule
     *           Step 9: Emit audit event
     *
     * @param vault      The EOAVault to execute through
     * @param req        The signed execution request
     * @param signature  65-byte ECDSA signature from the vault's owner EOA
     */
    function execute(
        address vault,
        SignatureVerifier.ExecutionRequest calldata req,
        bytes calldata signature
    )
        external
        whenNotPaused
        onlyRegisteredVault(vault)
    {
        // ── Step 1: Temporal and chain validation ────────────────────────────
        _validateTemporalContext(req.deadline, req.chainId);

        // ── Step 1b: Validate sequential nonce ─────────────────────────────────────────
        {
            uint256 expectedNonce = IEOAVault(vault).getNonce();
            if (req.nonce != expectedNonce) {
                revert Orchestrator__NonceMismatch(expectedNonce, req.nonce);
            }
        }

        // ── Step 2: Retrieve vault owner and domain separator ────────────────
        (address vaultOwner, bytes32 domainSeparator) = _getVaultContext(vault);

        // ── Step 3: Verify ECDSA signature ───────────────────────────────────
        bool sigValid = SignatureVerifier.verifyExecutionRequest(
            domainSeparator,
            req,
            signature,
            vaultOwner
        );

        if (!sigValid) {
            address recovered = SignatureVerifier.recoverExecutionSigner(
                domainSeparator, req, signature
            );
            revert Orchestrator__InvalidSignature(recovered, vaultOwner);
        }

        // ── Step 4: Compute operation ID and check replay ────────────────────
        bytes32 operationId = SignatureVerifier.computeOperationId(req);

        if (consumedOperations[operationId]) {
            revert Orchestrator__OperationAlreadyConsumed(operationId);
        }

        // ── Step 5: Enforce call policies ────────────────────────────────────
        bytes4 reqSelector;
        if (req.data.length >= 4) {
            bytes memory reqData = req.data;
            assembly { reqSelector := mload(add(reqData, 32)) }
        }
        _enforceCallPolicy(req.target, req.value, reqSelector);

        // ── Step 6: Check timelock requirement ───────────────────────────────
        CallPolicy memory policy = callPolicies[req.target];
        bool needsTimelock = (
            policy.requiresDelay ||
            req.value >= timelockValueThreshold
        );

        if (needsTimelock) {
            // Queue the operation instead of executing immediately
            // Note: _queueOperation always reverts with Orchestrator__TimelockRequired
            _queueOperation(vault, req, signature, operationId, policy.delaySeconds);
        }

        // ── Step 7: Mark consumed ────────────────────────────────────────────
        consumedOperations[operationId] = true;

        // ── Step 8: Route to vault ───────────────────────────────────────────
        bool success = _routeToVault(vault, req, operationId);

        // ── Step 9: Emit audit event ─────────────────────────────────────────
        emit OperationExecuted(
            operationId,
            vault,
            req.target,
            req.value,
            req.nonce,
            success
        );
    }

    /**
     * @notice Execute a signed batch of operations atomically
     * @dev    All operations in the batch must share the same nonce and deadline.
     *         The entire batch succeeds or fails atomically if `atomic` is true.
     *
     * @param vault      The EOAVault to execute through
     * @param batch      The signed batch execution request
     * @param signature  65-byte ECDSA signature from the vault's owner EOA
     * @param atomic     If true, any failure reverts the entire batch
     */
    function executeBatch(
        address vault,
        SignatureVerifier.BatchExecution calldata batch,
        bytes calldata signature,
        bool atomic
    )
        external
        whenNotPaused
        onlyRegisteredVault(vault)
    {
        // ── Temporal validation ──────────────────────────────────────────────
        _validateTemporalContext(batch.deadline, batch.chainId);

        // ── Vault context ────────────────────────────────────────────────────
        (address vaultOwner, bytes32 domainSeparator) = _getVaultContext(vault);

        // ── Signature verification ───────────────────────────────────────────
        bool sigValid = SignatureVerifier.verifyBatchExecution(
            domainSeparator,
            batch,
            signature,
            vaultOwner
        );

        if (!sigValid) {
            address recovered = SignatureVerifier.recoverBatchSigner(
                domainSeparator, batch, signature
            );
            revert Orchestrator__InvalidSignature(recovered, vaultOwner);
        }

        // ── Batch ID and replay check ────────────────────────────────────────
        bytes32 batchId = SignatureVerifier.computeBatchOperationId(batch);

        if (consumedOperations[batchId]) {
            revert Orchestrator__OperationAlreadyConsumed(batchId);
        }

        // ── Per-operation policy enforcement ─────────────────────────────────
        for (uint256 i = 0; i < batch.operations.length; i++) {
            SignatureVerifier.ExecutionRequest memory op = batch.operations[i];
            if (op.data.length >= 4) {
                bytes4 opSelector;
                bytes memory opData = op.data;
                assembly { opSelector := mload(add(opData, 32)) }
                _enforceCallPolicy(op.target, op.value, opSelector);
            }
        }

        // ── Mark consumed ────────────────────────────────────────────────────
        consumedOperations[batchId] = true;

        // ── Build and route batch call ───────────────────────────────────────
        uint256 opCount = batch.operations.length;
        bytes memory batchCallData = _encodeBatchCall(batch, atomic);
        bytes4 batchSelector = bytes4(keccak256("executeBatch(address[],uint256[],bytes[],bool)"));

        // Route to vault for delegatecall execution
        IEOAVault(vault).executeFromOrchestrator(
            batchSelector,
            batchCallData,
            batch.nonce
        );

        emit BatchOperationExecuted(batchId, vault, opCount, batch.nonce, true);
    }

    /**
     * @dev Internal helper to encode batch calldata. Extracted to reduce stack
     *      depth in executeBatch() and avoid "Stack too deep" compilation errors.
     */
    function _encodeBatchCall(
        SignatureVerifier.BatchExecution calldata batch,
        bool atomic
    ) private pure returns (bytes memory) {
        uint256 opCount = batch.operations.length;
        address[] memory targets = new address[](opCount);
        uint256[] memory values  = new uint256[](opCount);
        bytes[]   memory dataArr = new bytes[](opCount);

        for (uint256 i = 0; i < opCount; i++) {
            targets[i] = batch.operations[i].target;
            values[i]  = batch.operations[i].value;
            dataArr[i] = batch.operations[i].data;
        }

        return abi.encodeWithSignature(
            "executeBatch(address[],uint256[],bytes[],bool)",
            targets,
            values,
            dataArr,
            atomic
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // TIMELOCK QUEUE MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Executes a previously queued (timelocked) operation
     * @dev    Anyone can trigger execution of a queued operation after the delay.
     *         The original signature is re-verified to ensure integrity.
     *
     * @param operationId  The ID of the queued operation to execute
     */
    function executeQueued(bytes32 operationId)
        external
        whenNotPaused
    {
        QueuedOperation storage op = queuedOperations[operationId];

        if (op.scheduledAt == 0) {
            revert Orchestrator__OperationNotQueued(operationId);
        }
        if (op.executed) {
            revert Orchestrator__OperationAlreadyExecuted(operationId);
        }
        if (op.cancelled) {
            revert Orchestrator__OperationCancelled(operationId);
        }

        // Check timelock delay has passed
        CallPolicy memory policy = callPolicies[op.req.target];
        uint256 delay = policy.requiresDelay
            ? policy.delaySeconds
            : defaultTimelockDelay;

        uint256 executeAfter = op.scheduledAt + delay;

        if (block.timestamp < executeAfter) {
            revert Orchestrator__TimelockNotExpired(executeAfter, block.timestamp);
        }

        // Check request hasn't expired
        if (block.timestamp > op.req.deadline) {
            revert Orchestrator__DeadlineExpired(op.req.deadline, block.timestamp);
        }

        // Mark as executed before external calls (CEI pattern)
        op.executed = true;
        consumedOperations[operationId] = true;

        // Route to vault
        bool success = _routeToVault(op.vault, op.req, operationId);

        emit OperationExecutedFromQueue(operationId, msg.sender);
        emit OperationExecuted(
            operationId,
            op.vault,
            op.req.target,
            op.req.value,
            op.req.nonce,
            success
        );
    }

    /**
     * @notice Cancels a queued operation before it is executed
     * @dev    Only callable by the vault owner or orchestrator admin
     * @param vault        The vault the operation was queued for
     * @param operationId  The operation to cancel
     */
    function cancelQueuedOperation(
        address vault,
        bytes32 operationId
    ) external {
        QueuedOperation storage op = queuedOperations[operationId];

        if (op.scheduledAt == 0) {
            revert Orchestrator__OperationNotQueued(operationId);
        }
        if (op.executed) {
            revert Orchestrator__OperationAlreadyExecuted(operationId);
        }
        if (op.cancelled) {
            revert Orchestrator__OperationCancelled(operationId);
        }

        // Only admin or the vault's owner can cancel
        (address vaultOwner, ) = _getVaultContext(vault);
        require(
            msg.sender == admin || msg.sender == vaultOwner,
            "Orchestrator: not authorized to cancel"
        );

        op.cancelled = true;

        emit OperationCancelled(operationId, msg.sender);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VAULT REGISTRY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Registers an EOAVault as eligible for orchestration
     * @param vault  The vault address to register
     */
    function registerVault(address vault) external {
        if (msg.sender != admin && msg.sender != factory)
            revert Orchestrator__NotAdmin(msg.sender);
        if (vault == address(0)) revert Orchestrator__ZeroAddress();
        registeredVaults[vault] = true;
        emit VaultRegistered(vault, msg.sender);
    }

    /**
     * @notice Removes a vault from the registry
     * @param vault  The vault address to deregister
     */
    function deregisterVault(address vault) external onlyAdmin {
        registeredVaults[vault] = false;
        emit VaultDeregistered(vault);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // POLICY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Sets or updates a call policy for a target address
     * @param target  The target address the policy applies to
     * @param policy  The CallPolicy configuration
     */
    function setCallPolicy(
        address target,
        CallPolicy calldata policy
    ) external onlyAdmin {
        if (target == address(0)) revert Orchestrator__ZeroAddress();
        callPolicies[target] = policy;
        emit PolicyUpdated(target, policy);
    }

    /**
     * @notice Enables or disables whitelist mode
     * @dev    When enabled, only targets with `policy.allowed = true` can be called
     * @param enabled  True to enable whitelist mode
     */
    function setWhitelistMode(bool enabled) external onlyAdmin {
        whitelistMode = enabled;
    }

    /**
     * @notice Updates the value threshold above which timelock is required
     * @param newThreshold  New threshold in wei
     */
    function setTimelockValueThreshold(uint256 newThreshold) external onlyAdmin {
        uint256 old = timelockValueThreshold;
        timelockValueThreshold = newThreshold;
        emit TimelockThresholdUpdated(old, newThreshold);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ADMIN MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Initiates a two-step admin transfer
     * @param newAdmin  The proposed new admin address
     */
    function transferAdmin(address newAdmin) external onlyAdmin {
        if (newAdmin == address(0)) revert Orchestrator__ZeroAddress();
        pendingAdmin = newAdmin;
        emit AdminTransferInitiated(admin, newAdmin);
    }

    /**
     * @notice Completes the admin transfer (called by pending admin)
     */
    function acceptAdmin() external {
        require(msg.sender == pendingAdmin, "Orchestrator: not pending admin");
        address old = admin;
        admin        = pendingAdmin;
        pendingAdmin = address(0);
        emit AdminTransferCompleted(old, admin);
    }

    /// @notice Pauses the orchestrator
    function pause() external onlyAdmin {
        orchestratorPaused = true;
        emit OrchestratorPaused(msg.sender);
    }

    /// @notice Unpauses the orchestrator
    function unpause() external onlyAdmin {
        orchestratorPaused = false;
        emit OrchestratorUnpaused(msg.sender);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Validates temporal context of a request
     */
    function _validateTemporalContext(uint256 deadline, uint256 chainId) internal view {
        if (block.timestamp > deadline) {
            revert Orchestrator__DeadlineExpired(deadline, block.timestamp);
        }
        if (chainId != block.chainid) {
            revert Orchestrator__ChainIdMismatch(block.chainid, chainId);
        }
    }

    /**
     * @notice Retrieves the vault owner and domain separator via interface calls
     */
    function _getVaultContext(address vault)
        internal
        view
        returns (address vaultOwner, bytes32 domainSeparator)
    {
        vaultOwner      = IEOAVault(vault).owner();
        domainSeparator = IEOAVault(vault).DOMAIN_SEPARATOR();
    }

    /**
     * @notice Enforces the call policy for a given target
     */
    function _enforceCallPolicy(
        address target,
        uint256 value,
        bytes4  selector
    ) internal view {
        CallPolicy memory policy = callPolicies[target];

        // In whitelist mode, target must be explicitly allowed
        if (whitelistMode && !policy.allowed) {
            revert Orchestrator__TargetNotAllowed(target);
        }

        // Value check against policy maximum
        if (policy.allowed && value > policy.maxValue && policy.maxValue != 0) {
            revert Orchestrator__ValueExceedsPolicy(value, policy.maxValue);
        }

        // Selector restriction check
        if (
            policy.allowed &&
            policy.allowedSelector != bytes4(0) &&
            selector != policy.allowedSelector
        ) {
            revert Orchestrator__SelectorNotAllowed(selector, target);
        }
    }

    /**
     * @notice Queues an operation for time-delayed execution
     */
    function _queueOperation(
        address vault,
        SignatureVerifier.ExecutionRequest calldata req,
        bytes calldata signature,
        bytes32 operationId,
        uint256 delaySeconds
    ) internal {
        uint256 delay = delaySeconds > 0 ? delaySeconds : defaultTimelockDelay;

        queuedOperations[operationId] = QueuedOperation({
            vault:       vault,
            req:         req,
            signature:   signature,
            scheduledAt: block.timestamp,
            executed:    false,
            cancelled:   false
        });

        emit OperationQueued(
            operationId,
            vault,
            req.target,
            block.timestamp,
            block.timestamp + delay
        );

        // Queue the timelock at vault level too
        revert Orchestrator__TimelockRequired(operationId, block.timestamp + delay);
    }

    /**
     * @notice Routes a validated execution request to the vault
     * @dev    Encodes the appropriate ExecutionModule function call and
     *         forwards it to the vault for delegatecall dispatch.
     */
    function _routeToVault(
        address vault,
        SignatureVerifier.ExecutionRequest memory req,
        bytes32 /*operationId*/
    ) internal returns (bool success) {
        // Encode the execute() call for ExecutionModule
        bytes memory moduleCallData = abi.encodeWithSignature(
            "execute(address,uint256,bytes,bool)",
            req.target,
            req.value,
            req.data,
            true  // allowRevert = true (propagate failures)
        );

        bytes4 executeSelector = bytes4(
            keccak256("execute(address,uint256,bytes,bool)")
        );

        try IEOAVault(vault).executeFromOrchestrator{value: 0}(
            executeSelector,
            moduleCallData,
            req.nonce
        ) returns (bytes memory) {
            success = true;
        } catch (bytes memory revertData) {
            success = false;
            revert Orchestrator__ExecutionFailed(vault, revertData);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VIEW FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Checks whether an operation has been consumed
     */
    function isOperationConsumed(bytes32 operationId)
        external
        view
        returns (bool)
    {
        return consumedOperations[operationId];
    }

    /**
     * @notice Returns details of a queued operation
     */
    function getQueuedOperation(bytes32 operationId)
        external
        view
        returns (QueuedOperation memory)
    {
        return queuedOperations[operationId];
    }

    /**
     * @notice Simulates whether an execution request would pass orchestrator validation
     */
    function simulateExecution(
        address vault,
        SignatureVerifier.ExecutionRequest calldata req,
        bytes calldata signature
    ) external view returns (bool valid, string memory reason) {
        // Temporal check
        if (block.timestamp > req.deadline) return (false, "DEADLINE_EXPIRED");
        if (req.chainId != block.chainid)    return (false, "CHAIN_ID_MISMATCH");

        // Vault registration
        if (!registeredVaults[vault]) return (false, "VAULT_NOT_REGISTERED");

        // Signature check
        (address vaultOwner, bytes32 domainSep) = _getVaultContext(vault);
        bool sigValid = SignatureVerifier.verifyExecutionRequest(
            domainSep, req, signature, vaultOwner
        );
        if (!sigValid) return (false, "INVALID_SIGNATURE");

        // Replay check
        bytes32 opId = SignatureVerifier.computeOperationId(req);
        if (consumedOperations[opId]) return (false, "ALREADY_CONSUMED");

        // Policy check
        CallPolicy memory policy = callPolicies[req.target];
        if (whitelistMode && !policy.allowed) return (false, "TARGET_NOT_WHITELISTED");

        return (true, "");
    }

    /// @notice Accept ETH (needed to forward value with calls)
    receive() external payable {}
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE — EOAVault (minimal interface used by Orchestrator)
// ─────────────────────────────────────────────────────────────────────────────

interface IEOAVault {
    function owner()            external view returns (address);
    function DOMAIN_SEPARATOR() external view returns (bytes32);
    function getNonce()         external view returns (uint256);
    function isPaused()         external view returns (bool);

    function executeFromOrchestrator(
        bytes4  selector,
        bytes calldata callData,
        uint256 nonce
    ) external payable returns (bytes memory);

    function executeDirectModule(
        address module,
        bytes calldata callData,
        uint256 nonce
    ) external payable returns (bytes memory);
}