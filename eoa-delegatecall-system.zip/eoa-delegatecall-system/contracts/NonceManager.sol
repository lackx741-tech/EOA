// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";

/**
 * @title NonceManager
 * @notice Manages sequential and non-sequential nonces for the EOA Vault system.
 *         Provides full replay protection across single executions, batch executions,
 *         and module-scoped operations.
 *
 * @dev Inherits StorageLayout to read/write nonce state into shared storage slots.
 *      This contract is designed to be inherited by the EOAVault (not called externally).
 *
 * Nonce Architecture:
 * ┌────────────────────────────────────────────────────────────────────────────┐
 * │ Type              │ Storage            │ Description                       │
 * ├────────────────────────────────────────────────────────────────────────────┤
 * │ Global Sequential │ _nonce (slot 2)    │ Monotonically increasing uint256  │
 * │ Operation Hash    │ _executionNonces   │ Consumed operation IDs (bitmap)   │
 * │ Module Scoped     │ _moduleNonces      │ Per-module operation counters      │
 * └────────────────────────────────────────────────────────────────────────────┘
 *
 * Replay Attack Prevention:
 *   1. Sequential nonce must match _nonce exactly → incremented after use
 *   2. Operation ID (hash of full params) stored permanently after execution
 *   3. Deadline field provides time-based expiry
 *   4. chainId field prevents cross-network replay
 */
abstract contract NonceManager is StorageLayout {

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Emitted when the global nonce advances
    event NonceAdvanced(uint256 indexed previousNonce, uint256 indexed newNonce);

    /// @notice Emitted when an operation ID is consumed (single use)
    event OperationConsumed(bytes32 indexed operationId, uint256 indexed nonce);

    /// @notice Emitted when a module nonce advances
    event ModuleNonceAdvanced(
        address indexed module,
        uint256 indexed previousNonce,
        uint256 indexed newNonce
    );

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error NonceManager__InvalidNonce(uint256 expected, uint256 provided);
    error NonceManager__OperationAlreadyExecuted(bytes32 operationId);
    error NonceManager__DeadlineExpired(uint256 deadline, uint256 currentTime);
    error NonceManager__ChainIdMismatch(uint256 expected, uint256 provided);
    error NonceManager__InvalidModuleNonce(
        address module,
        uint256 expected,
        uint256 provided
    );

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL — GLOBAL SEQUENTIAL NONCE
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Returns the current global nonce
     * @dev    The caller should sign over this value when constructing a request
     * @return current  The current sequential nonce
     */
    function _currentNonce() internal view returns (uint256 current) {
        current = _nonce;
    }

    /**
     * @notice Validates and advances the global sequential nonce
     * @dev    MUST be called before executing any authorized operation.
     *         Reverts if `providedNonce` does not equal the current nonce.
     *         Increments atomically — no reentrancy gap.
     * @param providedNonce  The nonce included in the signed request
     */
    function _useNonce(uint256 providedNonce) internal {
        uint256 current = _nonce;

        if (providedNonce != current) {
            revert NonceManager__InvalidNonce(current, providedNonce);
        }

        unchecked {
            // Safe: nonce overflowing uint256 is practically impossible
            _nonce = current + 1;
        }

        emit NonceAdvanced(current, _nonce);
    }

    /**
     * @notice Validates nonce without incrementing (view-only check)
     * @param providedNonce  The nonce to check against current state
     * @return valid         True if nonce matches current state
     */
    function _isValidNonce(uint256 providedNonce) internal view returns (bool valid) {
        valid = (providedNonce == _nonce);
    }

    /**
     * @notice Forcibly advances the nonce to a specific value
     * @dev    EMERGENCY USE ONLY — allows skipping nonces to invalidate
     *         all pending signed requests below the new nonce value.
     *         Caller must enforce access control before calling this.
     * @param newNonce  The new nonce value (must be > current nonce)
     */
    function _advanceNonceTo(uint256 newNonce) internal {
        uint256 current = _nonce;
        require(newNonce > current, "NonceManager: new nonce must exceed current");

        emit NonceAdvanced(current, newNonce);
        _nonce = newNonce;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL — OPERATION ID REGISTRY (Hash-Based Bitmap)
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Marks an operation ID as consumed to prevent replay
     * @dev    Called AFTER successful execution. The operationId is a
     *         keccak256 hash of the full execution parameters (see SignatureVerifier).
     * @param operationId  The unique operation identifier to mark as consumed
     * @param nonce        The nonce associated with this operation (for event indexing)
     */
    function _consumeOperationId(bytes32 operationId, uint256 nonce) internal {
        if (_executionNonces[operationId]) {
            revert NonceManager__OperationAlreadyExecuted(operationId);
        }

        _executionNonces[operationId] = true;
        emit OperationConsumed(operationId, nonce);
    }

    /**
     * @notice Checks if an operation ID has already been consumed
     * @param operationId  The operation identifier to check
     * @return consumed    True if this operation was already executed
     */
    function _isOperationConsumed(bytes32 operationId) internal view returns (bool consumed) {
        consumed = _executionNonces[operationId];
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL — MODULE-SCOPED NONCES
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Returns the current nonce for a specific module
     * @param module  The module contract address
     * @return nonce  The current module-scoped nonce
     */
    function _moduleNonce(address module) internal view returns (uint256 nonce) {
        nonce = _moduleNonces[module];
    }

    /**
     * @notice Validates and advances a module-scoped nonce
     * @param module         The module contract whose nonce to advance
     * @param providedNonce  The nonce provided in the signed request
     */
    function _useModuleNonce(address module, uint256 providedNonce) internal {
        uint256 current = _moduleNonces[module];

        if (providedNonce != current) {
            revert NonceManager__InvalidModuleNonce(module, current, providedNonce);
        }

        unchecked {
            _moduleNonces[module] = current + 1;
        }

        emit ModuleNonceAdvanced(module, current, _moduleNonces[module]);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INTERNAL — TEMPORAL AND CHAIN VALIDATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Validates that a request has not expired
     * @param deadline  The unix timestamp after which the request is invalid
     */
    function _checkDeadline(uint256 deadline) internal view {
        if (block.timestamp > deadline) {
            revert NonceManager__DeadlineExpired(deadline, block.timestamp);
        }
    }

    /**
     * @notice Validates that the chainId in a signed request matches current network
     * @param chainId  The chainId from the signed request
     */
    function _checkChainId(uint256 chainId) internal view {
        if (chainId != block.chainid) {
            revert NonceManager__ChainIdMismatch(block.chainid, chainId);
        }
    }

    /**
     * @notice Combined validation: deadline + chainId + nonce
     * @dev    This is the primary validation entry point used by the Orchestrator
     * @param providedNonce  Nonce from signed request
     * @param deadline       Expiry timestamp
     * @param chainId        Signed chain identifier
     */
    function _validateRequestContext(
        uint256 providedNonce,
        uint256 deadline,
        uint256 chainId
    ) internal {
        _checkDeadline(deadline);
        _checkChainId(chainId);
        _useNonce(providedNonce);
    }

    /**
     * @notice Full replay protection check without advancing nonce
     * @dev    Used for view queries to check if an operation would be valid
     * @param providedNonce  Nonce from signed request
     * @param deadline       Expiry timestamp
     * @param chainId        Chain identifier
     * @param operationId    Pre-computed operation hash
     * @return valid         True if request would pass validation
     * @return reason        Human-readable rejection reason, empty if valid
     */
    function _simulateValidation(
        uint256 providedNonce,
        uint256 deadline,
        uint256 chainId,
        bytes32 operationId
    ) internal view returns (bool valid, string memory reason) {
        if (block.timestamp > deadline) {
            return (false, "EXPIRED_DEADLINE");
        }
        if (chainId != block.chainid) {
            return (false, "CHAIN_ID_MISMATCH");
        }
        if (providedNonce != _nonce) {
            return (false, "INVALID_NONCE");
        }
        if (_executionNonces[operationId]) {
            return (false, "OPERATION_ALREADY_EXECUTED");
        }
        return (true, "");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // PUBLIC VIEW — EXPOSED FOR EOA WALLET INTEGRATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Returns the current global nonce (used by EOA wallet to construct requests)
     * @return The current nonce to include in the next signed request
     */
    function getNonce() external view returns (uint256) {
        return _nonce;
    }

    /**
     * @notice Returns the nonce for a specific module
     * @param module  The module address to query
     * @return        The module's current nonce
     */
    function getModuleNonce(address module) external view returns (uint256) {
        return _moduleNonces[module];
    }

    /**
     * @notice Checks if a specific operation ID has been consumed
     * @param operationId  The operation hash to query
     * @return             True if already executed
     */
    function isOperationConsumed(bytes32 operationId) external view returns (bool) {
        return _executionNonces[operationId];
    }

    /**
     * @notice Simulates whether a request would pass validation (for pre-flight checks)
     * @param providedNonce  Expected nonce value
     * @param deadline       Request expiry timestamp
     * @param chainId        Chain identifier
     * @param operationId    Pre-computed operation hash
     * @return valid         Whether the request would succeed
     * @return reason        Failure reason string if invalid
     */
    function simulateValidation(
        uint256 providedNonce,
        uint256 deadline,
        uint256 chainId,
        bytes32 operationId
    ) external view returns (bool valid, string memory reason) {
        return _simulateValidation(providedNonce, deadline, chainId, operationId);
    }
}