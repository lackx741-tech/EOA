// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./EOAVault.sol";
import "./ExecutionModule.sol";
import "./TokenClaimModule.sol";
import "./AdvancedExecutionModule.sol";
import "./Orchestrator.sol";

/**
 * @title VaultFactory
 * @notice Factory contract for deterministic deployment of EOAVault instances.
 *         Uses CREATE2 to allow pre-computation of vault addresses before deployment,
 *         enabling counterfactual vault funding (send ETH to vault address before deploy).
 *
 * @dev Factory maintains a registry of deployed vaults and their associated modules.
 *      The Orchestrator is shared across all vaults deployed by this factory.
 *      Three modules are deployed and registered: ExecutionModule, TokenClaimModule,
 *      and AdvancedExecutionModule.
 *
 * Deployment Pattern:
 * ┌──────────────────────────────────────────────────────────────────────────┐
 * │  1. Deploy VaultFactory (includes shared Orchestrator + 3 modules)      │
 * │  2. EOA calls deployVault(salt) → deterministic vault address           │
 * │  3. Factory initializes vault with EOA as owner, Orchestrator as coord  │
 * │  4. Factory registers vault with Orchestrator                           │
 * │  5. Factory registers all 3 modules in vault's module registry          │
 * │  6. Vault is ready for operation                                        │
 * └──────────────────────────────────────────────────────────────────────────┘
 */
contract VaultFactory {

    // ─────────────────────────────────────────────────────────────────────────
    // STATE
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice The shared Orchestrator for all vaults
    Orchestrator public immutable orchestrator;

    /// @notice The shared ExecutionModule for all vaults
    ExecutionModule public immutable executionModule;

    /// @notice The shared TokenClaimModule for all vaults
    TokenClaimModule public immutable tokenClaimModule;

    /// @notice The shared AdvancedExecutionModule for all vaults
    AdvancedExecutionModule public immutable advancedExecutionModule;

    /// @notice Factory admin
    address public factoryAdmin;

    /// @notice Mapping: owner address → list of deployed vault addresses
    mapping(address => address[]) public ownerVaults;

    /// @notice Mapping: vault address → owner address (reverse lookup)
    mapping(address => address) public vaultOwner;

    /// @notice All deployed vaults
    address[] public allVaults;

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    event VaultDeployed(
        address indexed owner,
        address indexed vault,
        bytes32 indexed salt,
        address orchestrator_,
        address executionModule_
    );

    event FactoryAdminTransferred(address indexed oldAdmin, address indexed newAdmin);

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error VaultFactory__ZeroAddress();
    error VaultFactory__VaultAlreadyExists(address predicted);
    error VaultFactory__DeploymentFailed();
    error VaultFactory__NotFactoryAdmin(address caller);

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Deploys the factory, shared Orchestrator, and all shared modules.
     * @param admin                  Factory and Orchestrator admin
     * @param timelockDelay          Default timelock delay in seconds
     * @param timelockValueThreshold ETH value above which timelock kicks in (wei)
     */
    constructor(
        address admin,
        uint256 timelockDelay,
        uint256 timelockValueThreshold
    ) {
        require(admin != address(0), "VaultFactory: zero admin");

        factoryAdmin = admin;

        // Deploy shared orchestrator
        orchestrator = new Orchestrator(
            admin,
            timelockDelay,
            timelockValueThreshold
        );

        // Deploy shared execution modules
        executionModule         = new ExecutionModule();
        tokenClaimModule        = new TokenClaimModule();
        advancedExecutionModule = new AdvancedExecutionModule();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VAULT DEPLOYMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Deploys a new EOAVault for the caller (msg.sender = EOA owner)
     * @dev    Uses CREATE2 with salt = keccak256(owner, userSalt) for determinism.
     *         Pre-computable address allows counterfactual funding.
     *         All three modules are registered atomically during initialization.
     *
     * @param userSalt  User-provided entropy for CREATE2 salt
     * @return vault    Address of the deployed EOAVault
     */
    function deployVault(bytes32 userSalt) external returns (address vault) {
        address owner = msg.sender;

        // Compute deterministic salt
        bytes32 salt = keccak256(abi.encodePacked(owner, userSalt));

        // Predict address and check it doesn't already exist
        address predicted = predictVaultAddress(owner, userSalt);
        if (predicted.code.length > 0) {
            revert VaultFactory__VaultAlreadyExists(predicted);
        }

        // ── Deploy EOAVault via CREATE2 ─────────────────────────────────────
        bytes memory bytecode = type(EOAVault).creationCode;

        assembly {
            vault := create2(
                0,                          // no ETH sent during deployment
                add(bytecode, 0x20),        // skip length prefix
                mload(bytecode),            // bytecode length
                salt                        // CREATE2 salt
            )
        }

        if (vault == address(0)) {
            revert VaultFactory__DeploymentFailed();
        }

        // ── Build selector lists for all modules ────────────────────────────
        (
            bytes4[] memory execSelectors,
            bytes4[] memory claimSelectors,
            bytes4[] memory advSelectors
        ) = _buildAllModuleSelectors();

        // ── Initialize vault with ExecutionModule selectors first ───────────
        // The initialize() function registers one module atomically.
        // Additional modules are registered via owner calls below.
        EOAVault(payable(vault)).initialize(
            owner,
            address(orchestrator),
            execSelectors,
            address(executionModule)
        );

        // ── Register TokenClaimModule selectors ─────────────────────────────
        // We use the vault's registerModule() function. The factory is the
        // effective owner during this setup window because the vault was just
        // initialized with `owner` as owner. However, `registerModule` requires
        // `onlyOwner`, so we need the owner to call it, or we need a factory
        // bootstrap path.
        //
        // Solution: Use initializeModules() — a one-time factory-callable hook
        // added to EOAVault that allows the factory to register additional modules
        // immediately after init. If not available, register via direct storage
        // write through the module registry bootstrap in initialize().
        //
        // Since EOAVault.initialize() already sets _initialized = true and
        // requires msg.sender == owner for registerModule(), we instead use
        // the _batchRegisterModules() internal approach via a secondary init call.
        //
        // IMPLEMENTATION: We call registerAdditionalModules() on the vault,
        // which is callable ONLY by the factory (address stored as immutable).
        // This is the cleanest pattern — see EOAVault for the implementation.
        //
        // NOTE: For backwards compat with existing EOAVault that doesn't have
        // registerAdditionalModules(), we call registerModule() impersonating owner.
        // Since we can't do that, we instead use a factory-privileged method.
        //
        // ACTUAL APPROACH: Vault stores factory address; factory can register
        // modules in the same deployment tx before ownership is "live".
        // We implement this as: call vault.registerModulesFromFactory(selectors, module)
        // which checks msg.sender == factory (set in vault constructor).
        //
        // SIMPLEST CORRECT APPROACH: Since the vault is freshly deployed and
        // only the factory knows about it, we have the owner (msg.sender of deployVault)
        // pre-approve the factory to register modules. But this requires a separate tx.
        //
        // FINAL DECISION: Add a `_factoryAddress` immutable to EOAVault that is set
        // in the constructor. Then add `registerModulesFromFactory()` callable only
        // by that factory address, usable only before or during initialization.
        //
        // For NOW (to keep existing tests passing), we register additional modules
        // using the vault owner calling registerModule(). Since we are the factory
        // and the owner is msg.sender (who called deployVault()), we cannot call
        // as owner here. 
        //
        // PRAGMATIC SOLUTION: Extend initialize() to accept multiple module arrays.
        // We'll call a new overloaded initializer or use a different approach.
        //
        // SIMPLEST: Add factory-callable registerModulesFromFactory() to EOAVault.
        // Since we're already modifying EOAVault, this is cleanest.
        // This is implemented below — the vault accepts module registrations
        // from the factory address stored at construction time.

        // For the initial deployment, we pass all selectors to a multi-module
        // init function. See the _registerModulesForVault() call below.
        _registerAdditionalModules(vault, claimSelectors, advSelectors);

        // ── Register vault with orchestrator ────────────────────────────────
        orchestrator.registerVault(vault);

        // ── Update registry ─────────────────────────────────────────────────
        ownerVaults[owner].push(vault);
        vaultOwner[vault] = owner;
        allVaults.push(vault);

        emit VaultDeployed(
            owner,
            vault,
            salt,
            address(orchestrator),
            address(executionModule)
        );
    }

    /**
     * @notice Registers additional modules (TokenClaim + AdvancedExecution) in the vault.
     * @dev    Called by the factory immediately after initialize(). Uses the factory's
     *         privileged access to registerModule() on behalf of the owner.
     *         This works because the vault exposes registerModulesFromFactory()
     *         which is restricted to the deploying factory address.
     */
    function _registerAdditionalModules(
        address vault,
        bytes4[] memory claimSelectors,
        bytes4[] memory advSelectors
    ) internal {
        EOAVault v = EOAVault(payable(vault));

        // Register TokenClaimModule selectors
        for (uint256 i = 0; i < claimSelectors.length; i++) {
            v.registerModuleFromFactory(claimSelectors[i], address(tokenClaimModule));
        }

        // Register AdvancedExecutionModule selectors
        for (uint256 i = 0; i < advSelectors.length; i++) {
            v.registerModuleFromFactory(advSelectors[i], address(advancedExecutionModule));
        }
    }

    /**
     * @notice Builds selector arrays for all three modules.
     * @return execSelectors   ExecutionModule function selectors
     * @return claimSelectors  TokenClaimModule function selectors
     * @return advSelectors    AdvancedExecutionModule function selectors
     */
    function _buildAllModuleSelectors()
        internal
        pure
        returns (
            bytes4[] memory execSelectors,
            bytes4[] memory claimSelectors,
            bytes4[] memory advSelectors
        )
    {
        // ── ExecutionModule ─────────────────────────────────────────────────
        execSelectors = new bytes4[](6);
        execSelectors[0] = bytes4(keccak256("execute(address,uint256,bytes,bool)"));
        execSelectors[1] = bytes4(keccak256("executeBatch(address[],uint256[],bytes[],bool)"));
        execSelectors[2] = bytes4(keccak256("sendETH(address,uint256)"));
        execSelectors[3] = bytes4(keccak256("updateModuleRegistry(bytes4,address)"));
        execSelectors[4] = bytes4(keccak256("setDelegate(address,bool)"));
        execSelectors[5] = bytes4(keccak256("syncBalance()"));

        // ── TokenClaimModule ────────────────────────────────────────────────
        claimSelectors = new bytes4[](10);
        claimSelectors[0] = bytes4(keccak256("claimERC20(address,bytes)"));
        claimSelectors[1] = bytes4(keccak256("claimWithMerkle(address,uint256,uint256,bytes32[])"));
        claimSelectors[2] = bytes4(keccak256("approveERC20(address,address,uint256)"));
        claimSelectors[3] = bytes4(keccak256("transferERC20(address,address,uint256)"));
        claimSelectors[4] = bytes4(keccak256("transferFromERC20(address,address,uint256)"));
        claimSelectors[5] = bytes4(keccak256("sweepERC20(address,address)"));
        claimSelectors[6] = bytes4(keccak256("claimAndSweep(address,bytes,address,address)"));
        claimSelectors[7] = bytes4(keccak256("transferERC721(address,address,uint256)"));
        claimSelectors[8] = bytes4(keccak256("transferERC1155(address,address,uint256,uint256,bytes)"));
        claimSelectors[9] = bytes4(keccak256("setApprovalForAll(address,address,bool)"));

        // ── AdvancedExecutionModule ─────────────────────────────────────────
        advSelectors = new bytes4[](15);
        advSelectors[0]  = bytes4(keccak256("deployContract(bytes,uint256)"));
        advSelectors[1]  = bytes4(keccak256("deployContract2(bytes,bytes32,uint256)"));
        advSelectors[2]  = bytes4(keccak256("predictDeployAddress(bytes32,bytes32)"));
        advSelectors[3]  = bytes4(keccak256("approveHash(bytes32)"));
        advSelectors[4]  = bytes4(keccak256("revokeHash(bytes32)"));
        advSelectors[5]  = bytes4(keccak256("permitERC20(address,address,uint256,uint256,uint8,bytes32,bytes32)"));
        advSelectors[6]  = bytes4(keccak256("stakeETH(address,uint256,bytes)"));
        advSelectors[7]  = bytes4(keccak256("unstakeETH(address,uint256,bytes)"));
        advSelectors[8]  = bytes4(keccak256("claimStakingRewards(address,bytes)"));
        advSelectors[9]  = bytes4(keccak256("swapExact(address,address,address,uint256,uint256,bytes)"));
        advSelectors[10] = bytes4(keccak256("addLiquidity(address,uint256,uint256,uint256,bytes)"));
        advSelectors[11] = bytes4(keccak256("removeLiquidity(address,uint256,bytes)"));
        advSelectors[12] = bytes4(keccak256("bridgeTokens(address,address,uint256,uint256,uint256,bytes)"));
        advSelectors[13] = bytes4(keccak256("rawCall(address,bytes)"));
        advSelectors[14] = bytes4(keccak256("rawCallWithValue(address,uint256,bytes)"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ADDRESS PREDICTION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Predicts the vault address for a given owner and salt
     * @dev    Allows EOA to fund the vault address BEFORE deployment (counterfactual)
     *
     * @param owner     The EOA that will own the vault
     * @param userSalt  User-provided salt entropy
     * @return predicted The deterministic address the vault will be deployed to
     */
    function predictVaultAddress(
        address owner,
        bytes32 userSalt
    ) public view returns (address predicted) {
        bytes32 salt     = keccak256(abi.encodePacked(owner, userSalt));
        bytes32 initHash = keccak256(type(EOAVault).creationCode);

        predicted = address(uint160(uint256(keccak256(abi.encodePacked(
            bytes1(0xff),
            address(this),
            salt,
            initHash
        )))));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VIEW FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Returns all vaults owned by a given address
    function getOwnerVaults(address owner)
        external
        view
        returns (address[] memory)
    {
        return ownerVaults[owner];
    }

    /// @notice Returns total number of deployed vaults
    function totalVaults() external view returns (uint256) {
        return allVaults.length;
    }

    /// @notice Returns a slice of deployed vaults (pagination)
    function getVaults(uint256 offset, uint256 limit)
        external
        view
        returns (address[] memory result)
    {
        uint256 total  = allVaults.length;
        uint256 end    = offset + limit > total ? total : offset + limit;
        uint256 length = end - offset;

        result = new address[](length);
        for (uint256 i = 0; i < length; i++) {
            result[i] = allVaults[offset + i];
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ADMIN
    // ─────────────────────────────────────────────────────────────────────────

    modifier onlyFactoryAdmin() {
        if (msg.sender != factoryAdmin) {
            revert VaultFactory__NotFactoryAdmin(msg.sender);
        }
        _;
    }

    function transferFactoryAdmin(address newAdmin) external onlyFactoryAdmin {
        if (newAdmin == address(0)) revert VaultFactory__ZeroAddress();
        emit FactoryAdminTransferred(factoryAdmin, newAdmin);
        factoryAdmin = newAdmin;
    }
}