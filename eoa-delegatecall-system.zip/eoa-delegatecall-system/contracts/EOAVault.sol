// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./NonceManager.sol";
import "./SessionKeyManager.sol";
import "./SignatureVerifier.sol";

/**
 * @title EOAVault
 * @notice The central proxy contract that acts as the on-chain representation
 *         of an EOA. It holds funds, maintains state, and delegates execution
 *         logic to registered ExecutionModules via delegatecall.
 *
 * @dev ╔══════════════════════════════════════════════════════════════════════╗
 *      ║  ARCHITECTURE POSITION                                              ║
 *      ║  ─────────────────────────────────────────────────────────────────  ║
 *      ║  EOA (off-chain signer)                                             ║
 *      ║    │  signs ExecutionRequest                                        ║
 *      ║    ▼                                                                ║
 *      ║  Orchestrator (validates signature, manages flow)                   ║
 *      ║    │  calls EOAVault.executeFromOrchestrator()                      ║
 *      ║    ▼                                                                ║
 *      ║  EOAVault (THIS CONTRACT)                                           ║
 *      ║    │  delegatecall → ExecutionModule                                ║
 *      ║    ▼                                                                ║
 *      ║  ExecutionModule (logic runs in EOAVault's context)                 ║
 *      ║    │  call → Target Contract                                        ║
 *      ║    ▼                                                                ║
 *      ║  Target Contract (actual destination of the operation)              ║
 *      ╚══════════════════════════════════════════════════════════════════════╝
 *
 * Key Design Properties:
 *  - delegatecall preserves EOAVault's address as msg.sender to target
 *  - All storage mutations affect EOAVault's state (not the module's)
 *  - Module logic is upgradeable without changing the vault address
 *  - ETH and tokens always reside in EOAVault, never in modules
 *  - Full replay protection via NonceManager inheritance
 *  - Session keys via SessionKeyManager inheritance
 */
contract EOAVault is NonceManager, SessionKeyManager {

    using SignatureVerifier for *;

    // ─────────────────────────────────────────────────────────────────────────
    // EVENTS
    // ─────────────────────────────────────────────────────────────────────────

    event VaultInitialized(address indexed owner, address indexed orchestrator);
    event OrchestratorUpdated(address indexed oldOrchestrator, address indexed newOrchestrator);
    event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    event ExecutionRouted(
        bytes4  indexed selector,
        address indexed module,
        address indexed caller,
        uint256 nonce
    );
    event DirectExecutionCompleted(
        address indexed target,
        uint256 value,
        bool    success
    );
    event VaultPaused(address indexed by);
    event VaultUnpaused(address indexed by);
    event ETHReceived(address indexed sender, uint256 amount);
    event ModuleRegistered(bytes4 indexed selector, address indexed module);
    event EmergencyNonceAdvanced(uint256 from, uint256 to);
    event SessionKeyExecuted(address indexed key, address indexed target, uint256 value);

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error EOAVault__AlreadyInitialized();
    error EOAVault__ZeroAddress();
    error EOAVault__Unauthorized(address caller);
    error EOAVault__InvalidSignature(address recovered, address expected);
    error EOAVault__NoModuleForSelector(bytes4 selector);
    error EOAVault__DelegatecallFailed(address module, bytes returnData);
    error EOAVault__Paused();
    error EOAVault__Locked();
    error EOAVault__InvalidOwnerChange();
    error EOAVault__NotFactory(address caller);

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTANTS — EIP-712 Domain
    // ─────────────────────────────────────────────────────────────────────────

    string  public constant NAME    = "EOAVault";
    string  public constant VERSION = "1";

    // ─────────────────────────────────────────────────────────────────────────
    // IMMUTABLES
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice The EIP-712 domain separator — computed once at deployment,
    ///         anchored to this contract's address and chain
    bytes32 public immutable DOMAIN_SEPARATOR;

    /// @notice The factory that deployed this vault — stored immutably at
    ///         construction time so `registerModuleFromFactory` can be
    ///         restricted to the factory without owner privileges.
    address public immutable FACTORY;

    // ─────────────────────────────────────────────────────────────────────────
    // MODIFIERS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Prevents reentrancy using the _locked flag in shared storage
    modifier nonReentrant() {
        if (_locked) revert EOAVault__Locked();
        _locked = true;
        _;
        _locked = false;
    }

    /// @notice Only the registered orchestrator can call this function
    modifier onlyOrchestrator() {
        if (msg.sender != _orchestrator) {
            revert EOAVault__Unauthorized(msg.sender);
        }
        _;
    }

    /// @notice Only the vault owner (mapped EOA) can call this function
    modifier onlyOwner() {
        if (msg.sender != _owner) {
            revert EOAVault__Unauthorized(msg.sender);
        }
        _;
    }

    /// @notice Blocks execution when vault is paused
    modifier whenNotPaused() {
        if (_paused) revert EOAVault__Paused();
        _;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTRUCTOR
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Deploys the EOAVault and locks the domain separator at deployment address.
     * @dev    The vault is NOT initialized here. Call initialize() after deployment.
     *         msg.sender at construction time is the VaultFactory — stored as FACTORY
     *         so that registerModuleFromFactory() can be gated to it.
     */
    constructor() {
        // Compute domain separator bound to this contract's address and chainId
        DOMAIN_SEPARATOR = SignatureVerifier.buildDomainSeparator(
            NAME,
            VERSION,
            address(this)
        );

        // Capture the deploying factory address
        FACTORY = msg.sender;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // INITIALIZATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Initializes the vault with an owner, orchestrator, and optional module bootstrap
     * @dev    Can only be called once. The factory calls this immediately after CREATE2 deployment.
     *         Module selectors are registered here (before ownership is exercised) so the
     *         factory does not need owner rights — it wires up modules during init atomically.
     *
     * @param initialOwner         The EOA address that owns this vault (the signer)
     * @param initialOrchestrator  The orchestrator contract address
     * @param selectors            Function selectors to register (typically ExecutionModule selectors)
     * @param module               The implementation module address for above selectors
     */
    function initialize(
        address initialOwner,
        address initialOrchestrator,
        bytes4[] calldata selectors,
        address module
    ) external {
        if (_initialized)                     revert EOAVault__AlreadyInitialized();
        if (initialOwner        == address(0)) revert EOAVault__ZeroAddress();
        if (initialOrchestrator == address(0)) revert EOAVault__ZeroAddress();

        _owner        = initialOwner;
        _orchestrator = initialOrchestrator;
        _nonce        = 0;
        _locked       = false;
        _paused       = false;
        _initialized  = true;

        // Bootstrap module registry atomically during initialization.
        // This avoids requiring the factory to have owner rights after init.
        if (module != address(0) && selectors.length > 0) {
            _delegates[module] = true;
            for (uint256 i = 0; i < selectors.length; i++) {
                _moduleRegistry[selectors[i]] = module;
            }
        }

        emit VaultInitialized(initialOwner, initialOrchestrator);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FACTORY MODULE REGISTRATION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Registers a module selector from the factory — called right after
     *         initialize() to wire up TokenClaimModule and AdvancedExecutionModule
     *         without requiring owner privileges on the newly-deployed vault.
     *
     * @dev    Restricted to the immutable FACTORY address set at construction.
     *         Can be called multiple times (once per selector) during vault deployment.
     *
     * @param selector  The function selector to register
     * @param module    The module implementation address
     */
    function registerModuleFromFactory(bytes4 selector, address module) external {
        if (msg.sender != FACTORY) revert EOAVault__NotFactory(msg.sender);
        require(module != address(0), "EOAVault: zero module address");

        _moduleRegistry[selector] = module;
        _delegates[module]        = true;

        emit ModuleRegistered(selector, module);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // CORE — DELEGATECALL DISPATCH
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Primary entry point for the Orchestrator to route signed operations
     * @dev    FLOW:
     *           1. Orchestrator validates signature off this function
     *           2. Orchestrator calls this with verified parameters
     *           3. This function looks up the module for the target selector
     *           4. delegatecall executes module logic IN THIS CONTRACT'S CONTEXT
     *           5. Results are returned to the orchestrator
     *
     *         WHY delegatecall here:
     *           - Module code runs as if it were written in this contract
     *           - Module can modify EOAVault's storage (nonces, balances, etc.)
     *           - msg.sender seen by the module = Orchestrator (the real caller)
     *           - address(this) seen by the module = EOAVault (not module)
     *           - Target contract ultimately sees EOAVault as the caller
     *
     * @param selector    4-byte function selector to look up module routing
     * @param callData    Full calldata to forward to the module (including selector)
     * @param nonce       Request nonce (already validated by Orchestrator)
     * @return returnData Data returned from the module execution
     */
    function executeFromOrchestrator(
        bytes4  selector,
        bytes calldata callData,
        uint256 nonce
    )
        external
        payable
        onlyOrchestrator
        whenNotPaused
        nonReentrant
        returns (bytes memory returnData)
    {
        // ── Module resolution ─────────────────────────────────────────────
        address module = _moduleRegistry[selector];

        if (module == address(0)) {
            revert EOAVault__NoModuleForSelector(selector);
        }

        if (!_delegates[module]) {
            revert EOAVault__Unauthorized(module);
        }

        emit ExecutionRouted(selector, module, msg.sender, nonce);

        // ── delegatecall to module ─────────────────────────────────────────
        // IMPORTANT: callData must already be ABI-encoded with the correct
        //            function signature from the ExecutionModule.
        bool success;
        (success, returnData) = module.delegatecall(callData);

        if (!success) {
            revert EOAVault__DelegatecallFailed(module, returnData);
        }
    }

    /**
     * @notice Direct delegatecall with explicit module address (bypass registry)
     * @dev    Allows orchestrator to call a specific module directly when the
     *         selector-based registry routing is insufficient.
     *         Requires module to be in the delegate whitelist.
     *
     * @param module    The specific module address to delegatecall
     * @param callData  Encoded function call for the module
     * @param nonce     Associated nonce for event logging
     * @return returnData The module's return data
     */
    function executeDirectModule(
        address module,
        bytes calldata callData,
        uint256 nonce
    )
        external
        payable
        onlyOrchestrator
        whenNotPaused
        nonReentrant
        returns (bytes memory returnData)
    {
        if (module == address(0)) revert EOAVault__ZeroAddress();

        if (!_delegates[module]) {
            revert EOAVault__Unauthorized(module);
        }

        bytes4 selector = bytes4(callData[:4]);
        emit ExecutionRouted(selector, module, msg.sender, nonce);

        bool success;
        (success, returnData) = module.delegatecall(callData);

        if (!success) {
            revert EOAVault__DelegatecallFailed(module, returnData);
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // SESSION KEY EXECUTION
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Execute a vault operation using a delegated session key.
     * @dev    The session key signs a SessionExecution struct off-chain.
     *         This function:
     *           1. Recovers the signer from the EIP-712 signature
     *           2. Validates all session key permissions
     *           3. Increments the per-key nonce
     *           4. Routes to the appropriate module via delegatecall
     *
     *         Anyone can submit a valid session key transaction — the key is
     *         the off-chain signature, not msg.sender.
     *
     * @param req        The session execution request (target, value, data, nonce, keyAddress)
     * @param signature  EIP-712 signature from the session key holder
     * @return returnData  Data returned from module execution
     */
    function executeSessionKey(
        SignatureVerifier.SessionExecution calldata req,
        bytes calldata signature
    )
        external
        payable
        whenNotPaused
        nonReentrant
        returns (bytes memory returnData)
    {
        // ── 1. Verify EIP-712 signature ───────────────────────────────────
        address recovered = SignatureVerifier.recoverSessionExecutionSigner(
            DOMAIN_SEPARATOR,
            req,
            signature
        );

        if (recovered != req.keyAddress) {
            revert EOAVault__InvalidSignature(recovered, req.keyAddress);
        }

        // ── 1b. Validate deadline and chainId
        require(req.deadline >= block.timestamp, "EOAVault: session key request expired");
        require(req.chainId  == block.chainid,   "EOAVault: session key wrong chainId");

        // ── 2. Validate session key nonce ─────────────────────────────────
        uint256 expectedNonce = _sessionKeyNonces[req.keyAddress];
        if (req.nonce != expectedNonce) {
            revert SessionKey__InvalidNonce(req.keyAddress, expectedNonce, req.nonce);
        }
        _sessionKeyNonces[req.keyAddress]++;

        // ── 3. Validate permissions + record usage ────────────────────────
        bytes4 selector = req.data.length >= 4 ? bytes4(req.data[:4]) : bytes4(0);
        _consumeSessionKey(req.keyAddress, req.target, req.value, selector);

        emit SessionKeyExecuted(req.keyAddress, req.target, req.value);

        // ── 4. Route to module via delegatecall ───────────────────────────
        if (req.data.length >= 4) {
            address module = _moduleRegistry[selector];
            if (module == address(0)) {
                revert EOAVault__NoModuleForSelector(selector);
            }
            if (!_delegates[module]) {
                revert EOAVault__Unauthorized(module);
            }

            bool success;
            (success, returnData) = module.delegatecall(req.data);
            if (!success) {
                revert EOAVault__DelegatecallFailed(module, returnData);
            }
        } else {
            // Pure ETH transfer — no module needed
            require(address(this).balance >= req.value, "EOAVault: insufficient balance");
            (bool sent, ) = req.target.call{value: req.value}("");
            require(sent, "EOAVault: ETH transfer failed");
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EIP-1271 — isValidSignature
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice EIP-1271 signature validation — allows the vault to act as a smart wallet
     *         for contracts that call isValidSignature (e.g., Gnosis Safe integrations,
     *         permit-based protocols, OpenSea off-chain orders).
     *
     * @dev    Two modes:
     *           1. Hash pre-approved via AdvancedExecutionModule.approveHash() → instant valid
     *           2. Signature is a valid ECDSA signature from the vault owner → valid
     *
     * @param hash       The EIP-712 or raw hash to validate
     * @param signature  The ECDSA signature (65 bytes) or empty bytes for pre-approved hashes
     * @return magicValue  0x1626ba7e if valid, 0xffffffff if invalid
     */
    function isValidSignature(
        bytes32 hash,
        bytes memory signature
    ) external view returns (bytes4 magicValue) {
        // Mode 1: hash was pre-approved via approveHash()
        if (_approvedHashes[hash]) {
            return 0x1626ba7e;
        }

        // Mode 2: valid owner ECDSA signature
        if (signature.length == 65) {
            address recovered = SignatureVerifier.recoverSigner(hash, signature);
            if (recovered == _owner) {
                return 0x1626ba7e;
            }
        }

        return 0xffffffff;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // FALLBACK — DYNAMIC ROUTING
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Fallback function that routes unknown selectors to registered modules
     * @dev    When the vault receives a call with an unrecognized selector,
     *         it attempts to find a registered module and delegatecalls it.
     *         This enables the vault to appear as if it implements the module's ABI.
     *
     *         Security: Only callable by the orchestrator to prevent unauthorized routing.
     */
    fallback() external payable {
        // Only allow orchestrator to trigger fallback routing
        // Direct callers are rejected
        if (msg.sender != _orchestrator && msg.sender != _owner) {
            revert EOAVault__Unauthorized(msg.sender);
        }

        bytes4 selector = msg.sig;
        address module  = _moduleRegistry[selector];

        if (module == address(0)) {
            revert EOAVault__NoModuleForSelector(selector);
        }

        // delegatecall and return result
        assembly {
            // Copy calldata to memory
            calldatacopy(0, 0, calldatasize())

            // delegatecall: gas, module address, memory in offset, size, out offset, out size
            let result := delegatecall(gas(), module, 0, calldatasize(), 0, 0)

            // Copy returndata to memory
            returndatacopy(0, 0, returndatasize())

            switch result
            case 0 {
                // Call failed — revert with return data
                revert(0, returndatasize())
            }
            default {
                // Call succeeded — return the data
                return(0, returndatasize())
            }
        }
    }

    /// @notice Accept plain ETH transfers (like an EOA would)
    receive() external payable {
        _trackedBalance += msg.value;
        emit ETHReceived(msg.sender, msg.value);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // MODULE REGISTRY MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Registers a module for a given function selector
     * @dev    After registration, the selector is whitelisted in _delegates too.
     *         Only callable by the owner (EOA) directly — governance operation.
     *
     * @param selector  The 4-byte function selector the module handles
     * @param module    The ExecutionModule implementation address
     */
    function registerModule(
        bytes4  selector,
        address module
    ) external onlyOwner {
        require(module != address(0), "EOAVault: zero module address");

        _moduleRegistry[selector] = module;
        _delegates[module]        = true;

        emit ModuleRegistered(selector, module);
    }

    /**
     * @notice Removes a module registration
     * @param selector  The selector to deregister
     */
    function deregisterModule(bytes4 selector) external onlyOwner {
        address module = _moduleRegistry[selector];
        require(module != address(0), "EOAVault: module not registered");

        delete _moduleRegistry[selector];
        // Note: _delegates[module] is NOT cleared here because the module
        // might be registered under multiple selectors
    }

    /**
     * @notice Revokes a module from the delegate whitelist entirely
     * @dev    This blocks the module from ANY delegatecall, regardless of selector
     * @param module  The module address to revoke
     */
    function revokeDelegate(address module) external onlyOwner {
        _delegates[module] = false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // OWNERSHIP & ORCHESTRATOR MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Transfers vault ownership to a new EOA
     * @dev    The new owner takes full control. Old owner loses all access.
     * @param newOwner  Address of the new owner
     */
    function transferOwnership(address newOwner) external onlyOwner {
        if (newOwner == address(0)) revert EOAVault__ZeroAddress();
        if (newOwner == _owner)     revert EOAVault__InvalidOwnerChange();

        address old = _owner;
        _owner = newOwner;

        emit OwnershipTransferred(old, newOwner);
    }

    /**
     * @notice Updates the orchestrator address
     * @dev    Should be called when upgrading the orchestrator contract.
     *         Owner must pre-verify the new orchestrator is safe.
     * @param newOrchestrator  New orchestrator contract address
     */
    function setOrchestrator(address newOrchestrator) external onlyOwner {
        if (newOrchestrator == address(0)) revert EOAVault__ZeroAddress();

        address old = _orchestrator;
        _orchestrator = newOrchestrator;

        emit OrchestratorUpdated(old, newOrchestrator);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EMERGENCY CONTROLS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Pauses the vault — halts all module execution
     * @dev    Only callable by owner. Use in case of compromised orchestrator.
     */
    function pause() external onlyOwner {
        _paused = true;
        emit VaultPaused(msg.sender);
    }

    /**
     * @notice Unpauses the vault
     */
    function unpause() external onlyOwner {
        _paused = false;
        emit VaultUnpaused(msg.sender);
    }

    /**
     * @notice Emergency nonce advance — invalidates all pending signed requests
     * @dev    Use when a signing key may be compromised. Jumps nonce forward
     *         by `steps`, making all previously signed requests with lower nonces invalid.
     * @param steps  How many nonce positions to skip forward
     */
    function emergencyAdvanceNonce(uint256 steps) external onlyOwner {
        require(steps > 0 && steps <= 1000, "EOAVault: invalid step count");

        uint256 from = _nonce;
        uint256 to   = from + steps;

        emit EmergencyNonceAdvanced(from, to);
        _nonce = to;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VIEW FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice Returns the vault owner address
    function owner() external view returns (address) {
        return _owner;
    }

    /// @notice Returns the orchestrator address
    function orchestrator() external view returns (address) {
        return _orchestrator;
    }

    /// @notice Returns whether a given address is a whitelisted delegate/module
    function isDelegate(address module) external view returns (bool) {
        return _delegates[module];
    }

    /// @notice Returns the module registered for a given selector
    function getModule(bytes4 selector) external view returns (address) {
        return _moduleRegistry[selector];
    }

    /// @notice Returns whether the vault is paused
    function isPaused() external view returns (bool) {
        return _paused;
    }

    /// @notice Returns the vault's ETH balance
    function vaultBalance() external view returns (uint256) {
        return address(this).balance;
    }

    /**
     * @notice Computes the EIP-712 digest for a given execution request
     * @dev    EOA wallet uses this to know exactly what to sign
     * @param req  The execution request to produce a digest for
     * @return     The 32-byte digest ready for signing
     */
    function getExecutionDigest(
        SignatureVerifier.ExecutionRequest calldata req
    ) external view returns (bytes32) {
        return SignatureVerifier.toTypedDataHash(
            DOMAIN_SEPARATOR,
            SignatureVerifier.hashExecutionRequest(req)
        );
    }

    /**
     * @notice Computes the EIP-712 digest for a batch execution request
     * @param batch  The batch to hash
     * @return       The 32-byte digest ready for signing
     */
    function getBatchExecutionDigest(
        SignatureVerifier.BatchExecution calldata batch
    ) external view returns (bytes32) {
        return SignatureVerifier.toTypedDataHash(
            DOMAIN_SEPARATOR,
            SignatureVerifier.hashBatchExecution(batch)
        );
    }

    /**
     * @notice Computes the EIP-712 digest for a session key execution request
     * @param req  The session execution request to produce a digest for
     * @return     The 32-byte digest ready for signing by the session key
     */
    function getSessionExecutionDigest(
        SignatureVerifier.SessionExecution calldata req
    ) external view returns (bytes32) {
        return SignatureVerifier.toTypedDataHash(
            DOMAIN_SEPARATOR,
            SignatureVerifier.hashSessionExecution(req)
        );
    }
}