// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract MockReceiver {
    bytes public lastCallData;
    uint256 public lastValue;
    uint256 public callCount;

    event Received(address sender, uint256 value, bytes data);

    receive() external payable {
        lastValue = msg.value;
        callCount++;
        emit Received(msg.sender, msg.value, "");
    }

    fallback() external payable {
        lastCallData = msg.data;
        lastValue = msg.value;
        callCount++;
        emit Received(msg.sender, msg.value, msg.data);
    }

    function getCallCount() external view returns (uint256) {
        return callCount;
    }
}
