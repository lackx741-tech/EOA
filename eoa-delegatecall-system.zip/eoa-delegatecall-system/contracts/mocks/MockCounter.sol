// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title MockCounter
/// @notice Simple counter contract used as a call target in SessionKey tests.
contract MockCounter {
    uint256 public count;

    event Incremented(address indexed caller, uint256 newCount);

    function increment() external {
        count++;
        emit Incremented(msg.sender, count);
    }

    function incrementBy(uint256 n) external {
        count += n;
        emit Incremented(msg.sender, count);
    }

    function getCount() external view returns (uint256) {
        return count;
    }
}