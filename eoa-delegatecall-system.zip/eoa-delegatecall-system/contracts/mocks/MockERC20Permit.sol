// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

contract MockERC20Permit {
    mapping(address => uint256) public balanceOf;
    mapping(address => mapping(address => uint256)) public allowance;
    mapping(address => uint256) public nonces;

    string public name = "Permit Token";
    string public symbol = "PRMT";

    event PermitCalled(address owner, address spender, uint256 value, uint256 deadline);

    constructor(address to, uint256 amount) {
        balanceOf[to] = amount;
    }

    // Simplified permit — just sets allowance (doesn't verify sig for testing)
    function permit(
        address owner_,
        address spender,
        uint256 value,
        uint256 deadline,
        uint8 /*v*/,
        bytes32 /*r*/,
        bytes32 /*s*/
    ) external {
        require(block.timestamp <= deadline, "expired");
        allowance[owner_][spender] = value;
        nonces[owner_]++;
        emit PermitCalled(owner_, spender, value, deadline);
    }

    function transfer(address to, uint256 amount) external returns (bool) {
        balanceOf[msg.sender] -= amount;
        balanceOf[to] += amount;
        return true;
    }
}
