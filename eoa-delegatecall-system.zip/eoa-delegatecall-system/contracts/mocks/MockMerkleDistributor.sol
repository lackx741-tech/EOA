// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./MockERC20.sol";

contract MockMerkleDistributor {
    MockERC20 public token;
    mapping(uint256 => bool) public isClaimed;

    constructor(address _token) {
        token = MockERC20(_token);
    }

    function claim(
        uint256 index,
        address account,
        uint256 amount,
        bytes32[] calldata /*merkleProof*/
    ) external {
        require(!isClaimed[index], "already claimed");
        isClaimed[index] = true;
        // Transfer tokens to account
        token.transfer(account, amount);
    }
}
