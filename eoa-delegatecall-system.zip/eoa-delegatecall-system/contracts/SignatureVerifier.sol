// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title SignatureVerifier
 * @notice A comprehensive ECDSA signature verification library that replicates
 *         the signing behavior of an EOA. Supports EIP-191 personal_sign and
 *         EIP-712 structured data signing for typed operation authorization.
 *
 * @dev This library is used by the Orchestrator to validate that every call
 *      routed through the system was authorized by the legitimate EOA owner
 *      BEFORE execution happens. It never calls the EOA directly.
 *
 * Signing Schemes Supported:
 * ┌────────────────────────────────────────────────────────────────────────┐
 * │ 1. EIP-191  │ personal_sign("\x19Ethereum Signed Message:\n32" + hash)│
 * │ 2. EIP-712  │ Structured typed data with domain separator             │
 * │ 3. Raw      │ Raw keccak256 digest (advanced use only)                │
 * └────────────────────────────────────────────────────────────────────────┘
 */
library SignatureVerifier {

    // ─────────────────────────────────────────────────────────────────────────
    // CONSTANTS
    // ─────────────────────────────────────────────────────────────────────────

    /// @notice EIP-712 typehash for domain separator construction
    bytes32 public constant DOMAIN_TYPEHASH = keccak256(
        "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
    );

    /// @notice EIP-712 typehash for an ExecutionRequest (the core operation struct)
    bytes32 public constant EXECUTION_TYPEHASH = keccak256(
        "ExecutionRequest("
        "address target,"
        "uint256 value,"
        "bytes data,"
        "uint256 nonce,"
        "uint256 deadline,"
        "uint256 chainId"
        ")"
    );

    /// @notice EIP-712 typehash for a SessionExecution (signed by a session key)
    bytes32 public constant SESSION_EXEC_TYPEHASH = keccak256(
        "SessionExecution("
        "address keyAddress,"
        "address target,"
        "uint256 value,"
        "bytes data,"
        "uint256 nonce,"
        "uint256 deadline,"
        "uint256 chainId"
        ")"
    );

    /// @notice EIP-712 typehash for a BatchExecution
    bytes32 public constant BATCH_EXECUTION_TYPEHASH = keccak256(
        "BatchExecution("
        "ExecutionRequest[] operations,"
        "uint256 nonce,"
        "uint256 deadline,"
        "uint256 chainId"
        ")"
        "ExecutionRequest("
        "address target,"
        "uint256 value,"
        "bytes data,"
        "uint256 nonce,"
        "uint256 deadline,"
        "uint256 chainId"
        ")"
    );

    // ─────────────────────────────────────────────────────────────────────────
    // STRUCTS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Represents a single authorized execution request
     * @param target     The contract or EOA to call
     * @param value      ETH value to send with the call
     * @param data       ABI-encoded calldata
     * @param nonce      Sequential nonce for replay protection
     * @param deadline   Block timestamp after which this request expires
     * @param chainId    Network identifier to prevent cross-chain replay
     */
    struct ExecutionRequest {
        address target;
        uint256 value;
        bytes   data;
        uint256 nonce;
        uint256 deadline;
        uint256 chainId;
    }

    /**
     * @notice Represents an authorized batch of execution requests
     * @param operations  Array of individual ExecutionRequests
     * @param nonce       Global nonce for the entire batch
     * @param deadline    Expiry for the entire batch
     * @param chainId     Network identifier
     */
    struct BatchExecution {
        ExecutionRequest[] operations;
        uint256 nonce;
        uint256 deadline;
        uint256 chainId;
    }

    /**
     * @notice Represents a session key execution request
     * @param keyAddress  The session key address that must sign this request
     * @param target      The contract or EOA to call
     * @param value       ETH value to send with the call
     * @param data        ABI-encoded calldata
     * @param nonce       Per-key sequential nonce for replay protection
     * @param deadline    Block timestamp after which this request expires
     * @param chainId     Network identifier to prevent cross-chain replay
     */
    struct SessionExecution {
        address keyAddress;
        address target;
        uint256 value;
        bytes   data;
        uint256 nonce;
        uint256 deadline;
        uint256 chainId;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DOMAIN SEPARATOR
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Builds an EIP-712 domain separator for a given contract
     * @param name              Human-readable name of the signing domain
     * @param version           Version string (e.g., "1")
     * @param verifyingContract The contract whose address anchors this domain
     * @return domainSeparator  32-byte domain separator hash
     */
    function buildDomainSeparator(
        string memory name,
        string memory version,
        address verifyingContract
    ) internal view returns (bytes32 domainSeparator) {
        domainSeparator = keccak256(abi.encode(
            DOMAIN_TYPEHASH,
            keccak256(bytes(name)),
            keccak256(bytes(version)),
            block.chainid,
            verifyingContract
        ));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // HASH FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Hashes a single ExecutionRequest according to EIP-712 encoding
     * @param req  The execution request to hash
     * @return     The struct hash of the request
     */
    function hashExecutionRequest(
        ExecutionRequest memory req
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(
            EXECUTION_TYPEHASH,
            req.target,
            req.value,
            keccak256(req.data),   // dynamic types must be hashed
            req.nonce,
            req.deadline,
            req.chainId
        ));
    }

    /**
     * @notice Hashes a BatchExecution request according to EIP-712 encoding
     * @param batch  The batch execution to hash
     * @return       The struct hash of the batch
     */
    function hashBatchExecution(
        BatchExecution memory batch
    ) internal pure returns (bytes32) {
        // Hash each individual operation first
        bytes32[] memory opHashes = new bytes32[](batch.operations.length);
        for (uint256 i = 0; i < batch.operations.length; i++) {
            opHashes[i] = hashExecutionRequest(batch.operations[i]);
        }

        return keccak256(abi.encode(
            BATCH_EXECUTION_TYPEHASH,
            keccak256(abi.encodePacked(opHashes)),
            batch.nonce,
            batch.deadline,
            batch.chainId
        ));
    }

    /**
     * @notice Produces the final EIP-712 digest to be signed or recovered from
     * @param domainSeparator  The domain separator of the signing contract
     * @param structHash       The hash of the typed struct
     * @return digest          The final 32-byte digest
     */
    function toTypedDataHash(
        bytes32 domainSeparator,
        bytes32 structHash
    ) internal pure returns (bytes32 digest) {
        digest = keccak256(abi.encodePacked(
            "\x19\x01",         // EIP-712 prefix
            domainSeparator,
            structHash
        ));
    }

    /**
     * @notice Produces an EIP-191 personal_sign digest
     * @param messageHash  The raw 32-byte message hash to prefix
     * @return             The prefixed and hashed digest
     */
    function toEthSignedMessageHash(
        bytes32 messageHash
    ) internal pure returns (bytes32) {
        return keccak256(abi.encodePacked(
            "\x19Ethereum Signed Message:\n32",
            messageHash
        ));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // RECOVERY FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Recovers the signer address from an EIP-712 typed data signature
     * @param domainSeparator  Domain separator of the authorizing contract
     * @param req              The execution request that was signed
     * @param signature        65-byte ECDSA signature (r, s, v)
     * @return signer          Recovered signer address
     */
    function recoverExecutionSigner(
        bytes32 domainSeparator,
        ExecutionRequest memory req,
        bytes memory signature
    ) internal pure returns (address signer) {
        bytes32 digest = toTypedDataHash(
            domainSeparator,
            hashExecutionRequest(req)
        );
        signer = recoverSigner(digest, signature);
    }

    /**
     * @notice Recovers the signer address from a batch execution signature
     * @param domainSeparator  Domain separator of the authorizing contract
     * @param batch            The batch that was signed
     * @param signature        65-byte ECDSA signature
     * @return signer          Recovered signer address
     */
    function recoverBatchSigner(
        bytes32 domainSeparator,
        BatchExecution memory batch,
        bytes memory signature
    ) internal pure returns (address signer) {
        bytes32 digest = toTypedDataHash(
            domainSeparator,
            hashBatchExecution(batch)
        );
        signer = recoverSigner(digest, signature);
    }

    /**
     * @notice Core ECDSA signer recovery from a digest and signature
     * @dev    Performs strict signature validation:
     *         - Signature must be exactly 65 bytes
     *         - `s` must be in the lower half of the curve (EIP-2 malleability fix)
     *         - `v` must be 27 or 28
     * @param digest     32-byte message digest
     * @param signature  65-byte signature bytes
     * @return signer    Recovered address, or address(0) on failure
     */
    function recoverSigner(
        bytes32 digest,
        bytes memory signature
    ) internal pure returns (address signer) {
        // ── Strict length check ──────────────────────────────────────────────
        require(signature.length == 65, "SignatureVerifier: invalid sig length");

        bytes32 r;
        bytes32 s;
        uint8   v;

        // ── Efficient inline assembly extraction ─────────────────────────────
        assembly {
            // First 32 bytes after length prefix = r
            r := mload(add(signature, 0x20))
            // Next 32 bytes = s
            s := mload(add(signature, 0x40))
            // Final byte = v
            v := byte(0, mload(add(signature, 0x60)))
        }

        // ── Normalize v (some signers output 0/1 instead of 27/28) ───────────
        if (v < 27) {
            v += 27;
        }

        require(v == 27 || v == 28, "SignatureVerifier: invalid v value");

        // ── Malleability check: s must be in lower half order ─────────────────
        // secp256k1 curve order n / 2
        require(
            uint256(s) <= 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0,
            "SignatureVerifier: malleable signature"
        );

        // ── ecrecover ─────────────────────────────────────────────────────────
        signer = ecrecover(digest, v, r, s);
        require(signer != address(0), "SignatureVerifier: zero address recovery");
    }

    // ─────────────────────────────────────────────────────────────────────────
    // VERIFICATION FUNCTIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Verifies that an ExecutionRequest was signed by `expectedSigner`
     * @param domainSeparator  Domain separator
     * @param req              The request to verify
     * @param signature        The 65-byte signature
     * @param expectedSigner   The address we expect signed this request
     * @return valid           True if signature is valid and from expectedSigner
     */
    function verifyExecutionRequest(
        bytes32 domainSeparator,
        ExecutionRequest memory req,
        bytes memory signature,
        address expectedSigner
    ) internal pure returns (bool valid) {
        address recovered = recoverExecutionSigner(domainSeparator, req, signature);
        valid = (recovered == expectedSigner);
    }

    /**
     * @notice Verifies a batch execution request signature
     * @param domainSeparator  Domain separator
     * @param batch            The batch to verify
     * @param signature        The 65-byte signature
     * @param expectedSigner   Expected signer address
     * @return valid           True if valid
     */
    function verifyBatchExecution(
        bytes32 domainSeparator,
        BatchExecution memory batch,
        bytes memory signature,
        address expectedSigner
    ) internal pure returns (bool valid) {
        address recovered = recoverBatchSigner(domainSeparator, batch, signature);
        valid = (recovered == expectedSigner);
    }

    /**
     * @notice Validates that a request has not expired and chainId matches
     * @param req      The execution request to check
     * @return valid   True if request is temporally valid
     */
    function validateRequestExpiry(
        ExecutionRequest memory req
    ) internal view returns (bool valid) {
        valid = (
            req.deadline >= block.timestamp &&
            req.chainId  == block.chainid
        );
    }

    /**
     * @notice Validates batch expiry and chainId
     * @param batch  The batch execution to check
     * @return valid True if batch is temporally valid
     */
    function validateBatchExpiry(
        BatchExecution memory batch
    ) internal view returns (bool valid) {
        valid = (
            batch.deadline >= block.timestamp &&
            batch.chainId  == block.chainid
        );
    }

    /**
     * @notice Hashes a SessionExecution request according to EIP-712 encoding
     * @param req  The session execution request to hash
     * @return     The struct hash of the request
     */
    function hashSessionExecution(
        SessionExecution memory req
    ) internal pure returns (bytes32) {
        return keccak256(abi.encode(
            SESSION_EXEC_TYPEHASH,
            req.keyAddress,
            req.target,
            req.value,
            keccak256(req.data),
            req.nonce,
            req.deadline,
            req.chainId
        ));
    }

    /**
     * @notice Recovers the signer address from a SessionExecution EIP-712 signature
     * @param domainSeparator  Domain separator of the authorizing vault
     * @param req              The session execution that was signed
     * @param signature        65-byte ECDSA signature from the session key holder
     * @return signer          Recovered signer address
     */
    function recoverSessionExecutionSigner(
        bytes32 domainSeparator,
        SessionExecution memory req,
        bytes memory signature
    ) internal pure returns (address signer) {
        bytes32 digest = toTypedDataHash(
            domainSeparator,
            hashSessionExecution(req)
        );
        signer = recoverSigner(digest, signature);
    }

    /**
     * @notice Verifies a SessionExecution was signed by the specified key
     * @param domainSeparator  Domain separator
     * @param req              The session execution to verify
     * @param signature        65-byte ECDSA signature
     * @param expectedKey      The session key address we expect signed this
     * @return valid           True if signature is valid and from expectedKey
     */
    function verifySessionExecution(
        bytes32 domainSeparator,
        SessionExecution memory req,
        bytes memory signature,
        address expectedKey
    ) internal pure returns (bool valid) {
        address recovered = recoverSessionExecutionSigner(domainSeparator, req, signature);
        valid = (recovered == expectedKey);
    }

    /**
     * @notice Validates session execution expiry and chainId
     * @param req   The session execution to check
     * @return valid True if not expired and chainId matches
     */
    function validateSessionExpiry(
        SessionExecution memory req
    ) internal view returns (bool valid) {
        valid = (
            req.deadline >= block.timestamp &&
            req.chainId  == block.chainid
        );
    }

    // ─────────────────────────────────────────────────────────────────────────
    // OPERATION ID HELPERS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Computes a unique operation identifier for replay tracking
     * @dev    This ID is stored in the _executionNonces mapping after use
     * @param req  The execution request
     * @return id  Unique bytes32 operation ID
     */
    function computeOperationId(
        ExecutionRequest memory req
    ) internal pure returns (bytes32 id) {
        id = keccak256(abi.encode(
            req.target,
            req.value,
            keccak256(req.data),
            req.nonce,
            req.deadline,
            req.chainId
        ));
    }

    /**
     * @notice Computes a unique batch operation identifier
     * @param batch  The batch execution
     * @return id    Unique bytes32 batch ID
     */
    function computeBatchOperationId(
        BatchExecution memory batch
    ) internal pure returns (bytes32 id) {
        id = keccak256(abi.encode(
            batch.nonce,
            batch.deadline,
            batch.chainId,
            batch.operations.length
        ));
    }
}