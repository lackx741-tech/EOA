// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/**
 * @title StorageLayout
 * @notice Defines the canonical storage layout shared across all delegatecall-compatible
 *         contracts in the EOA Vault system. ALL contracts that participate in delegatecall
 *         chains MUST inherit from this contract to prevent storage slot collisions.
 *
 * @dev Storage slots are carefully ordered and padded. Any modification to this layout
 *      WILL corrupt state across the entire system. Slots follow EIP-1967 inspired design.
 *
 * Storage Map:
 * ┌──────────────────────────────────────────────────────────────────────┐
 * │ Slot 0  │ owner          │ address (20 bytes)                       │
 * │ Slot 1  │ orchestrator   │ address (20 bytes)                       │
 * │ Slot 2  │ nonce          │ uint256                                  │
 * │ Slot 3  │ locked         │ bool (reentrancy guard)                  │
 * │ Slot 4  │ initialized    │ bool                                     │
 * │ Slot 5  │ paused         │ bool                                     │
 * │ Slot 6  │ executionNonces│ mapping(bytes32 => bool)                 │
 * │ Slot 7  │ delegates      │ mapping(address => bool)                 │
 * │ Slot 8  │ moduleRegistry │ mapping(bytes4 => address)               │
 * │ Slot 9  │ ethBalance     │ uint256 (tracked balance)                │
 * │ Slot 10 │ pendingOps     │ mapping(bytes32 => uint256)              │
 * │ Slot 11 │ moduleNonces   │ mapping(address => uint256)              │
 * │ Slot 12 │ sessionKeys    │ mapping(address => SessionKey)           │
 * │ Slot 13 │ sessionKeyNonces│ mapping(address => uint256)             │
 * │ Slot 14 │ approvedHashes │ mapping(bytes32 => bool)  (EIP-1271)    │
 * │ Slot 15 │ permitNonces   │ mapping(address => uint256) (EIP-2612)  │
 * └──────────────────────────────────────────────────────────────────────┘
 */
abstract contract StorageLayout {

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 0 — Primary owner (maps to EOA address)
    // ─────────────────────────────────────────────────────────────────────────
    address internal _owner;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 1 — Orchestrator contract address
    // ─────────────────────────────────────────────────────────────────────────
    address internal _orchestrator;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 2 — Global sequential nonce (prevents replay attacks)
    // ─────────────────────────────────────────────────────────────────────────
    uint256 internal _nonce;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 3 — Reentrancy lock flag
    // ─────────────────────────────────────────────────────────────────────────
    bool internal _locked;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 4 — Initialization flag (prevents re-initialization)
    // ─────────────────────────────────────────────────────────────────────────
    bool internal _initialized;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 5 — Emergency pause flag
    // ─────────────────────────────────────────────────────────────────────────
    bool internal _paused;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 6 — Execution nonce registry: tracks consumed operation hashes
    //          key = keccak256(abi.encode(nonce, target, value, data, chainId))
    // ─────────────────────────────────────────────────────────────────────────
    mapping(bytes32 => bool) internal _executionNonces;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 7 — Delegate whitelist: approved module addresses
    // ─────────────────────────────────────────────────────────────────────────
    mapping(address => bool) internal _delegates;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 8 — Module registry: function selector → implementation address
    //          Used for routing calls to the correct execution module
    // ─────────────────────────────────────────────────────────────────────────
    mapping(bytes4 => address) internal _moduleRegistry;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 9 — Tracked ETH balance (used for accounting in delegatecall flows)
    // ─────────────────────────────────────────────────────────────────────────
    uint256 internal _trackedBalance;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 10 — Pending operations queue (timelock / batching support)
    // ─────────────────────────────────────────────────────────────────────────
    mapping(bytes32 => uint256) internal _pendingOperations; // opHash => scheduledTime

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 11 — Per-module operation counters (for fine-grained nonce scoping)
    // ─────────────────────────────────────────────────────────────────────────
    mapping(address => uint256) internal _moduleNonces;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 12 — Session key registry
    //           Each session key has its own permission struct stored here.
    //           The struct packs across multiple storage slots internally.
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Permission struct for a delegated session key.
     * @dev    Packed into vault storage starting at slot 12 mapping.
     *         Dynamic arrays (allowedSelectors, allowedTargets) are stored
     *         at hash-derived slots per EVM mapping rules.
     */
    struct SessionKey {
        bool      active;          // whether key is currently active
        uint48    validAfter;      // unix timestamp: key not valid before this
        uint48    validUntil;      // unix timestamp: key expires after this
        uint256   maxValuePerCall; // max ETH per single call (0 = no ETH allowed)
        uint256   maxValueTotal;   // lifetime ETH budget (0 = unlimited)
        uint256   spentValue;      // accumulated ETH spent via this key
        uint256   usageCount;      // number of times this key has been used
        uint256   maxUsageCount;   // max allowed uses (0 = unlimited)
        bytes4[]  allowedSelectors; // empty = any selector allowed
        address[] allowedTargets;   // empty = any target allowed
    }

    mapping(address => SessionKey) internal _sessionKeys;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 13 — Per-session-key nonces (sequential replay protection)
    // ─────────────────────────────────────────────────────────────────────────
    mapping(address => uint256) internal _sessionKeyNonces;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 14 — Pre-approved hashes for EIP-1271 isValidSignature
    //           Set via AdvancedExecutionModule.approveHash()
    // ─────────────────────────────────────────────────────────────────────────
    mapping(bytes32 => bool) internal _approvedHashes;

    // ─────────────────────────────────────────────────────────────────────────
    // SLOT 15 — EIP-2612 permit nonces per token contract
    // ─────────────────────────────────────────────────────────────────────────
    mapping(address => uint256) internal _permitNonces;

    // ─────────────────────────────────────────────────────────────────────────
    // RESERVED SLOTS — 16 through 49 are intentionally reserved for future
    //                  upgrades without storage collision risk
    // ─────────────────────────────────────────────────────────────────────────
    uint256[34] private __gap;
}