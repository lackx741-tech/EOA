// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./StorageLayout.sol";

/**
 * @title AdvancedExecutionModule
 * @notice Delegatecall module enabling full EOA-equivalent capabilities:
 *         contract deployment, EIP-1271 hash approval, EIP-2612 permit,
 *         staking, DeFi swap/liquidity/bridge operations, and raw escape hatches.
 *
 * @dev All functions execute in EOAVault's storage context via delegatecall.
 *      The vault is msg.sender to all external contracts.
 *      This module MUST NOT hold state or assets of its own.
 *
 * Capabilities:
 * ┌────────────────────────────────────────────────────────────────────────────┐
 * │  deployContract()      │ CREATE deployment from vault context             │
 * │  deployContract2()     │ CREATE2 deterministic deployment                 │
 * │  predictDeployAddress()│ Predict CREATE2 address                          │
 * │  approveHash()         │ EIP-1271 hash pre-approval                       │
 * │  revokeHash()          │ EIP-1271 hash revocation                         │
 * │  permitERC20()         │ EIP-2612 gasless permit                          │
 * │  stakeETH()            │ ETH staking via arbitrary staking contract       │
 * │  unstakeETH()          │ ETH unstake                                      │
 * │  claimStakingRewards() │ Claim staking rewards                            │
 * │  swapExact()           │ DEX exact-in swap                                │
 * │  addLiquidity()        │ Add liquidity to a pool                          │
 * │  removeLiquidity()     │ Remove liquidity from a pool                     │
 * │  bridgeTokens()        │ Cross-chain token bridge                         │
 * │  rawCall()             │ Arbitrary external call (no ETH)                 │
 * │  rawCallWithValue()    │ Arbitrary external call with ETH                 │
 * └────────────────────────────────────────────────────────────────────────────┘
 */
contract AdvancedExecutionModule is StorageLayout {

    // ─────────────────────────────────────────────────────────────────────────
    // DELEGATECALL GUARD
    // ─────────────────────────────────────────────────────────────────────────

    address private immutable _self;

    constructor() {
        _self = address(this);
    }

    modifier onlyDelegatecall() {
        require(
            address(this) != _self,
            "AdvancedExecutionModule: must be called via delegatecall"
        );
        _;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ERRORS
    // ─────────────────────────────────────────────────────────────────────────

    error AdvancedExecutionModule__DeployFailed();
    error AdvancedExecutionModule__CallFailed(address target, bytes returnData);
    error AdvancedExecutionModule__ZeroAddress();
    error AdvancedExecutionModule__HashAlreadyApproved(bytes32 hash);
    error AdvancedExecutionModule__HashNotApproved(bytes32 hash);
    error AdvancedExecutionModule__InsufficientBalance(uint256 available, uint256 required);

    // ─────────────────────────────────────────────────────────────────────────
    // CONTRACT DEPLOYMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Deploy a contract using CREATE (standard deployment).
     * @dev    The deployed contract's address is determined by vault address + nonce.
     *         Runs in EOAVault's context, so the vault is the deployer.
     *
     * @param bytecode   Compiled creation bytecode (with constructor args appended)
     * @param value      ETH to send to the new contract's constructor
     * @return deployed  Address of the newly deployed contract
     */
    function deployContract(
        bytes calldata bytecode,
        uint256 value
    )
        external
        payable
        onlyDelegatecall
        returns (address deployed)
    {
        require(bytecode.length > 0, "AdvancedExecutionModule: empty bytecode");

        if (value > 0 && address(this).balance < value) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, value);
        }

        assembly {
            let ptr := mload(0x40)
            let size := bytecode.length
            calldatacopy(ptr, bytecode.offset, size)
            deployed := create(value, ptr, size)
        }

        if (deployed == address(0)) revert AdvancedExecutionModule__DeployFailed();
    }

    /**
     * @notice Deploy a contract using CREATE2 (deterministic address).
     * @dev    Address is determined by vault address, salt, and bytecode hash.
     *         Enables counterfactual deployments.
     *
     * @param bytecode   Compiled creation bytecode
     * @param salt       32-byte salt for address derivation
     * @param value      ETH to send to the new contract's constructor
     * @return deployed  Address of the deterministically deployed contract
     */
    function deployContract2(
        bytes calldata bytecode,
        bytes32 salt,
        uint256 value
    )
        external
        payable
        onlyDelegatecall
        returns (address deployed)
    {
        require(bytecode.length > 0, "AdvancedExecutionModule: empty bytecode");

        if (value > 0 && address(this).balance < value) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, value);
        }

        assembly {
            let ptr := mload(0x40)
            let size := bytecode.length
            calldatacopy(ptr, bytecode.offset, size)
            deployed := create2(value, ptr, size, salt)
        }

        if (deployed == address(0)) revert AdvancedExecutionModule__DeployFailed();
    }

    /**
     * @notice Predict the CREATE2 address for a given bytecode hash and salt.
     * @dev    Useful for counterfactual funding before deployment.
     *
     * @param bytecodeHash  keccak256 of the creation bytecode
     * @param salt          32-byte salt
     * @return predicted    The deterministic deployment address
     */
    function predictDeployAddress(
        bytes32 bytecodeHash,
        bytes32 salt
    )
        external
        view
        onlyDelegatecall
        returns (address predicted)
    {
        predicted = address(uint160(uint256(keccak256(abi.encodePacked(
            bytes1(0xff),
            address(this),   // deployer = vault (delegatecall context)
            salt,
            bytecodeHash
        )))));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EIP-1271 HASH MANAGEMENT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Pre-approve a hash so the vault returns the EIP-1271 magic value.
     * @dev    Writes to `_approvedHashes` (slot 14) in EOAVault's storage.
     *         After this, `vault.isValidSignature(hash, "")` returns 0x1626ba7e.
     *
     * @param hash  The 32-byte hash to approve
     */
    function approveHash(bytes32 hash) external onlyDelegatecall {
        if (_approvedHashes[hash]) {
            revert AdvancedExecutionModule__HashAlreadyApproved(hash);
        }
        _approvedHashes[hash] = true;
    }

    /**
     * @notice Revoke a previously approved hash.
     * @param hash  The hash to revoke
     */
    function revokeHash(bytes32 hash) external onlyDelegatecall {
        if (!_approvedHashes[hash]) {
            revert AdvancedExecutionModule__HashNotApproved(hash);
        }
        _approvedHashes[hash] = false;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // EIP-2612 PERMIT
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Execute an EIP-2612 permit for a token, approving a spender without gas.
     * @dev    The vault calls permit() on the token, so the signature must be for
     *         the vault's address as the owner. The relayer provides the signature
     *         components (v, r, s).
     *
     * @param token    ERC-20 token with EIP-2612 permit support
     * @param spender  Address to permit
     * @param amount   Allowance amount
     * @param deadline Signature expiry
     * @param v        Signature v component
     * @param r        Signature r component
     * @param s        Signature s component
     */
    function permitERC20(
        address token,
        address spender,
        uint256 amount,
        uint256 deadline,
        uint8   v,
        bytes32 r,
        bytes32 s
    )
        external
        onlyDelegatecall
    {
        if (token == address(0) || spender == address(0))
            revert AdvancedExecutionModule__ZeroAddress();

        bytes memory data = abi.encodeWithSignature(
            "permit(address,address,uint256,uint256,uint8,bytes32,bytes32)",
            address(this),   // owner = vault
            spender,
            amount,
            deadline,
            v, r, s
        );

        (bool success, bytes memory ret) = token.call(data);
        if (!success) revert AdvancedExecutionModule__CallFailed(token, ret);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // STAKING OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Stake ETH via an arbitrary staking contract.
     * @dev    Forwards `callData` to `stakingContract` with `amount` ETH.
     *         e.g. Lido: stakeETH(lido, 1 ether, abi.encodeWithSignature("submit(address)", referral))
     *
     * @param stakingContract  The staking protocol contract
     * @param amount           ETH to stake
     * @param callData         Encoded staking function call
     * @return returnData      Data returned by the staking contract
     */
    function stakeETH(
        address stakingContract,
        uint256 amount,
        bytes calldata callData
    )
        external
        payable
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (stakingContract == address(0)) revert AdvancedExecutionModule__ZeroAddress();
        if (address(this).balance < amount) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, amount);
        }

        bool success;
        (success, returnData) = stakingContract.call{value: amount}(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(stakingContract, returnData);
    }

    /**
     * @notice Unstake from a staking protocol.
     * @param stakingContract  The staking protocol contract
     * @param callData         Encoded unstake function call
     * @return returnData      Data returned by the staking contract
     */
    function unstakeETH(
        address stakingContract,
        uint256 /*amount*/,
        bytes calldata callData
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (stakingContract == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        bool success;
        (success, returnData) = stakingContract.call(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(stakingContract, returnData);
    }

    /**
     * @notice Claim staking rewards from a rewards contract.
     * @param stakingContract  The staking rewards contract
     * @param callData         Encoded claim function call
     * @return returnData      Data returned by the staking contract
     */
    function claimStakingRewards(
        address stakingContract,
        bytes calldata callData
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (stakingContract == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        bool success;
        (success, returnData) = stakingContract.call(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(stakingContract, returnData);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // DEFI OPERATIONS
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Execute an exact-input swap on a DEX router.
     * @dev    Forwards pre-encoded `callData` to the router with optional ETH.
     *         Supports Uniswap V2, V3, curve, and any ABI-compatible router.
     *
     * @param router    DEX router address
     * @param tokenIn   Input token (address(0) for ETH)
     * @param tokenOut  Output token (address(0) for ETH)
     * @param amountIn  Amount of input token
     * @param ethValue  ETH to send with the call (for ETH-in swaps)
     * @param callData  Pre-encoded swap calldata for the specific router
     * @return returnData  Swap result data
     */
    function swapExact(
        address router,
        address tokenIn,
        address tokenOut,
        uint256 amountIn,
        uint256 ethValue,
        bytes calldata callData
    )
        external
        payable
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (router == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        if (ethValue > 0 && address(this).balance < ethValue) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, ethValue);
        }

        // Suppress "unused variable" warnings for tokenIn/tokenOut
        // (provided for indexing/event purposes by callers)
        tokenIn; tokenOut; amountIn;

        bool success;
        (success, returnData) = router.call{value: ethValue}(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(router, returnData);
    }

    /**
     * @notice Add liquidity to a DEX pool.
     * @param pool      Pool / router contract address
     * @param amount0   Amount of token0 (or ETH if pool uses ETH)
     * @param amount1   Amount of token1
     * @param ethValue  ETH to send with the call
     * @param callData  Pre-encoded addLiquidity calldata
     * @return returnData  LP receipt data
     */
    function addLiquidity(
        address pool,
        uint256 amount0,
        uint256 amount1,
        uint256 ethValue,
        bytes calldata callData
    )
        external
        payable
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (pool == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        if (ethValue > 0 && address(this).balance < ethValue) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, ethValue);
        }

        amount0; amount1; // provided for caller context

        bool success;
        (success, returnData) = pool.call{value: ethValue}(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(pool, returnData);
    }

    /**
     * @notice Remove liquidity from a DEX pool.
     * @param pool      Pool / router contract address
     * @param liquidity LP token amount to burn
     * @param callData  Pre-encoded removeLiquidity calldata
     * @return returnData  Withdrawn token amounts
     */
    function removeLiquidity(
        address pool,
        uint256 liquidity,
        bytes calldata callData
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (pool == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        liquidity; // provided for caller context

        bool success;
        (success, returnData) = pool.call(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(pool, returnData);
    }

    /**
     * @notice Bridge tokens to another chain via a bridge protocol.
     * @dev    Forwards pre-encoded calldata to the bridge contract.
     *         Supports Hop, Across, Stargate, LayerZero, etc.
     *
     * @param bridge      Bridge contract address
     * @param token       Token to bridge (address(0) for ETH)
     * @param amount      Amount to bridge
     * @param targetChain Destination chain ID
     * @param ethValue    ETH to send with the bridge call (fees + value for ETH bridge)
     * @param callData    Pre-encoded bridge calldata
     * @return returnData Bridge receipt data
     */
    function bridgeTokens(
        address bridge,
        address token,
        uint256 amount,
        uint256 targetChain,
        uint256 ethValue,
        bytes calldata callData
    )
        external
        payable
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (bridge == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        if (ethValue > 0 && address(this).balance < ethValue) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, ethValue);
        }

        token; amount; targetChain; // provided for caller context

        bool success;
        (success, returnData) = bridge.call{value: ethValue}(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(bridge, returnData);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // RAW CALL ESCAPE HATCHES
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * @notice Execute an arbitrary call to any address (no ETH value).
     * @dev    General-purpose escape hatch for operations not covered by
     *         specific module functions. Use with caution.
     *
     * @param target    Address to call
     * @param callData  Calldata to forward
     * @return returnData  Data returned by the target
     */
    function rawCall(
        address target,
        bytes calldata callData
    )
        external
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (target == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        bool success;
        (success, returnData) = target.call(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(target, returnData);
    }

    /**
     * @notice Execute an arbitrary call to any address WITH ETH value.
     * @dev    Escape hatch for sending ETH + calldata atomically.
     *
     * @param target    Address to call
     * @param value     ETH to send (must be available in vault balance)
     * @param callData  Calldata to forward
     * @return returnData  Data returned by the target
     */
    function rawCallWithValue(
        address target,
        uint256 value,
        bytes calldata callData
    )
        external
        payable
        onlyDelegatecall
        returns (bytes memory returnData)
    {
        if (target == address(0)) revert AdvancedExecutionModule__ZeroAddress();

        if (value > 0 && address(this).balance < value) {
            revert AdvancedExecutionModule__InsufficientBalance(address(this).balance, value);
        }

        bool success;
        (success, returnData) = target.call{value: value}(callData);
        if (!success) revert AdvancedExecutionModule__CallFailed(target, returnData);
    }
}